/**
 * Database Connection Manager
 * Supports PostgreSQL (relational) and MongoDB (document) databases
 */

const { Pool } = require('pg');
const { MongoClient } = require('mongodb');
const { logger } = require('../utils/logger');

// PostgreSQL connection pool
let pgPool = null;

// MongoDB client
let mongoClient = null;
let initializationError = null;
let initializationCompleted = false;

/**
 * Initialize PostgreSQL connection
 */
async function initPostgreSQL() {
  try {
    pgPool = new Pool({
      host: process.env.PG_HOST || 'localhost',
      port: parseInt(process.env.PG_PORT) || 5432,
      database: process.env.PG_DATABASE || 'afrera_db',
      user: process.env.PG_USER || 'postgres',
      password: process.env.PG_PASSWORD || 'password',
      max: 20, // Maximum pool size
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 2000,
    });

    // Test connection
    const client = await pgPool.connect();
    await client.query('SELECT NOW()');
    client.release();
    
    logger.info('PostgreSQL connection established successfully');
    return pgPool;
  } catch (error) {
    logger.error('PostgreSQL connection failed:', error);
    throw error;
  }
}

/**
 * Initialize MongoDB connection
 */
async function initMongoDB() {
  try {
    const uri = process.env.MONGO_URI || 'mongodb://localhost:27017/afrera_mongo';
    mongoClient = new MongoClient(uri, {
      maxPoolSize: 20,
      serverSelectionTimeoutMS: 5000,
      socketTimeoutMS: 45000,
    });

    await mongoClient.connect();
    await mongoClient.db('admin').command({ ping: 1 });
    
    logger.info('MongoDB connection established successfully');
    return mongoClient;
  } catch (error) {
    logger.error('MongoDB connection failed:', error);
    throw error;
  }
}

/**
 * Initialize all database connections
 */
async function initialize() {
  if (initializationCompleted) {
    return { pgPool, mongoClient };
  }

  try {
    await initPostgreSQL();
    await initMongoDB();
    initializationCompleted = true;
    initializationError = null;
    logger.info('All database connections initialized');
    return { pgPool, mongoClient };
  } catch (error) {
    initializationCompleted = true;
    initializationError = error;
    logger.warn('Database initialization failed; continuing in fallback mode:', error.message);
    return { pgPool, mongoClient };
  }
}

/**
 * Get PostgreSQL pool
 */
function getPostgreSQL() {
  if (!pgPool) {
    return null;
  }
  return pgPool;
}

/**
 * Get MongoDB client
 */
function getMongoDB() {
  if (!mongoClient) {
    throw new Error('MongoDB not initialized. Call initialize() first.');
  }
  return mongoClient;
}

/**
 * Get MongoDB database
 */
function getMongoDatabase() {
  const dbName = process.env.MONGO_DATABASE || 'afrera_mongo';
  return mongoClient.db(dbName);
}

/**
 * Health check for databases
 */
function isHealthy() {
  const pgHealthy = pgPool !== null;
  const mongoHealthy = mongoClient !== null && mongoClient.isConnected();
  return {
    postgresql: pgHealthy,
    mongodb: mongoHealthy,
    overall: pgHealthy && mongoHealthy,
    fallback: initializationError !== null
  };
}

/**
 * Close all database connections
 */
async function close() {
  try {
    if (pgPool) {
      await pgPool.end();
      logger.info('PostgreSQL connection closed');
    }
    if (mongoClient) {
      await mongoClient.close();
      logger.info('MongoDB connection closed');
    }
  } catch (error) {
    logger.error('Error closing database connections:', error);
    throw error;
  }
}

// Initialize on module load if not in test mode
if (process.env.NODE_ENV !== 'test') {
  initialize().catch(error => {
    logger.warn('Database initialization deferred to fallback mode:', error.message);
  });
}

module.exports = {
  initialize,
  getPostgreSQL,
  getMongoDB,
  getMongoDatabase,
  isHealthy,
  close
};
