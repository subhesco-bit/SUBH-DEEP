/**
 * Database Migration Runner
 * Runs all pending migrations in order
 */

const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');
const { logger } = require('../utils/logger');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

const migrationsDir = path.join(__dirname, 'migrations');

async function runMigrations() {
  try {
    logger.info('Starting database migrations...');

    // Create migrations table if not exists
    await pool.query(`
      CREATE TABLE IF NOT EXISTS schema_migrations (
        id SERIAL PRIMARY KEY,
        filename VARCHAR(255) UNIQUE NOT NULL,
        executed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Get all migration files
    const migrationFiles = fs.readdirSync(migrationsDir)
      .filter(file => file.endsWith('.sql'))
      .sort();

    logger.info(`Found ${migrationFiles.length} migration files`);

    // Get executed migrations
    const executedResult = await pool.query('SELECT filename FROM schema_migrations');
    const executedFiles = new Set(executedResult.rows.map(row => row.filename));

    // Run pending migrations
    for (const file of migrationFiles) {
      if (executedFiles.has(file)) {
        logger.info(`Skipping already executed migration: ${file}`);
        continue;
      }

      logger.info(`Running migration: ${file}`);
      const migrationPath = path.join(migrationsDir, file);
      const migrationSQL = fs.readFileSync(migrationPath, 'utf8');

      try {
        await pool.query(migrationSQL);
        await pool.query('INSERT INTO schema_migrations (filename) VALUES ($1)', [file]);
        logger.info(`Migration completed: ${file}`);
      } catch (error) {
        logger.error(`Migration failed: ${file}`, error);
        throw error;
      }
    }

    logger.info('All migrations completed successfully');
  } catch (error) {
    logger.error('Migration error:', error);
    process.exit(1);
  } finally {
    await pool.end();
  }
}

async function rollbackMigration(filename) {
  try {
    logger.info(`Rolling back migration: ${filename}`);

    // Remove from executed migrations
    await pool.query('DELETE FROM schema_migrations WHERE filename = $1', [filename]);

    logger.info(`Rollback completed: ${filename}`);
  } catch (error) {
    logger.error('Rollback error:', error);
    await pool.end();
    process.exit(1);
  } finally {
    await pool.end();
  }
}

async function showMigrationStatus() {
  try {
    const migrationFiles = fs.readdirSync(migrationsDir)
      .filter(file => file.endsWith('.sql'))
      .sort();

    const executedResult = await pool.query('SELECT filename, executed_at FROM schema_migrations ORDER BY executed_at');
    const executedFiles = new Map(executedResult.rows.map(row => [row.filename, row.executed_at]));

    const statusLines = ['\nMigration Status:', '=================='];

    for (const file of migrationFiles) {
      const executed = executedFiles.get(file);
      if (executed) {
        statusLines.push(`✅ ${file} - Executed at ${new Date(executed).toLocaleString()}`);
      } else {
        statusLines.push(`⏳ ${file} - Pending`);
      }
    }

    statusLines.push('==================\n');
    console.log(statusLines.join('\n'));
  } catch (error) {
    logger.error('Error showing migration status:', error);
    await pool.end();
    process.exit(1);
  } finally {
    await pool.end();
  }
}

// CLI interface
const command = process.argv[2];
const arg = process.argv[3];

switch (command) {
  case 'up':
  case undefined:
    runMigrations();
    break;
  case 'down':
    if (!arg) {
      console.error('Please specify migration filename to rollback');
      process.exit(1);
    }
    rollbackMigration(arg);
    break;
  case 'status':
    showMigrationStatus();
    break;
  default:
    console.log('Usage: node migrate.js [up|down|status] [filename]');
    process.exit(1);
    break;
}
