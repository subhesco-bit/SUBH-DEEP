-- Advanced Voice AI Tables Migration
-- for AFRERA Platform Advanced Voice AI Service

-- Voice conversations table
CREATE TABLE IF NOT EXISTS voice_conversations (
  id SERIAL PRIMARY KEY,
  conversation_id VARCHAR(100) UNIQUE NOT NULL,
  user_id INTEGER NOT NULL REFERENCES users(id),
  language VARCHAR(10) DEFAULT 'en',
  status VARCHAR(20) DEFAULT 'active',
  started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  ended_at TIMESTAMP,
  duration_seconds INTEGER,
  metadata JSONB DEFAULT '{}',
  INDEX idx_voice_conversations_user (user_id),
  INDEX idx_voice_conversations_status (status),
  INDEX idx_voice_conversations_language (language)
);

-- Voice conversation turns table
CREATE TABLE IF NOT EXISTS voice_conversation_turns (
  id SERIAL PRIMARY KEY,
  conversation_id VARCHAR(100) NOT NULL REFERENCES voice_conversations(conversation_id),
  user_id INTEGER NOT NULL REFERENCES users(id),
  transcript TEXT NOT NULL,
  intent VARCHAR(50) NOT NULL,
  confidence DECIMAL(3,2),
  entities JSONB DEFAULT '{}',
  response_text TEXT NOT NULL,
  response_data JSONB DEFAULT '{}',
  audio_transcription_provider VARCHAR(50),
  audio_transcription_confidence DECIMAL(3,2),
  processing_time_ms INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_voice_turns_conversation (conversation_id),
  INDEX idx_voice_turns_user (user_id),
  INDEX idx_voice_turns_intent (intent),
  INDEX idx_voice_turns_created (created_at)
);

-- Voice command analytics table
CREATE TABLE IF NOT EXISTS voice_command_analytics (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  intent VARCHAR(50) NOT NULL,
  confidence DECIMAL(3,2),
  language VARCHAR(10),
  entities_detected JSONB,
  response_generated BOOLEAN DEFAULT TRUE,
  user_satisfaction_rating INTEGER,
  error_message TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_voice_analytics_user (user_id),
  INDEX idx_voice_analytics_intent (intent),
  INDEX idx_voice_analytics_language (language),
  INDEX idx_voice_analytics_created (created_at)
);

-- Voice language preferences table
CREATE TABLE IF NOT EXISTS voice_language_preferences (
  id SERIAL PRIMARY KEY,
  user_id INTEGER UNIQUE REFERENCES users(id),
  preferred_language VARCHAR(10) DEFAULT 'en',
  voice_gender VARCHAR(10) DEFAULT 'female',
  speech_rate DECIMAL(2,1) DEFAULT 1.0,
  speech_pitch DECIMAL(2,1) DEFAULT 1.0,
  accessibility_settings JSONB DEFAULT '{}',
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_voice_prefs_user (user_id)
);

-- Voice feedback table
CREATE TABLE IF NOT EXISTS voice_feedback (
  id SERIAL PRIMARY KEY,
  conversation_id VARCHAR(100) REFERENCES voice_conversations(conversation_id),
  user_id INTEGER NOT NULL REFERENCES users(id),
  rating INTEGER CHECK (rating >= 1 AND rating <= 5),
  feedback_text TEXT,
  misunderstood_query TEXT,
  suggested_improvement TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_voice_feedback_conversation (conversation_id),
  INDEX idx_voice_feedback_user (user_id),
  INDEX idx_voice_feedback_rating (rating)
);

-- Add voice preference to user profiles if not exists
ALTER TABLE user_profiles
ADD COLUMN IF NOT EXISTS voice_language VARCHAR(10) DEFAULT 'en',
ADD COLUMN IF NOT EXISTS voice_preference JSONB DEFAULT '{"gender": "female", "rate": 1.0, "pitch": 1.0}';

-- Create function to update voice conversation duration
CREATE OR REPLACE FUNCTION update_voice_conversation_duration()
RETURNS TRIGGER AS $$
BEGIN
  NEW.duration_seconds = EXTRACT(EPOCH FROM (COALESCE(NEW.ended_at, CURRENT_TIMESTAMP) - NEW.started_at));
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to automatically update duration
CREATE TRIGGER trigger_update_voice_conversation_duration
BEFORE INSERT OR UPDATE ON voice_conversations
FOR EACH ROW
EXECUTE FUNCTION update_voice_conversation_duration();