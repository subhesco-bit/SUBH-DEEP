-- GST Service Tables Migration
-- for AFRERA Platform GST Service

-- HSN to GST rate mapping table
CREATE TABLE IF NOT EXISTS hsn_gst_mapping (
  id SERIAL PRIMARY KEY,
  hsn_code VARCHAR(10) UNIQUE NOT NULL,
  description TEXT,
  gst_rate DECIMAL(4,2) NOT NULL,
  category VARCHAR(50),
  effective_date DATE DEFAULT CURRENT_DATE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_hsn_code (hsn_code),
  INDEX idx_hsn_category (category),
  INDEX idx_hsn_gst_rate (gst_rate)
);

-- GST invoices table
CREATE TABLE IF NOT EXISTS gst_invoices (
  id SERIAL PRIMARY KEY,
  order_id INTEGER NOT NULL REFERENCES orders(id),
  invoice_number VARCHAR(50) UNIQUE NOT NULL,
  invoice_date DATE NOT NULL,
  buyer_name VARCHAR(255) NOT NULL,
  buyer_gstin VARCHAR(15),
  buyer_address TEXT,
  buyer_state VARCHAR(10),
  seller_state VARCHAR(10) DEFAULT 'AS',
  gst_calculation JSONB NOT NULL,
  total_amount DECIMAL(12,2) NOT NULL,
  payment_status VARCHAR(20) DEFAULT 'pending',
  eway_bill_number VARCHAR(20),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_gst_invoice_order (order_id),
  INDEX idx_gst_invoice_number (invoice_number),
  INDEX idx_gst_invoice_date (invoice_date),
  INDEX idx_gst_invoice_buyer_gstin (buyer_gstin)
);

-- GST invoice items table
CREATE TABLE IF NOT EXISTS gst_invoice_items (
  id SERIAL PRIMARY KEY,
  invoice_id INTEGER NOT NULL REFERENCES gst_invoices(id),
  item_id INTEGER,
  name VARCHAR(255) NOT NULL,
  hsn_code VARCHAR(10),
  gst_rate DECIMAL(4,2),
  taxable_value DECIMAL(12,2),
  cgst DECIMAL(12,2),
  sgst DECIMAL(12,2),
  igst DECIMAL(12,2),
  total_gst DECIMAL(12,2),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_gst_item_invoice (invoice_id),
  INDEX idx_gst_item_hsn (hsn_code)
);

-- E-way bills table
CREATE TABLE IF NOT EXISTS eway_bills (
  id SERIAL PRIMARY KEY,
  eway_bill_number VARCHAR(20) UNIQUE NOT NULL,
  invoice_id INTEGER NOT NULL REFERENCES gst_invoices(id),
  vehicle_number VARCHAR(20) NOT NULL,
  distance INTEGER NOT NULL,
  validity_days INTEGER NOT NULL,
  valid_from TIMESTAMP NOT NULL,
  valid_until TIMESTAMP NOT NULL,
  status VARCHAR(20) DEFAULT 'active',
  extension_count INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_eway_bill_number (eway_bill_number),
  INDEX idx_eway_invoice (invoice_id),
  INDEX idx_eway_vehicle (vehicle_number),
  INDEX idx_eway_status (status),
  INDEX idx_eway_validity (valid_until)
);

-- GST ITC ledger table
CREATE TABLE IF NOT EXISTS gst_itc_ledger (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  financial_year VARCHAR(10) NOT NULL,
  period VARCHAR(10) NOT NULL,
  eligible_itc DECIMAL(12,2) DEFAULT 0,
  utilized_itc DECIMAL(12,2) DEFAULT 0,
  balance_itc DECIMAL(12,2) DEFAULT 0,
  return_filed BOOLEAN DEFAULT FALSE,
  return_date DATE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_itc_user (user_id),
  INDEX idx_itc_period (financial_year, period),
  INDEX idx_itc_return (return_filed)
);

-- GST compliance tracking table
CREATE TABLE IF NOT EXISTS gst_compliance_tracking (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  financial_year VARCHAR(10) NOT NULL,
  gstr1_filed BOOLEAN DEFAULT FALSE,
  gstr1_filed_date DATE,
  gstr3b_filed BOOLEAN DEFAULT FALSE,
  gstr3b_filed_date DATE,
  gst_payment_made BOOLEAN DEFAULT FALSE,
  gst_payment_date DATE,
  gst_payment_amount DECIMAL(12,2),
  compliance_score DECIMAL(3,2),
  last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_compliance_user (user_id),
  INDEX idx_compliance_year (financial_year)
);

-- GST returns history table
CREATE TABLE IF NOT EXISTS gst_returns_history (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  return_type VARCHAR(10) NOT NULL,
  return_period VARCHAR(10) NOT NULL,
  filing_date DATE,
  status VARCHAR(20),
  acknowledgement_number VARCHAR(50),
  tax_paid DECIMAL(12,2),
  itc_claimed DECIMAL(12,2),
  refund_claimed DECIMAL(12,2),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_returns_user (user_id),
  INDEX idx_returns_period (return_period),
  INDEX idx_returns_type (return_type)
);

-- Add GSTIN to user profiles if not exists
ALTER TABLE user_profiles
ADD COLUMN IF NOT EXISTS gstin VARCHAR(15),
ADD COLUMN IF NOT EXISTS gst_registration_type VARCHAR(20) DEFAULT 'unregistered',
ADD COLUMN IF NOT EXISTS gst_filing_frequency VARCHAR(20) DEFAULT 'monthly';

-- Create function to update invoice total
CREATE OR REPLACE FUNCTION update_gst_invoice_total()
RETURNS TRIGGER AS $$
BEGIN
  NEW.total_amount = (
    SELECT COALESCE(SUM(taxable_value + total_gst), 0)
    FROM gst_invoice_items
    WHERE invoice_id = NEW.id
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to automatically update invoice total
CREATE TRIGGER trigger_update_gst_invoice_total
AFTER INSERT OR UPDATE ON gst_invoice_items
FOR EACH STATEMENT
EXECUTE FUNCTION update_gst_invoice_total();

-- Insert default HSN codes for agricultural products
INSERT INTO hsn_gst_mapping (hsn_code, description, gst_rate, category) VALUES
('0801', 'Coconuts, Brazil nuts and cashew nuts, fresh or dried', 0, 'agricultural_products'),
('0802', 'Other nuts, fresh or dried', 0, 'agricultural_products'),
('0803', 'Bananas, including plantains, fresh or dried', 0, 'agricultural_products'),
('0804', 'Dates, figs, pineapples, avocados, mangoes, fresh or dried', 0, 'agricultural_products'),
('0805', 'Citrus fruit, fresh or dried', 0, 'agricultural_products'),
('0806', 'Grapes, fresh or dried', 0, 'agricultural_products'),
('0807', 'Melons, including watermelons, and papayas, fresh', 0, 'agricultural_products'),
('0808', 'Apples, pears and quinces, fresh', 0, 'agricultural_products'),
('0809', 'Apricots, cherries, peaches, nectarines, plums and sloes, fresh', 0, 'agricultural_products'),
('0810', 'Other fruit, fresh', 0, 'agricultural_products'),
('0901', 'Coffee, whether or not roasted or decaffeinated', 0, 'agricultural_products'),
('0902', 'Tea, whether or not flavored', 0, 'agricultural_products'),
('1001', 'Wheat and meslin', 0, 'agricultural_products'),
('1002', 'Rye', 0, 'agricultural_products'),
('1003', 'Barley', 0, 'agricultural_products'),
('1004', 'Oats', 0, 'agricultural_products'),
('1005', 'Maize (corn)', 0, 'agricultural_products'),
('1006', 'Rice', 0, 'agricultural_products'),
('1007', 'Grain sorghum', 0, 'agricultural_products'),
('1008', 'Buckwheat, millet and canary seed', 0, 'agricultural_products'),
('1905', 'Bread, pastry, cakes, biscuits and other bakers wares', 5, 'processed_foods'),
('2001', 'Vegetables, fruit, nuts prepared or preserved by vinegar', 5, 'processed_foods'),
('2002', 'Tomatoes, prepared or preserved', 5, 'processed_foods'),
('2004', 'Other vegetables, prepared or preserved', 5, 'processed_foods'),
('2008', 'Fruit, nuts prepared or preserved', 12, 'processed_foods'),
('0401', 'Milk and cream, not concentrated', 0, 'dairy_products'),
('0402', 'Milk and cream, concentrated', 12, 'dairy_products'),
('0403', 'Yogurt', 12, 'dairy_products'),
('0405', 'Butter and other fats from milk', 12, 'dairy_products'),
('0406', 'Cheese and curd', 12, 'dairy_products'),
('0409', 'Natural honey', 0, 'dairy_products')
ON CONFLICT (hsn_code) DO NOTHING;