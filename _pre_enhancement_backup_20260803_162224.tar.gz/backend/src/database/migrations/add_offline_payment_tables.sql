-- Offline Payment Tables Migration
-- for AFRERA Platform Offline Payment Service

-- Offline payment requests table
CREATE TABLE IF NOT EXISTS offline_payment_requests (
  id SERIAL PRIMARY KEY,
  payment_code VARCHAR(100) UNIQUE NOT NULL,
  merchant_id INTEGER NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  reference VARCHAR(100),
  payment_data TEXT NOT NULL,
  signature VARCHAR(255) NOT NULL,
  expires_at TIMESTAMP NOT NULL,
  status VARCHAR(20) DEFAULT 'pending',
  completed_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_offline_payment_code (payment_code),
  INDEX idx_offline_merchant (merchant_id),
  INDEX idx_offline_status (status),
  INDEX idx_offline_expires (expires_at)
);

-- Offline transactions table
CREATE TABLE IF NOT EXISTS offline_transactions (
  id SERIAL PRIMARY KEY,
  transaction_id VARCHAR(100) UNIQUE NOT NULL,
  payment_request_id INTEGER REFERENCES offline_payment_requests(id),
  payer_id INTEGER NOT NULL REFERENCES users(id),
  merchant_id INTEGER NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  pin_verified BOOLEAN DEFAULT FALSE,
  biometric_data JSONB,
  status VARCHAR(20) DEFAULT 'pending',
  sync_status VARCHAR(20) DEFAULT 'pending',
  synced_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_offline_tx_id (transaction_id),
  INDEX idx_offline_tx_payer (payer_id),
  INDEX idx_offline_tx_merchant (merchant_id),
  INDEX idx_offline_tx_status (status),
  INDEX idx_offline_tx_sync (sync_status)
);

-- Offline sync queue table
CREATE TABLE IF NOT EXISTS offline_sync_queue (
  id SERIAL PRIMARY KEY,
  transaction_id VARCHAR(100) UNIQUE NOT NULL,
  transaction_type VARCHAR(50) NOT NULL,
  sync_status VARCHAR(20) DEFAULT 'pending',
  retry_count INTEGER DEFAULT 0,
  last_sync_attempt TIMESTAMP,
  synced_at TIMESTAMP,
  error_message TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_sync_queue_tx (transaction_id),
  INDEX idx_sync_queue_status (sync_status),
  INDEX idx_sync_queue_type (transaction_type),
  INDEX idx_sync_queue_created (created_at)
);

-- USSD payment requests table
CREATE TABLE IF NOT EXISTS ussd_payment_requests (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  merchant_id INTEGER NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  ussd_code VARCHAR(50) UNIQUE NOT NULL,
  reference VARCHAR(100),
  status VARCHAR(20) DEFAULT 'pending',
  completed_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_ussd_user (user_id),
  INDEX idx_ussd_merchant (merchant_id),
  INDEX idx_ussd_code (ussd_code),
  INDEX idx_ussd_status (status)
);

-- User payment settings table
CREATE TABLE IF NOT EXISTS user_payment_settings (
  id SERIAL PRIMARY KEY,
  user_id INTEGER UNIQUE NOT NULL REFERENCES users(id),
  pin_hash VARCHAR(255) NOT NULL,
  biometric_enabled BOOLEAN DEFAULT FALSE,
  biometric_data JSONB,
  daily_limit DECIMAL(10,2) DEFAULT 50000,
  transaction_limit DECIMAL(10,2) DEFAULT 10000,
  security_questions JSONB DEFAULT '[]',
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_payment_settings_user (user_id)
);

-- User wallets table
CREATE TABLE IF NOT EXISTS user_wallets (
  id SERIAL PRIMARY KEY,
  user_id INTEGER UNIQUE NOT NULL REFERENCES users(id),
  balance DECIMAL(10,2) DEFAULT 0,
  currency VARCHAR(3) DEFAULT 'INR',
  status VARCHAR(20) DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_wallets_user (user_id),
  INDEX idx_wallets_status (status)
);

-- Transactions table (if not exists)
CREATE TABLE IF NOT EXISTS transactions (
  id SERIAL PRIMARY KEY,
  transaction_id VARCHAR(100) UNIQUE NOT NULL,
  user_id INTEGER NOT NULL REFERENCES users(id),
  type VARCHAR(50) NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  status VARCHAR(20) DEFAULT 'pending',
  reference VARCHAR(100),
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_transactions_id (transaction_id),
  INDEX idx_transactions_user (user_id),
  INDEX idx_transactions_type (type),
  INDEX idx_transactions_status (status),
  INDEX idx_transactions_created (created_at)
);

-- NFC payment cards table (for future use)
CREATE TABLE IF NOT EXISTS nfc_payment_cards (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  card_id VARCHAR(100) UNIQUE NOT NULL,
  card_token VARCHAR(255) NOT NULL,
  is_active BOOLEAN DEFAULT TRUE,
  daily_limit DECIMAL(10,2) DEFAULT 10000,
  last_used_at TIMESTAMP,
  expires_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_nfc_user (user_id),
  INDEX idx_nfc_card (card_id),
  INDEX idx_nfc_active (is_active)
);

-- Offline payment analytics table
CREATE TABLE IF NOT EXISTS offline_payment_analytics (
  id SERIAL PRIMARY KEY,
  transaction_id VARCHAR(100) REFERENCES offline_transactions(transaction_id),
  user_id INTEGER REFERENCES users(id),
  merchant_id INTEGER,
  payment_method VARCHAR(20) NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  processing_time_ms INTEGER,
  sync_delay_minutes INTEGER,
  location_lat DECIMAL(10,6),
  location_long DECIMAL(10,6),
  device_info JSONB,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_offline_analytics_user (user_id),
  INDEX idx_offline_analytics_method (payment_method),
  INDEX idx_offline_analytics_created (created_at)
);

-- Add payment preferences to user profiles
ALTER TABLE user_profiles
ADD COLUMN IF NOT EXISTS payment_method_preference VARCHAR(20) DEFAULT 'qr',
ADD COLUMN IF NOT EXISTS auto_sync_enabled BOOLEAN DEFAULT TRUE,
ADD COLUMN IF NOT EXISTS offline_payment_enabled BOOLEAN DEFAULT TRUE;