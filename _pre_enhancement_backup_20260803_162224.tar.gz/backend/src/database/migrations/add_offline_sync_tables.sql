-- Offline Sync Service Tables Migration
-- for AFRERA Platform Offline Sync Service

-- Sync queue table
CREATE TABLE IF NOT EXISTS sync_queue (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  entity_type VARCHAR(50) NOT NULL,
  entity_data JSONB NOT NULL,
  operation VARCHAR(20) NOT NULL,
  sync_token VARCHAR(255) NOT NULL,
  priority INTEGER DEFAULT 3,
  status VARCHAR(20) DEFAULT 'pending',
  retry_count INTEGER DEFAULT 0,
  next_retry_at TIMESTAMP,
  error_message TEXT,
  synced_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_sync_queue_user (user_id),
  INDEX idx_sync_queue_status (status),
  INDEX idx_sync_queue_priority (priority),
  INDEX idx_sync_queue_type (entity_type),
  INDEX idx_sync_queue_retry (next_retry_at)
);

-- Sync conflicts table
CREATE TABLE IF NOT EXISTS sync_conflicts (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  entity_type VARCHAR(50) NOT NULL,
  entity_id VARCHAR(100),
  client_data JSONB NOT NULL,
  client_sync_token VARCHAR(255) NOT NULL,
  server_data JSONB NOT NULL,
  server_sync_token VARCHAR(255) NOT NULL,
  operation VARCHAR(20) NOT NULL,
  status VARCHAR(20) DEFAULT 'unresolved',
  resolution VARCHAR(20),
  resolved_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_sync_conflicts_user (user_id),
  INDEX idx_sync_conflicts_status (status),
  INDEX idx_sync_conflicts_entity (entity_type, entity_id)
);

-- User sync preferences table
CREATE TABLE IF NOT EXISTS user_sync_preferences (
  id SERIAL PRIMARY KEY,
  user_id INTEGER UNIQUE NOT NULL REFERENCES users(id),
  sync_enabled BOOLEAN DEFAULT TRUE,
  sync_frequency INTEGER DEFAULT 5,
  sync_on_wifi_only BOOLEAN DEFAULT FALSE,
  sync_on_charging_only BOOLEAN DEFAULT FALSE,
  auto_sync BOOLEAN DEFAULT TRUE,
  sync_conflicts_resolution VARCHAR(20) DEFAULT 'last_write_wins',
  data_retention_days INTEGER DEFAULT 30,
  max_offline_storage_mb INTEGER DEFAULT 100,
  sync_entities JSONB DEFAULT '["orders", "products", "user_profile"]',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_sync_prefs_user (user_id)
);

-- Generic entities table for unsupported entity types
CREATE TABLE IF NOT EXISTS generic_entities (
  id SERIAL PRIMARY KEY,
  entity_type VARCHAR(50) NOT NULL,
  entity_id VARCHAR(100) NOT NULL,
  entity_data JSONB NOT NULL,
  operation VARCHAR(20) NOT NULL,
  sync_status VARCHAR(20) DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(entity_type, entity_id),
  INDEX idx_generic_entities_type (entity_type),
  INDEX idx_generic_entities_status (sync_status)
);

-- Sync audit log table
CREATE TABLE IF NOT EXISTS sync_audit_log (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  sync_session_id VARCHAR(100),
  action VARCHAR(50) NOT NULL,
  entity_type VARCHAR(50),
  entity_id VARCHAR(100),
  status VARCHAR(20) NOT NULL,
  error_message TEXT,
  data_size_bytes INTEGER,
  processing_time_ms INTEGER,
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_sync_audit_user (user_id),
  INDEX idx_sync_audit_session (sync_session_id),
  INDEX idx_sync_audit_action (action),
  INDEX idx_sync_audit_created (created_at)
);

-- Data snapshot table for offline storage
CREATE TABLE IF NOT EXISTS offline_data_snapshots (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  entity_type VARCHAR(50) NOT NULL,
  snapshot_data JSONB NOT NULL,
  snapshot_version VARCHAR(20),
  data_hash VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  expires_at TIMESTAMP,
  INDEX idx_snapshot_user (user_id),
  INDEX idx_snapshot_type (entity_type),
  INDEX idx_snapshot_expires (expires_at)
);

-- Network status tracking table
CREATE TABLE IF NOT EXISTS network_status_tracking (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  connection_type VARCHAR(20),
  network_quality VARCHAR(20),
  latency_ms INTEGER,
  bandwidth_mbps DECIMAL(8,2),
  online BOOLEAN DEFAULT TRUE,
  last_online_at TIMESTAMP,
  last_offline_at TIMESTAMP,
  offline_duration_seconds INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_network_user (user_id),
  INDEX idx_network_status (online)
);

-- Sync statistics table
CREATE TABLE IF NOT EXISTS sync_statistics (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  date DATE NOT NULL,
  total_sync_attempts INTEGER DEFAULT 0,
  successful_syncs INTEGER DEFAULT 0,
  failed_syncs INTEGER DEFAULT 0,
  total_data_synced_bytes BIGINT DEFAULT 0,
  average_sync_time_ms INTEGER,
  conflicts_resolved INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, date),
  INDEX idx_sync_stats_user (user_id),
  INDEX idx_sync_stats_date (date)
);

-- Add offline capabilities to user profiles
ALTER TABLE user_profiles
ADD COLUMN IF NOT EXISTS offline_mode_enabled BOOLEAN DEFAULT TRUE,
ADD COLUMN IF NOT EXISTS last_sync_timestamp TIMESTAMP,
ADD COLUMN IF NOT EXISTS offline_data_version VARCHAR(20);

-- Create function to update sync statistics
CREATE OR REPLACE FUNCTION update_sync_statistics(user_id_param INTEGER, status_param VARCHAR, data_size_param INTEGER, processing_time_param INTEGER)
RETURNS VOID AS $$
BEGIN
  INSERT INTO sync_statistics (user_id, date, total_sync_attempts, total_data_synced_bytes, average_sync_time_ms)
  VALUES (user_id_param, CURRENT_DATE, 1, data_size_param, processing_time_param)
  ON CONFLICT (user_id, date) 
  DO UPDATE SET 
    total_sync_attempts = sync_statistics.total_sync_attempts + 1,
    total_data_synced_bytes = sync_statistics.total_data_synced_bytes + data_size_param,
    average_sync_time_ms = (sync_statistics.average_sync_time_ms * sync_statistics.total_sync_attempts + processing_time_param) / (sync_statistics.total_sync_attempts + 1),
    successful_syncs = CASE WHEN status_param = 'success' THEN sync_statistics.successful_syncs + 1 ELSE sync_statistics.successful_syncs END,
    failed_syncs = CASE WHEN status_param = 'failed' THEN sync_statistics.failed_syncs + 1 ELSE sync_statistics.failed_syncs END,
    updated_at = NOW();
END;
$$ LANGUAGE plpgsql;

-- Create trigger to automatically update sync statistics
CREATE TRIGGER trigger_update_sync_statistics
AFTER INSERT OR UPDATE ON sync_queue
FOR EACH ROW
WHEN (NEW.status IN ('completed', 'failed'))
EXECUTE FUNCTION update_sync_statistics(NEW.user_id, NEW.status, 0, 0);

-- Create function to clean up old offline data
CREATE OR REPLACE FUNCTION cleanup_old_offline_data()
RETURNS VOID AS $$
BEGIN
  DELETE FROM offline_data_snapshots WHERE expires_at < NOW();
  DELETE FROM sync_queue WHERE created_at < NOW() - INTERVAL '30 days' AND status = 'completed';
  DELETE FROM sync_audit_log WHERE created_at < NOW() - INTERVAL '90 days';
END;
$$ LANGUAGE plpgsql;

-- Create index for periodic cleanup
CREATE INDEX IF NOT EXISTS idx_sync_queue_cleanup ON sync_queue(created_at) WHERE status = 'completed';

-- Add user preferences for offline storage management
ALTER TABLE user_sync_preferences
ADD COLUMN IF NOT EXISTS storage_optimization_enabled BOOLEAN DEFAULT TRUE,
ADD COLUMN IF NOT EXISTS compress_offline_data BOOLEAN DEFAULT TRUE,
ADD COLUMN IF NOT EXISTS background_sync_enabled BOOLEAN DEFAULT TRUE;