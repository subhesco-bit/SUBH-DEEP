/**
 * AFRERA Platform Backend - Main Entry Point
 * Microservices Architecture with API Gateway
 */

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const compression = require('compression');
const { createServer } = require('http');
const { Server } = require('socket.io');

// Import services
const authService = require('./services/authService');
const productService = require('./services/productService');
const orderService = require('./services/orderService');
const farmerService = require('./services/farmerService');
const financialService = require('./services/financialService');
const logisticsService = require('./services/logisticsService');
const insuranceService = require('./services/insuranceService');
const aiService = require('./services/aiService');
const erpService = require('./services/erpService');
const multilingualService = require('./services/multilingualService');
const organicTraceabilityService = require('./services/organicTraceabilityService');
const nutritionIntelligenceService = require('./services/nutritionIntelligenceService');
const conversationalAIService = require('./services/conversationalAIService');
const laboratoryERPService = require('./services/laboratoryERPService');
const giIntelligenceService = require('./services/giIntelligenceService');
const foodIntelligenceService = require('./services/foodIntelligenceService');
const valueCommerceService = require('./services/valueCommerceService');
const consumerHealthService = require('./services/consumerHealthService');
const voiceAIService = require('./services/voiceAIService');
const blockchainTraceabilityService = require('./services/blockchainTraceabilityService');
const knowledgeGraphService = require('./services/knowledgeGraphService');
const predictiveAnalyticsService = require('./services/predictiveAnalyticsService');
const iotIntegrationService = require('./services/iotIntegrationService');
const arVrService = require('./services/arVrService');
const smsAuthService = require('./services/smsAuthService');
const advancedVoiceAI = require('./services/advancedVoiceAI');
const offlinePaymentService = require('./services/offlinePaymentService');
const advancedAIService = require('./services/advancedAIService');
const gstService = require('./services/gstService');
const offlineSyncService = require('./services/offlineSyncService');
const formService = require('./services/formService');
const analyticsService = require('./services/analyticsService');
const moduleCatalogService = require('./services/moduleCatalogService');
const indigenousKnowledgeService = require('./services/indigenousKnowledgeService');
const biodiversityService = require('./services/biodiversityService');
const aiCopilotService = require('./services/aiCopilotService');
const omnichannelAIService = require('./services/omnichannelAIService');
const foodSafetyService = require('./services/foodSafetyService');
const shelfLifeService = require('./services/shelfLifeService');
const institutionalProcurementService = require('./services/institutionalProcurementService');
const digitalProductPassportService = require('./services/digitalProductPassportService');
const recipeIntelligenceService = require('./services/recipeIntelligenceService');

// Import enhancement routes
const marketplaceEnhancements = require('./routes/marketplaceEnhancements');
const insuranceEnhancements = require('./routes/insuranceEnhancements');
const farmerPortalEnhancements = require('./routes/farmerPortalEnhancements');
const governanceModule = require('./routes/governanceModule');
const logisticsEnhancements = require('./routes/logisticsEnhancements');
const advancedFeatures = require('./routes/advancedFeatures');

// Import middleware
const { errorHandler } = require('./middleware/errorHandler');
const { rateLimiter } = require('./middleware/rateLimiter');
const { authMiddleware } = require('./middleware/auth');
const { logger } = require('./utils/logger');

// Initialize Express app
const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: {
    origin: process.env.FRONTEND_URL || 'http://localhost:3000',
    methods: ['GET', 'POST', 'PUT', 'DELETE']
  }
});

// Security middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "https:"],
      scriptSrc: ["'self'"]
    }
  },
  crossOriginEmbedderPolicy: false
}));

// CORS configuration
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// General middleware
app.use(compression());
app.use(morgan('combined', { stream: { write: message => logger.info(message.trim()) } }));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Rate limiting
app.use('/api/', rateLimiter);

// Health check endpoint
app.get('/health', (req, res) => {
  const connection = require('./database/connection');
  const redis = require('./cache/redis');

  const healthChecks = {
    auth: typeof authService.isHealthy === 'function' ? authService.isHealthy() : { status: 'ok' },
    database: typeof connection.isHealthy === 'function' ? connection.isHealthy() : { status: 'unknown' },
    redis: typeof redis.isHealthy === 'function' ? redis.isHealthy() : { status: 'disabled' },
    ai: typeof aiService.isHealthy === 'function' ? aiService.isHealthy() : { status: 'ok' }
  };

  // Add optional services if they exist
  if (typeof indigenousKnowledgeService !== 'undefined') {
    healthChecks.indigenous_knowledge = typeof indigenousKnowledgeService.isHealthy === 'function' ? indigenousKnowledgeService.isHealthy() : { status: 'ok' };
  }
  if (typeof biodiversityService !== 'undefined') {
    healthChecks.biodiversity = typeof biodiversityService.isHealthy === 'function' ? biodiversityService.isHealthy() : { status: 'ok' };
  }
  if (typeof aiCopilotService !== 'undefined') {
    healthChecks.ai_copilot = typeof aiCopilotService.isHealthy === 'function' ? aiCopilotService.isHealthy() : { status: 'ok' };
  }
  if (typeof omnichannelAIService !== 'undefined') {
    healthChecks.omnichannel_ai = typeof omnichannelAIService.isHealthy === 'function' ? omnichannelAIService.isHealthy() : { status: 'ok' };
  }
  if (typeof foodSafetyService !== 'undefined') {
    healthChecks.food_safety = typeof foodSafetyService.isHealthy === 'function' ? foodSafetyService.isHealthy() : { status: 'ok' };
  }
  if (typeof shelfLifeService !== 'undefined') {
    healthChecks.shelf_life = typeof shelfLifeService.isHealthy === 'function' ? shelfLifeService.isHealthy() : { status: 'ok' };
  }
  if (typeof institutionalProcurementService !== 'undefined') {
    healthChecks.institutional_procurement = typeof institutionalProcurementService.isHealthy === 'function' ? institutionalProcurementService.isHealthy() : { status: 'ok' };
  }
  if (typeof digitalProductPassportService !== 'undefined') {
    healthChecks.digital_product_passport = typeof digitalProductPassportService.isHealthy === 'function' ? digitalProductPassportService.isHealthy() : { status: 'ok' };
  }
  if (typeof recipeIntelligenceService !== 'undefined') {
    healthChecks.recipe_intelligence = typeof recipeIntelligenceService.isHealthy === 'function' ? recipeIntelligenceService.isHealthy() : { status: 'ok' };
  }

  res.status(200).json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    services: healthChecks
  });
});

// API Routes
const mountRoute = (pathPrefix, serviceModule) => {
  if (serviceModule && serviceModule.router) {
    app.use(pathPrefix, serviceModule.router);
    return true;
  }

  logger.warn(`Skipping route mount for ${pathPrefix} because no router was exported.`);
  return false;
};

mountRoute('/api/v1/auth', authService);
mountRoute('/api/v1/products', productService);
mountRoute('/api/v1/orders', orderService);
mountRoute('/api/v1/farmers', farmerService);
mountRoute('/api/v1/financial', financialService);
mountRoute('/api/v1/logistics', logisticsService);
mountRoute('/api/v1/insurance', insuranceService);
mountRoute('/api/v1/ai', aiService);
mountRoute('/api/v1/erp', erpService);
mountRoute('/api/v1/multilingual', multilingualService);
mountRoute('/api/v1/organic-traceability', organicTraceabilityService);
mountRoute('/api/v1/nutrition-intelligence', nutritionIntelligenceService);
mountRoute('/api/v1/conversational-ai', conversationalAIService);
mountRoute('/api/v1/laboratory-erp', laboratoryERPService);
mountRoute('/api/v1/gi-intelligence', giIntelligenceService);
mountRoute('/api/v1/food-intelligence', foodIntelligenceService);
mountRoute('/api/v1/value-commerce', valueCommerceService);
mountRoute('/api/v1/consumer-health', consumerHealthService);
mountRoute('/api/v1/voice-ai', voiceAIService);
mountRoute('/api/v1/blockchain-traceability', blockchainTraceabilityService);
mountRoute('/api/v1/knowledge-graph', knowledgeGraphService);
mountRoute('/api/v1/predictive-analytics', predictiveAnalyticsService);
mountRoute('/api/v1/iot-integration', iotIntegrationService);
mountRoute('/api/v1/ar-vr', arVrService);
mountRoute('/api/v1/sms-auth', smsAuthService);
mountRoute('/api/v1/advanced-voice', advancedVoiceAI);
mountRoute('/api/v1/offline-payment', offlinePaymentService);
mountRoute('/api/v1/advanced-ai', advancedAIService);
mountRoute('/api/v1/gst', gstService);
mountRoute('/api/v1/offline-sync', offlineSyncService);
mountRoute('/api/v1/indigenous-knowledge', indigenousKnowledgeService);
mountRoute('/api/v1/biodiversity', biodiversityService);
mountRoute('/api/v1/ai-copilot', aiCopilotService);
mountRoute('/api/v1/omnichannel-ai', omnichannelAIService);
mountRoute('/api/v1/food-safety', foodSafetyService);
mountRoute('/api/v1/shelf-life', shelfLifeService);
mountRoute('/api/v1/institutional-procurement', institutionalProcurementService);
mountRoute('/api/v1/digital-product-passport', digitalProductPassportService);
mountRoute('/api/v1/recipe-intelligence', recipeIntelligenceService);
mountRoute('/api/v1/forms', formService);
mountRoute('/api/v1/analytics', analyticsService);
mountRoute('/api/v1/modules', moduleCatalogService);

// Enhancement routes
app.use('/api/v1/marketplace', marketplaceEnhancements);
app.use('/api/v1/insurance', insuranceEnhancements);
app.use('/api/v1/farmer-portal', farmerPortalEnhancements);
app.use('/api/v1/governance', governanceModule);
app.use('/api/v1/logistics', logisticsEnhancements);
app.use('/api/v1/advanced', advancedFeatures);

// GraphQL endpoint (if using GraphQL)
if (process.env.ENABLE_GRAPHQL === 'true') {
  const { graphqlHTTP } = require('express-graphql');
  const schema = require('./graphql/schema');
  app.use('/graphql', graphqlHTTP({
    schema: schema,
    graphiql: process.env.NODE_ENV === 'development'
  }));
}

// WebSocket connection handling
io.on('connection', (socket) => {
  logger.info(`Client connected: ${socket.id}`);

  // Join user-specific room for notifications
  socket.on('join', (userId) => {
    socket.join(`user:${userId}`);
    logger.info(`User ${userId} joined their room`);
  });

  // Real-time order updates
  socket.on('subscribe:orders', (orderId) => {
    socket.join(`order:${orderId}`);
  });

  // Real-time shipment tracking
  socket.on('subscribe:shipment', (shipmentId) => {
    socket.join(`shipment:${shipmentId}`);
  });

  socket.on('disconnect', () => {
    logger.info(`Client disconnected: ${socket.id}`);
  });
});

// Export io for use in services
app.set('io', io);

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    error: 'Not Found',
    message: `Route ${req.method} ${req.path} not found`,
    timestamp: new Date().toISOString()
  });
});

// Error handling middleware (must be last)
app.use(errorHandler);

// Start server
const PORT = process.env.PORT || 3001;
httpServer.listen(PORT, () => {
  logger.info(`AFRERA Backend Server running on port ${PORT}`);
  logger.info(`Environment: ${process.env.NODE_ENV || 'development'}`);
  logger.info(`API Gateway: http://localhost:${PORT}/api/v1`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  logger.info('SIGTERM signal received: closing HTTP server');
  httpServer.close(() => {
    logger.info('HTTP server closed');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  logger.info('SIGINT signal received: closing HTTP server');
  httpServer.close(() => {
    logger.info('HTTP server closed');
    process.exit(0);
  });
});

module.exports = { app, io };
