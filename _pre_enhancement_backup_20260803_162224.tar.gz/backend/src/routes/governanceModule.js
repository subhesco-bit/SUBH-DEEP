/**
 * Governance Module Routes
 * API endpoints for Village Management, Panchayat Integration, CSR Tracking, and Compliance
 */

const express = require('express');
const router = express.Router();
const governanceService = require('../services/governanceService');
const authMiddleware = require('../middleware/auth');
const adminMiddleware = require('../middleware/admin');
const { authRateLimit } = require('../middleware/rateLimiter');

// Village Management Routes
router.post('/governance/villages', adminMiddleware, async (req, res) => {
  try {
    const village = await governanceService.createVillage(req.body);
    res.json({ success: true, data: village });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/governance/villages', authMiddleware, async (req, res) => {
  try {
    const villages = await governanceService.getVillages(req.query);
    res.json({ success: true, data: villages });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/governance/villages/:villageId', authMiddleware, async (req, res) => {
  try {
    const { villageId } = req.params;
    const village = await governanceService.getVillage(villageId);
    res.json({ success: true, data: village });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/governance/villages/:villageId', adminMiddleware, async (req, res) => {
  try {
    const { villageId } = req.params;
    const village = await governanceService.updateVillage(villageId, req.body);
    res.json({ success: true, data: village });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Panchayat Integration Routes
router.post('/governance/panchayats', adminMiddleware, async (req, res) => {
  try {
    const panchayat = await governanceService.createPanchayat(req.body);
    res.json({ success: true, data: panchayat });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/governance/panchayats', authMiddleware, async (req, res) => {
  try {
    const panchayats = await governanceService.getPanchayats(req.query);
    res.json({ success: true, data: panchayats });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/governance/panchayats/:panchayatId', authMiddleware, async (req, res) => {
  try {
    const { panchayatId } = req.params;
    const panchayat = await governanceService.getPanchayat(panchayatId);
    res.json({ success: true, data: panchayat });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/governance/panchayats/:panchayatId/schemes', adminMiddleware, async (req, res) => {
  try {
    const { panchayatId } = req.params;
    const scheme = await governanceService.addPanchayatScheme(panchayatId, req.body);
    res.json({ success: true, data: scheme });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// CSR Tracking Routes
router.post('/governance/csr-projects', authRateLimit, authMiddleware, async (req, res) => {
  try {
    const project = await governanceService.createCSRProject(req.body);
    res.json({ success: true, data: project });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/governance/csr-projects', authMiddleware, async (req, res) => {
  try {
    const projects = await governanceService.getCSRProjects(req.query);
    res.json({ success: true, data: projects });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/governance/csr-projects/:projectId', authMiddleware, async (req, res) => {
  try {
    const { projectId } = req.params;
    const project = await governanceService.getCSRProject(projectId);
    res.json({ success: true, data: project });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/governance/csr-projects/:projectId', authRateLimit, authMiddleware, async (req, res) => {
  try {
    const { projectId } = req.params;
    const project = await governanceService.updateCSRProject(projectId, req.body);
    res.json({ success: true, data: project });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/governance/csr-projects/:projectId/contributions', authRateLimit, authMiddleware, async (req, res) => {
  try {
    const { projectId } = req.params;
    const contribution = await governanceService.addCSRContribution(projectId, req.user.id, req.body);
    res.json({ success: true, data: contribution });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/governance/csr/statistics', adminMiddleware, async (req, res) => {
  try {
    const stats = await governanceService.getCSRStatistics(req.query);
    res.json({ success: true, data: stats });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Compliance Routes
router.post('/governance/compliance-reports', authRateLimit, authMiddleware, async (req, res) => {
  try {
    const report = await governanceService.createComplianceReport(req.body);
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/governance/compliance-reports', authMiddleware, async (req, res) => {
  try {
    const reports = await governanceService.getComplianceReports(req.query);
    res.json({ success: true, data: reports });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/governance/compliance-reports/:reportId', authMiddleware, async (req, res) => {
  try {
    const { reportId } = req.params;
    const report = await governanceService.getComplianceReport(reportId);
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/governance/compliance-reports/:reportId/review', adminMiddleware, async (req, res) => {
  try {
    const { reportId } = req.params;
    const report = await governanceService.reviewComplianceReport(reportId, req.user.id, req.body);
    res.json({ success: true, data: report });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/governance/compliance/statistics', adminMiddleware, async (req, res) => {
  try {
    const stats = await governanceService.getComplianceStatistics(req.query);
    res.json({ success: true, data: stats });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Cooperative Management Routes
router.post('/governance/cooperatives', adminMiddleware, async (req, res) => {
  try {
    const cooperative = await governanceService.createCooperative(req.body);
    res.json({ success: true, data: cooperative });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/governance/cooperatives', authMiddleware, async (req, res) => {
  try {
    const cooperatives = await governanceService.getCooperatives(req.query);
    res.json({ success: true, data: cooperatives });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/governance/cooperatives/:cooperativeId/members', authRateLimit, authMiddleware, async (req, res) => {
  try {
    const { cooperativeId } = req.params;
    const membership = await governanceService.addCooperativeMember(cooperativeId, req.user.id, req.body);
    res.json({ success: true, data: membership });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
