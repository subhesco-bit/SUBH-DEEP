/**
 * Logistics Enhancement Routes
 * API endpoints for Fleet Management, Real-time Tracking, Temperature Monitoring, and Warehouse Integration
 */

const express = require('express');
const router = express.Router();
const logisticsEnhancementService = require('../services/logisticsEnhancementService');
const authMiddleware = require('../middleware/auth');
const adminMiddleware = require('../middleware/admin');
const { authRateLimit } = require('../middleware/rateLimiter');

// Fleet Management Routes
router.post('/logistics/fleet', adminMiddleware, async (req, res) => {
  try {
    const vehicle = await logisticsEnhancementService.addVehicle(req.body);
    res.json({ success: true, data: vehicle });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/logistics/fleet', authMiddleware, async (req, res) => {
  try {
    const fleet = await logisticsEnhancementService.getFleet(req.query);
    res.json({ success: true, data: fleet });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/logistics/fleet/:vehicleId', authMiddleware, async (req, res) => {
  try {
    const { vehicleId } = req.params;
    const vehicle = await logisticsEnhancementService.getVehicle(vehicleId);
    res.json({ success: true, data: vehicle });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/logistics/fleet/:vehicleId', adminMiddleware, async (req, res) => {
  try {
    const { vehicleId } = req.params;
    const vehicle = await logisticsEnhancementService.updateVehicle(vehicleId, req.body);
    res.json({ success: true, data: vehicle });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/logistics/fleet/:vehicleId/maintenance', adminMiddleware, async (req, res) => {
  try {
    const { vehicleId } = req.params;
    const maintenance = await logisticsEnhancementService.scheduleMaintenance(vehicleId, req.body);
    res.json({ success: true, data: maintenance });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Real-time Tracking Routes
router.post('/logistics/shipments/:shipmentId/tracking', authRateLimit, authMiddleware, async (req, res) => {
  try {
    const { shipmentId } = req.params;
    const tracking = await logisticsEnhancementService.updateTracking(shipmentId, req.body);
    res.json({ success: true, data: tracking });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/logistics/shipments/:shipmentId/tracking', authMiddleware, async (req, res) => {
  try {
    const { shipmentId } = req.params;
    const tracking = await logisticsEnhancementService.getTracking(shipmentId);
    res.json({ success: true, data: tracking });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/logistics/shipments/:shipmentId/live-tracking', authMiddleware, async (req, res) => {
  try {
    const { shipmentId } = req.params;
    const liveTracking = await logisticsEnhancementService.getLiveTracking(shipmentId);
    res.json({ success: true, data: liveTracking });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/logistics/shipments/:shipmentId/geofence', adminMiddleware, async (req, res) => {
  try {
    const { shipmentId } = req.params;
    const geofence = await logisticsEnhancementService.setGeofence(shipmentId, req.body);
    res.json({ success: true, data: geofence });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Temperature Monitoring Routes
router.post('/logistics/shipments/:shipmentId/temperature', authRateLimit, authMiddleware, async (req, res) => {
  try {
    const { shipmentId } = req.params;
    const temperature = await logisticsEnhancementService.recordTemperature(shipmentId, req.body);
    res.json({ success: true, data: temperature });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/logistics/shipments/:shipmentId/temperature', authMiddleware, async (req, res) => {
  try {
    const { shipmentId } = req.params;
    const temperatureData = await logisticsEnhancementService.getTemperatureData(shipmentId, req.query);
    res.json({ success: true, data: temperatureData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/logistics/shipments/:shipmentId/temperature-alerts', adminMiddleware, async (req, res) => {
  try {
    const { shipmentId } = req.params;
    const alert = await logisticsEnhancementService.setTemperatureAlert(shipmentId, req.body);
    res.json({ success: true, data: alert });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/logistics/shipments/:shipmentId/temperature-alerts', authMiddleware, async (req, res) => {
  try {
    const { shipmentId } = req.params;
    const alerts = await logisticsEnhancementService.getTemperatureAlerts(shipmentId);
    res.json({ success: true, data: alerts });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Warehouse Integration Routes
router.post('/logistics/warehouses', adminMiddleware, async (req, res) => {
  try {
    const warehouse = await logisticsEnhancementService.createWarehouse(req.body);
    res.json({ success: true, data: warehouse });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/logistics/warehouses', authMiddleware, async (req, res) => {
  try {
    const warehouses = await logisticsEnhancementService.getWarehouses(req.query);
    res.json({ success: true, data: warehouses });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/logistics/warehouses/:warehouseId', authMiddleware, async (req, res) => {
  try {
    const { warehouseId } = req.params;
    const warehouse = await logisticsEnhancementService.getWarehouse(warehouseId);
    res.json({ success: true, data: warehouse });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/logistics/warehouses/:warehouseId/inventory', authRateLimit, adminMiddleware, async (req, res) => {
  try {
    const { warehouseId } = req.params;
    const inventory = await logisticsEnhancementService.addInventory(warehouseId, req.body);
    res.json({ success: true, data: inventory });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/logistics/warehouses/:warehouseId/inventory', authMiddleware, async (req, res) => {
  try {
    const { warehouseId } = req.params;
    const inventory = await logisticsEnhancementService.getWarehouseInventory(warehouseId);
    res.json({ success: true, data: inventory });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/logistics/warehouses/:warehouseId/shipments', authRateLimit, adminMiddleware, async (req, res) => {
  try {
    const { warehouseId } = req.params;
    const shipment = await logisticsEnhancementService.processWarehouseShipment(warehouseId, req.body);
    res.json({ success: true, data: shipment });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/logistics/statistics', adminMiddleware, async (req, res) => {
  try {
    const stats = await logisticsEnhancementService.getLogisticsStatistics(req.query);
    res.json({ success: true, data: stats });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
