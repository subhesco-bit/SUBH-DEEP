/**
 * AR/VR Experience Service
 * Manages augmented reality and virtual reality experiences
 */

const express = require('express');
const { Pool } = require('pg');
const { logger } = require('../utils/logger');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();
const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

// ============================================================================
// AR/VR EXPERIENCES
// ============================================================================

/**
 * Create AR/VR experience
 */
async function createExperience(data) {
  const {
    experience_name,
    experience_type,
    experience_category,
    description,
    target_entity_id,
    target_entity_type,
    thumbnail_url,
    experience_data,
    platform_requirements
  } = data;

  try {
    const result = await pool.query(
      `INSERT INTO ar_vr_experiences 
       (experience_name, experience_type, experience_category, description, target_entity_id, 
        target_entity_type, thumbnail_url, experience_data, platform_requirements, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
       RETURNING *`,
      [
        experience_name,
        experience_type,
        experience_category,
        description,
        target_entity_id,
        target_entity_type,
        thumbnail_url,
        JSON.stringify(experience_data),
        JSON.stringify(platform_requirements),
        data.created_by
      ]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Create experience error:', error);
    throw error;
  }
}

/**
 * API endpoint to create experience
 */
router.post('/experiences', authMiddleware, async (req, res) => {
  try {
    const result = await createExperience({
      ...req.body,
      created_by: req.user.id
    });
    res.status(201).json(result);
  } catch (error) {
    logger.error('Create experience API error:', error);
    res.status(500).json({ error: 'Failed to create experience' });
  }
});

/**
 * Get experiences
 */
async function getExperiences(filters = {}) {
  try {
    let query = 'SELECT * FROM ar_vr_experiences WHERE is_published = true';
    const params = [];

    if (filters.experience_type) {
      query += ' AND experience_type = $' + (params.length + 1);
      params.push(filters.experience_type);
    }

    if (filters.experience_category) {
      query += ' AND experience_category = $' + (params.length + 1);
      params.push(filters.experience_category);
    }

    if (filters.target_entity_id && filters.target_entity_type) {
      query += ' AND target_entity_id = $' + (params.length + 1) + ' AND target_entity_type = $' + (params.length + 2);
      params.push(filters.target_entity_id, filters.target_entity_type);
    }

    query += ' ORDER BY created_at DESC';

    const result = await pool.query(query, params);
    return result.rows;
  } catch (error) {
    logger.error('Get experiences error:', error);
    throw error;
  }
}

/**
 * API endpoint to get experiences
 */
router.get('/experiences', async (req, res) => {
  try {
    const { experience_type, experience_category, target_entity_id, target_entity_type } = req.query;
    const result = await getExperiences({ experience_type, experience_category, target_entity_id, target_entity_type });
    res.json(result);
  } catch (error) {
    logger.error('Get experiences API error:', error);
    res.status(500).json({ error: 'Failed to get experiences' });
  }
});

/**
 * Publish experience
 */
async function publishExperience(experienceId) {
  try {
    const result = await pool.query(
      'UPDATE ar_vr_experiences SET is_published = true, updated_at = CURRENT_TIMESTAMP WHERE id = $1 RETURNING *',
      [experienceId]
    );

    if (result.rows.length === 0) {
      throw new Error('Experience not found');
    }

    return result.rows[0];
  } catch (error) {
    logger.error('Publish experience error:', error);
    throw error;
  }
}

/**
 * API endpoint to publish experience
 */
router.patch('/experiences/:experienceId/publish', authMiddleware, async (req, res) => {
  try {
    const result = await publishExperience(req.params.experienceId);
    res.json(result);
  } catch (error) {
    logger.error('Publish experience API error:', error);
    res.status(500).json({ error: 'Failed to publish experience' });
  }
});

// ============================================================================
// 3D ASSETS
// ============================================================================

/**
 * Create 3D asset
 */
async function createAsset(data) {
  const {
    asset_name,
    asset_type,
    asset_format,
    file_url,
    file_size_bytes,
    thumbnail_url,
    metadata
  } = data;

  try {
    const result = await pool.query(
      `INSERT INTO ar_vr_assets 
       (asset_name, asset_type, asset_format, file_url, file_size_bytes, thumbnail_url, metadata, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING *`,
      [
        asset_name,
        asset_type,
        asset_format,
        file_url,
        file_size_bytes,
        thumbnail_url,
        JSON.stringify(metadata),
        data.created_by
      ]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Create asset error:', error);
    throw error;
  }
}

/**
 * API endpoint to create asset
 */
router.post('/assets', authMiddleware, async (req, res) => {
  try {
    const result = await createAsset({
      ...req.body,
      created_by: req.user.id
    });
    res.status(201).json(result);
  } catch (error) {
    logger.error('Create asset API error:', error);
    res.status(500).json({ error: 'Failed to create asset' });
  }
});

/**
 * Get assets
 */
async function getAssets(assetType = null) {
  try {
    let query = 'SELECT * FROM ar_vr_assets WHERE 1=1';
    const params = [];

    if (assetType) {
      query += ' AND asset_type = $1';
      params.push(assetType);
    }

    query += ' ORDER BY created_at DESC';

    const result = await pool.query(query, params);
    return result.rows;
  } catch (error) {
    logger.error('Get assets error:', error);
    throw error;
  }
}

/**
 * API endpoint to get assets
 */
router.get('/assets', authMiddleware, async (req, res) => {
  try {
    const { asset_type } = req.query;
    const result = await getAssets(asset_type);
    res.json(result);
  } catch (error) {
    logger.error('Get assets API error:', error);
    res.status(500).json({ error: 'Failed to get assets' });
  }
});

// ============================================================================
// INTERACTION POINTS
// ============================================================================

/**
 * Create interaction point
 */
async function createInteractionPoint(data) {
  const {
    experience_id,
    point_name,
    point_type,
    position_x,
    position_y,
    position_z,
    interaction_data
  } = data;

  try {
    const result = await pool.query(
      `INSERT INTO interaction_points 
       (experience_id, point_name, point_type, position_x, position_y, position_z, interaction_data)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING *`,
      [
        experience_id,
        point_name,
        point_type,
        position_x,
        position_y,
        position_z,
        JSON.stringify(interaction_data)
      ]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Create interaction point error:', error);
    throw error;
  }
}

/**
 * API endpoint to create interaction point
 */
router.post('/interaction-points', authMiddleware, async (req, res) => {
  try {
    const result = await createInteractionPoint(req.body);
    res.status(201).json(result);
  } catch (error) {
    logger.error('Create interaction point API error:', error);
    res.status(500).json({ error: 'Failed to create interaction point' });
  }
});

/**
 * Get interaction points for experience
 */
async function getInteractionPoints(experienceId) {
  try {
    const result = await pool.query(
      'SELECT * FROM interaction_points WHERE experience_id = $1 AND is_active = true ORDER BY created_at ASC',
      [experienceId]
    );

    return result.rows;
  } catch (error) {
    logger.error('Get interaction points error:', error);
    throw error;
  }
}

/**
 * API endpoint to get interaction points
 */
router.get('/experiences/:experienceId/interaction-points', async (req, res) => {
  try {
    const result = await getInteractionPoints(req.params.experienceId);
    res.json(result);
  } catch (error) {
    logger.error('Get interaction points API error:', error);
    res.status(500).json({ error: 'Failed to get interaction points' });
  }
});

// ============================================================================
// USER SESSIONS
// ============================================================================

/**
 * Create AR/VR session
 */
async function createSession(data) {
  const {
    user_id,
    experience_id,
    session_type,
    device_type,
    session_data
  } = data;

  try {
    const result = await pool.query(
      `INSERT INTO ar_vr_sessions 
       (user_id, experience_id, session_type, device_type, session_data)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [user_id, experience_id, session_type, device_type, JSON.stringify(session_data)]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Create session error:', error);
    throw error;
  }
}

/**
 * API endpoint to create session
 */
router.post('/sessions', authMiddleware, async (req, res) => {
  try {
    const result = await createSession({
      ...req.body,
      user_id: req.user.id
    });
    res.status(201).json(result);
  } catch (error) {
    logger.error('Create session API error:', error);
    res.status(500).json({ error: 'Failed to create session' });
  }
});

/**
 * End session
 */
async function endSession(sessionId, interactionCount) {
  try {
    const result = await pool.query(
      `UPDATE ar_vr_sessions 
       SET ended_at = CURRENT_TIMESTAMP, 
           duration_seconds = calculate_session_duration(id),
           interaction_count = $1
       WHERE id = $2
       RETURNING *`,
      [interactionCount || 0, sessionId]
    );

    if (result.rows.length === 0) {
      throw new Error('Session not found');
    }

    return result.rows[0];
  } catch (error) {
    logger.error('End session error:', error);
    throw error;
  }
}

/**
 * API endpoint to end session
 */
router.patch('/sessions/:sessionId/end', authMiddleware, async (req, res) => {
  try {
    const { interaction_count } = req.body;
    const result = await endSession(req.params.sessionId, interaction_count);
    res.json(result);
  } catch (error) {
    logger.error('End session API error:', error);
    res.status(500).json({ error: 'Failed to end session' });
  }
});

// ============================================================================
// AR/VR ANALYTICS
// ============================================================================

/**
 * Record AR/VR analytics
 */
async function recordArVrAnalytics(metrics) {
  try {
    const result = await pool.query(
      `INSERT INTO ar_vr_analytics 
       (date, total_sessions, unique_users, average_session_duration, total_interactions, 
        most_viewed_experiences, device_distribution)
       VALUES (CURRENT_DATE, $1, $2, $3, $4, $5, $6)
       ON CONFLICT (date)
       DO UPDATE SET
         total_sessions = ar_vr_analytics.total_sessions + EXCLUDED.total_sessions,
         total_interactions = ar_vr_analytics.total_interactions + EXCLUDED.total_interactions
       RETURNING *`,
      [
        metrics.total_sessions || 0,
        metrics.unique_users || 0,
        metrics.avg_duration || 0,
        metrics.total_interactions || 0,
        JSON.stringify(metrics.most_viewed || {}),
        JSON.stringify(metrics.device_distribution || {})
      ]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Record AR/VR analytics error:', error);
    throw error;
  }
}

/**
 * API endpoint to record AR/VR analytics
 */
router.post('/ar-vr-analytics', authMiddleware, async (req, res) => {
  try {
    const { metrics } = req.body;
    const result = await recordArVrAnalytics(metrics);
    res.json(result);
  } catch (error) {
    logger.error('Record AR/VR analytics API error:', error);
    res.status(500).json({ error: 'Failed to record AR/VR analytics' });
  }
});

// ============================================================================
// HEALTH CHECK
// ============================================================================

function isHealthy() {
  return pool.connect().then(() => true).catch(() => false);
}

module.exports = {
  router,
  createExperience,
  getExperiences,
  publishExperience,
  createAsset,
  getAssets,
  createInteractionPoint,
  getInteractionPoints,
  createSession,
  endSession,
  recordArVrAnalytics,
  isHealthy
};
