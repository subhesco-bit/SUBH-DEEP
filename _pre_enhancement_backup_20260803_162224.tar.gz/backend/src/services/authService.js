/**
 * Authentication Service
 * Provides comprehensive authentication and authorization with JWT, OAuth2, and MFA
 */

const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const fs = require('fs');
const path = require('path');
const { logger } = require('../utils/logger');
const { getPostgreSQL } = require('../database/connection');

// JWT Configuration
const JWT_CONFIG = {
  secret: process.env.JWT_SECRET || 'your-super-secret-key-change-in-production',
  accessTokenExpiry: process.env.JWT_ACCESS_EXPIRY || '15m',
  refreshTokenExpiry: process.env.JWT_REFRESH_EXPIRY || '7d',
  issuer: process.env.JWT_ISSUER || 'afrera-platform',
  audience: process.env.JWT_AUDIENCE || 'afrera-users'
};

// OAuth2 Configuration
const OAUTH_PROVIDERS = {
  google: {
    enabled: process.env.GOOGLE_OAUTH_ENABLED === 'true',
    clientId: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    redirectUri: process.env.GOOGLE_REDIRECT_URI
  },
  facebook: {
    enabled: process.env.FACEBOOK_OAUTH_ENABLED === 'true',
    clientId: process.env.FACEBOOK_CLIENT_ID,
    clientSecret: process.env.FACEBOOK_CLIENT_SECRET,
    redirectUri: process.env.FACEBOOK_REDIRECT_URI
  }
};

const AUTH_STORE_PATH = path.join(__dirname, '..', 'database', 'auth_store.json');

function ensureAuthStore() {
  return {
    users: []
  };
}

function readAuthStore() {
  try {
    if (!fs.existsSync(AUTH_STORE_PATH)) {
      fs.writeFileSync(AUTH_STORE_PATH, JSON.stringify(ensureAuthStore(), null, 2));
      return ensureAuthStore();
    }

    const raw = fs.readFileSync(AUTH_STORE_PATH, 'utf8');
    const parsed = JSON.parse(raw);
    return {
      users: Array.isArray(parsed.users) ? parsed.users : []
    };
  } catch (error) {
    logger.warn('Unable to read auth store, resetting it:', error.message);
    return ensureAuthStore();
  }
}

function writeAuthStore(store) {
  try {
    fs.writeFileSync(AUTH_STORE_PATH, JSON.stringify(store, null, 2));
    return true;
  } catch (error) {
    logger.error('Unable to persist auth store:', error);
    return false;
  }
}

function getFallbackUserByEmail(email) {
  const store = readAuthStore();
  return store.users.find((user) => user.email === email.toLowerCase());
}

/**
 * Generate access token
 */
function generateAccessToken(user) {
  const payload = {
    userId: user.id,
    email: user.email,
    role: user.role,
    permissions: getUserPermissions(user.role)
  };

  return jwt.sign(payload, JWT_CONFIG.secret, {
    expiresIn: JWT_CONFIG.accessTokenExpiry,
    issuer: JWT_CONFIG.issuer,
    audience: JWT_CONFIG.audience,
    subject: user.id.toString()
  });
}

/**
 * Generate refresh token
 */
function generateRefreshToken(user) {
  const payload = {
    userId: user.id,
    tokenType: 'refresh'
  };

  return jwt.sign(payload, JWT_CONFIG.secret, {
    expiresIn: JWT_CONFIG.refreshTokenExpiry,
    issuer: JWT_CONFIG.issuer,
    audience: JWT_CONFIG.audience,
    subject: user.id.toString()
  });
}

/**
 * Verify JWT token
 */
function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_CONFIG.secret, {
      issuer: JWT_CONFIG.issuer,
      audience: JWT_CONFIG.audience
    });
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      throw new Error('Token expired');
    } else if (error.name === 'JsonWebTokenError') {
      throw new Error('Invalid token');
    } else {
      throw new Error('Token verification failed');
    }
  }
}

/**
 * Hash password
 */
async function hashPassword(password) {
  const salt = await bcrypt.genSalt(12);
  return bcrypt.hash(password, salt);
}

/**
 * Compare password with hash
 */
async function comparePassword(password, hash) {
  return bcrypt.compare(password, hash);
}

/**
 * Get user permissions based on role
 */
function getUserPermissions(role) {
  const permissions = {
    admin: ['*'],
    farmer: [
      'marketplace:read',
      'marketplace:buy',
      'farmer:read',
      'farmer:update',
      'orders:read',
      'orders:create',
      'contracts:read',
      'contracts:create'
    ],
    fpo: [
      'marketplace:read',
      'marketplace:buy',
      'farmer:read',
      'farmer:update',
      'fpo:read',
      'fpo:update',
      'orders:read',
      'orders:manage',
      'contracts:read',
      'contracts:create',
      'contracts:approve'
    ],
    corporate: [
      'marketplace:read',
      'marketplace:buy',
      'orders:read',
      'orders:create',
      'procurement:read',
      'procurement:create',
      'contracts:read',
      'contracts:create',
      'contracts:approve'
    ],
    consumer: [
      'marketplace:read',
      'marketplace:buy',
      'orders:read',
      'orders:create'
    ],
    logistics: [
      'logistics:read',
      'logistics:update',
      'shipments:read',
      'shipments:update',
      'vehicles:read',
      'drivers:read'
    ],
    horeca: [
      'marketplace:read',
      'marketplace:buy',
      'orders:read',
      'orders:create',
      'procurement:read'
    ]
  };

  return permissions[role] || [];
}

/**
 * Check if user has permission
 */
function hasPermission(userPermissions, requiredPermission) {
  if (userPermissions.includes('*')) return true;
  return userPermissions.includes(requiredPermission);
}

/**
 * Register new user
 */
async function registerUser(userData) {
  try {
    const pg = getPostgreSQL();

    if (!pg) {
      const store = readAuthStore();
      const normalizedEmail = (userData.email || '').toLowerCase();
      if (store.users.some((entry) => entry.email === normalizedEmail)) {
        throw new Error('Email already registered');
      }

      const passwordHash = await hashPassword(userData.password);
      const user = {
        id: `user-${Date.now()}`,
        email: normalizedEmail,
        phone: userData.phone || '',
        role: userData.role || 'consumer',
        status: userData.status || 'active',
        password_hash: passwordHash,
        first_name: userData.first_name || '',
        last_name: userData.last_name || '',
        created_at: new Date().toISOString()
      };

      store.users.push(user);
      writeAuthStore(store);

      const accessToken = generateAccessToken(user);
      const refreshToken = generateRefreshToken(user);

      logger.info(`User registered in fallback mode: ${user.email} (${user.role})`);

      return {
        user: {
          id: user.id,
          email: user.email,
          phone: user.phone,
          role: user.role,
          status: user.status,
          profile: {
            first_name: user.first_name,
            last_name: user.last_name,
            phone: user.phone
          }
        },
        accessToken,
        refreshToken,
        expiresIn: JWT_CONFIG.accessTokenExpiry
      };
    }
    
    // Check if email already exists
    const existingUser = await pg.query(
      'SELECT id FROM users WHERE email = $1',
      [userData.email.toLowerCase()]
    );
    
    if (existingUser.rows.length > 0) {
      throw new Error('Email already registered');
    }
    
    // Check if phone already exists
    if (userData.phone) {
      const existingPhone = await pg.query(
        'SELECT id FROM users WHERE phone = $1',
        [userData.phone]
      );
      
      if (existingPhone.rows.length > 0) {
        throw new Error('Phone number already registered');
      }
    }
    
    // Hash password
    const passwordHash = await hashPassword(userData.password);
    
    // Insert user
    const userQuery = `
      INSERT INTO users (email, phone, password_hash, role, status)
      VALUES ($1, $2, $3, $4, $5)
      RETURNING id, email, phone, role, status, created_at
    `;
    
    const userResult = await pg.query(userQuery, [
      userData.email.toLowerCase(),
      userData.phone || null,
      passwordHash,
      userData.role || 'consumer',
      userData.status || 'active'
    ]);
    
    const user = userResult.rows[0];
    
    // Insert user profile
    const profileQuery = `
      INSERT INTO user_profiles (user_id, first_name, last_name, phone)
      VALUES ($1, $2, $3, $4)
      RETURNING *
    `;
    
    const profileResult = await pg.query(profileQuery, [
      user.id,
      userData.first_name || '',
      userData.last_name || '',
      userData.phone || ''
    ]);
    
    // Generate tokens
    const accessToken = generateAccessToken(user);
    const refreshToken = generateRefreshToken(user);
    
    logger.info(`User registered: ${user.email} (${user.role})`);
    
    return {
      user: {
        id: user.id,
        email: user.email,
        phone: user.phone,
        role: user.role,
        status: user.status,
        profile: profileResult.rows[0]
      },
      accessToken,
      refreshToken,
      expiresIn: JWT_CONFIG.accessTokenExpiry
    };
  } catch (error) {
    logger.error('User registration failed:', error);
    throw error;
  }
}

/**
 * Login user
 */
async function loginUser(email, password, deviceInfo = {}) {
  try {
    const pg = getPostgreSQL();

    if (!pg) {
      const user = getFallbackUserByEmail(email);
      if (!user) {
        throw new Error('Invalid credentials');
      }

      const passwordValid = await comparePassword(password, user.password_hash);
      if (!passwordValid) {
        throw new Error('Invalid credentials');
      }

      const accessToken = generateAccessToken(user);
      const refreshToken = generateRefreshToken(user);

      logger.info(`User logged in in fallback mode: ${user.email} (${user.role})`);

      return {
        user: {
          id: user.id,
          email: user.email,
          phone: user.phone,
          role: user.role,
          status: user.status,
          firstName: user.first_name,
          lastName: user.last_name,
          profileImage: user.profile_image_url,
          permissions: getUserPermissions(user.role)
        },
        accessToken,
        refreshToken,
        expiresIn: JWT_CONFIG.accessTokenExpiry
      };
    }
    
    // Get user by email
    const userQuery = `
      SELECT u.*, up.first_name, up.last_name, up.profile_image_url
      FROM users u
      LEFT JOIN user_profiles up ON u.id = up.user_id
      WHERE u.email = $1
    `;
    
    const userResult = await pg.query(userQuery, [email.toLowerCase()]);
    
    if (userResult.rows.length === 0) {
      throw new Error('Invalid credentials');
    }
    
    const user = userResult.rows[0];
    
    // Check if account is locked
    if (user.locked_until && new Date(user.locked_until) > new Date()) {
      throw new Error('Account temporarily locked due to multiple failed attempts');
    }
    
    // Check if account is active
    if (user.status !== 'active') {
      throw new Error('Account is not active');
    }
    
    // Verify password
    const passwordValid = await comparePassword(password, user.password_hash);
    
    if (!passwordValid) {
      // Increment failed login attempts
      const failedAttempts = (user.failed_login_attempts || 0) + 1;
      
      if (failedAttempts >= 5) {
        // Lock account for 30 minutes
        const lockedUntil = new Date(Date.now() + 30 * 60 * 1000);
        await pg.query(
          'UPDATE users SET failed_login_attempts = $1, locked_until = $2 WHERE id = $3',
          [failedAttempts, lockedUntil, user.id]
        );
        throw new Error('Account locked due to multiple failed attempts');
      } else {
        await pg.query(
          'UPDATE users SET failed_login_attempts = $1 WHERE id = $2',
          [failedAttempts, user.id]
        );
      }
      
      throw new Error('Invalid credentials');
    }
    
    // Reset failed login attempts
    await pg.query(
      'UPDATE users SET failed_login_attempts = 0, last_login_at = NOW() WHERE id = $1',
      [user.id]
    );
    
    // Generate tokens
    const accessToken = generateAccessToken(user);
    const refreshToken = generateRefreshToken(user);
    
    // Store refresh token in database (optional, for revocation)
    await storeRefreshToken(user.id, refreshToken, deviceInfo);
    
    logger.info(`User logged in: ${user.email} (${user.role})`);
    
    return {
      user: {
        id: user.id,
        email: user.email,
        phone: user.phone,
        role: user.role,
        status: user.status,
        firstName: user.first_name,
        lastName: user.last_name,
        profileImage: user.profile_image_url,
        permissions: getUserPermissions(user.role)
      },
      accessToken,
      refreshToken,
      expiresIn: JWT_CONFIG.accessTokenExpiry
    };
  } catch (error) {
    logger.error('User login failed:', error);
    throw error;
  }
}

/**
 * Refresh access token
 */
async function refreshAccessToken(refreshToken) {
  try {
    // Verify refresh token
    const payload = verifyToken(refreshToken);
    
    if (payload.tokenType !== 'refresh') {
      throw new Error('Invalid refresh token');
    }

    const pg = getPostgreSQL();
    if (!pg) {
      const user = getFallbackUserByEmail(payload.email || '');
      if (!user) {
        throw new Error('User not found');
      }

      const newAccessToken = generateAccessToken(user);
      const newRefreshToken = generateRefreshToken(user);
      return {
        accessToken: newAccessToken,
        refreshToken: newRefreshToken,
        expiresIn: JWT_CONFIG.accessTokenExpiry
      };
    }
    
    // Check if refresh token exists and is valid
    const tokenQuery = `
      SELECT * FROM refresh_tokens
      WHERE user_id = $1 AND token = $2 AND revoked = FALSE
      ORDER BY created_at DESC
      LIMIT 1
    `;
    
    const tokenResult = await pg.query(tokenQuery, [payload.userId, refreshToken]);
    
    if (tokenResult.rows.length === 0) {
      throw new Error('Invalid or expired refresh token');
    }
    
    // Get user
    const userQuery = `
      SELECT u.*, up.first_name, up.last_name
      FROM users u
      LEFT JOIN user_profiles up ON u.id = up.user_id
      WHERE u.id = $1
    `;
    
    const userResult = await pg.query(userQuery, [payload.userId]);
    const user = userResult.rows[0];
    
    if (!user || user.status !== 'active') {
      throw new Error('User not found or inactive');
    }
    
    // Generate new tokens
    const newAccessToken = generateAccessToken(user);
    const newRefreshToken = generateRefreshToken(user);
    
    // Revoke old refresh token
    await revokeRefreshToken(refreshToken);
    
    // Store new refresh token
    await storeRefreshToken(user.id, newRefreshToken);
    
    logger.info(`Token refreshed for user: ${user.email}`);
    
    return {
      accessToken: newAccessToken,
      refreshToken: newRefreshToken,
      expiresIn: JWT_CONFIG.accessTokenExpiry
    };
  } catch (error) {
    logger.error('Token refresh failed:', error);
    throw error;
  }
}

/**
 * Logout user
 */
async function logoutUser(userId, refreshToken) {
  try {
    const pg = getPostgreSQL();
    if (!pg) {
      logger.info(`User logged out in fallback mode: ${userId}`);
      return { success: true, message: 'Logged out successfully' };
    }
    
    // Revoke refresh token
    if (refreshToken) {
      await revokeRefreshToken(refreshToken);
    }
    
    // Revoke all refresh tokens for user (optional, for complete logout)
    await pg.query(
      'UPDATE refresh_tokens SET revoked = TRUE WHERE user_id = $1',
      [userId]
    );
    
    logger.info(`User logged out: ${userId}`);
    
    return { success: true, message: 'Logged out successfully' };
  } catch (error) {
    logger.error('User logout failed:', error);
    throw error;
  }
}

/**
 * Store refresh token
 */
async function storeRefreshToken(userId, token, deviceInfo = {}) {
  try {
    const pg = getPostgreSQL();
    
    const query = `
      INSERT INTO refresh_tokens (user_id, token, device_info, expires_at)
      VALUES ($1, $2, $3, NOW() + INTERVAL '7 days')
      RETURNING id
    `;
    
    await pg.query(query, [userId, token, JSON.stringify(deviceInfo)]);
  } catch (error) {
    logger.error('Failed to store refresh token:', error);
    // Don't throw error, as this is not critical
  }
}

/**
 * Revoke refresh token
 */
async function revokeRefreshToken(token) {
  try {
    const pg = getPostgreSQL();
    
    await pg.query(
      'UPDATE refresh_tokens SET revoked = TRUE WHERE token = $1',
      [token]
    );
  } catch (error) {
    logger.error('Failed to revoke refresh token:', error);
  }
}

/**
 * Setup Two-Factor Authentication
 */
async function setupTwoFactor(userId) {
  try {
    const pg = getPostgreSQL();
    
    // Generate secret (in production, use speakeasy or similar library)
    const secret = generateTOTPSecret();
    
    // Store secret
    await pg.query(
      'UPDATE users SET two_factor_secret = $1, two_factor_enabled = FALSE WHERE id = $2',
      [secret, userId]
    );
    
    // Generate QR code (in production, use qrcode library)
    const qrCode = generateQRCode(secret, userId);
    
    return {
      secret,
      qrCode,
      backupCodes: generateBackupCodes()
    };
  } catch (error) {
    logger.error('2FA setup failed:', error);
    throw error;
  }
}

/**
 * Verify Two-Factor Authentication code
 */
async function verifyTwoFactor(userId, code) {
  try {
    const pg = getPostgreSQL();
    
    // Get user's 2FA secret
    const userResult = await pg.query(
      'SELECT two_factor_secret FROM users WHERE id = $1',
      [userId]
    );
    
    if (userResult.rows.length === 0 || !userResult.rows[0].two_factor_secret) {
      throw new Error('2FA not set up for user');
    }
    
    const secret = userResult.rows[0].two_factor_secret;
    
    // Verify TOTP code (in production, use speakeasy or similar library)
    const isValid = verifyTOTPCode(secret, code);
    
    if (!isValid) {
      throw new Error('Invalid 2FA code');
    }
    
    // Enable 2FA
    await pg.query(
      'UPDATE users SET two_factor_enabled = TRUE WHERE id = $1',
      [userId]
    );
    
    logger.info(`2FA enabled for user: ${userId}`);
    
    return { success: true, message: '2FA enabled successfully' };
  } catch (error) {
    logger.error('2FA verification failed:', error);
    throw error;
  }
}

/**
 * Disable Two-Factor Authentication
 */
async function disableTwoFactor(userId, password) {
  try {
    const pg = getPostgreSQL();
    
    // Verify password
    const userResult = await pg.query(
      'SELECT password_hash FROM users WHERE id = $1',
      [userId]
    );
    
    const passwordValid = await comparePassword(password, userResult.rows[0].password_hash);
    
    if (!passwordValid) {
      throw new Error('Invalid password');
    }
    
    // Disable 2FA
    await pg.query(
      'UPDATE users SET two_factor_enabled = FALSE, two_factor_secret = NULL WHERE id = $1',
      [userId]
    );
    
    logger.info(`2FA disabled for user: ${userId}`);
    
    return { success: true, message: '2FA disabled successfully' };
  } catch (error) {
    logger.error('2FA disable failed:', error);
    throw error;
  }
}

/**
 * OAuth2 authentication
 */
async function oauthAuthenticate(provider, code, redirectUri) {
  try {
    if (!OAUTH_PROVIDERS[provider] || !OAUTH_PROVIDERS[provider].enabled) {
      throw new Error(`${provider} OAuth not enabled`);
    }
    
    // Exchange code for access token
    const tokens = await exchangeOAuthCode(provider, code, redirectUri);
    
    // Get user info from OAuth provider
    const userInfo = await getOAuthUserInfo(provider, tokens.access_token);
    
    // Check if user exists
    const pg = getPostgreSQL();
    const userQuery = 'SELECT * FROM users WHERE email = $1';
    const userResult = await pg.query(userQuery, [userInfo.email]);
    
    let user;
    
    if (userResult.rows.length > 0) {
      // Existing user
      user = userResult.rows[0];
      
      // Update OAuth info
      await pg.query(
        `UPDATE user_profiles 
         SET oauth_provider = $1, oauth_id = $2 
         WHERE user_id = $3`,
        [provider, userInfo.id, user.id]
      );
    } else {
      // Create new user
      const passwordHash = await hashPassword(generateRandomPassword());
      
      const newUserQuery = `
        INSERT INTO users (email, password_hash, role, status, email_verified)
        VALUES ($1, $2, $3, $4, $5)
        RETURNING id, email, role, status
      `;
      
      const newUserResult = await pg.query(newUserQuery, [
        userInfo.email.toLowerCase(),
        passwordHash,
        'consumer',
        'active',
        true
      ]);
      
      user = newUserResult.rows[0];
      
      // Create profile
      await pg.query(
        `INSERT INTO user_profiles (user_id, first_name, last_name, oauth_provider, oauth_id)
         VALUES ($1, $2, $3, $4, $5)`,
        [user.id, userInfo.first_name || '', userInfo.last_name || '', provider, userInfo.id]
      );
    }
    
    // Generate tokens
    const accessToken = generateAccessToken(user);
    const refreshToken = generateRefreshToken(user);
    
    logger.info(`OAuth login: ${user.email} via ${provider}`);
    
    return {
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        status: user.status
      },
      accessToken,
      refreshToken,
      expiresIn: JWT_CONFIG.accessTokenExpiry
    };
  } catch (error) {
    logger.error('OAuth authentication failed:', error);
    throw error;
  }
}

/**
 * Get OAuth authorization URL
 */
function getOAuthAuthUrl(provider, state) {
  const config = OAUTH_PROVIDERS[provider];
  
  if (!config || !config.enabled) {
    throw new Error(`${provider} OAuth not enabled`);
  }
  
  const urls = {
    google: `https://accounts.google.com/o/oauth2/v2/auth?client_id=${config.clientId}&redirect_uri=${encodeURIComponent(config.redirectUri)}&response_type=code&scope=openid email profile&state=${state}`,
    facebook: `https://www.facebook.com/v18.0/dialog/oauth?client_id=${config.clientId}&redirect_uri=${encodeURIComponent(config.redirectUri)}&response_type=code&scope=email&state=${state}`
  };
  
  return urls[provider];
}

/**
 * Helper functions (simplified implementations)
 */
function generateTOTPSecret() {
  // In production, use speakeasy or similar library
  return 'JBSWY3DPEHPK3PXP';
}

function generateQRCode(secret, userId) {
  // In production, use qrcode library
  return `otpauth://totp/AFRERA:${userId}?secret=${secret}&issuer=AFRERA`;
}

function generateBackupCodes() {
  // Generate 10 backup codes
  return Array.from({ length: 10 }, () => 
    Math.random().toString(36).substring(2, 8).toUpperCase()
  );
}

function verifyTOTPCode(secret, code) {
  // In production, use speakeasy or similar library
  return code.length === 6 && /^\d+$/.test(code);
}

function generateRandomPassword() {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

async function exchangeOAuthCode(provider, code, redirectUri) {
  // In production, implement actual OAuth token exchange
  return { access_token: 'mock_access_token', refresh_token: 'mock_refresh_token' };
}

async function getOAuthUserInfo(provider, accessToken) {
  // In production, implement actual user info fetch from OAuth provider
  return {
    id: 'oauth_user_id',
    email: 'oauth@example.com',
    first_name: 'OAuth',
    last_name: 'User'
  };
}

/**
 * Express router for authentication service
 */
const express = require('express');
const router = express.Router();

// Register
router.post('/register', async (req, res) => {
  try {
    const result = await registerUser(req.body);
    res.status(201).json(result);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const { email, password, device_info } = req.body;
    const result = await loginUser(email, password, device_info);
    res.json(result);
  } catch (error) {
    res.status(401).json({ error: error.message });
  }
});

// Refresh token
router.post('/refresh', async (req, res) => {
  try {
    const { refresh_token } = req.body;
    const result = await refreshAccessToken(refresh_token);
    res.json(result);
  } catch (error) {
    res.status(401).json({ error: error.message });
  }
});

// Logout
router.post('/logout', async (req, res) => {
  try {
    const { user_id, refresh_token } = req.body;
    const result = await logoutUser(user_id, refresh_token);
    res.json(result);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Setup 2FA
router.post('/2fa/setup', async (req, res) => {
  try {
    const { user_id } = req.body;
    const result = await setupTwoFactor(user_id);
    res.json(result);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Verify 2FA
router.post('/2fa/verify', async (req, res) => {
  try {
    const { user_id, code } = req.body;
    const result = await verifyTwoFactor(user_id, code);
    res.json(result);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Disable 2FA
router.post('/2fa/disable', async (req, res) => {
  try {
    const { user_id, password } = req.body;
    const result = await disableTwoFactor(user_id, password);
    res.json(result);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// OAuth URL
router.get('/oauth/:provider/url', (req, res) => {
  try {
    const { provider } = req.params;
    const { state } = req.query;
    const url = getOAuthAuthUrl(provider, state);
    res.json({ url });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// OAuth callback
router.post('/oauth/:provider/callback', async (req, res) => {
  try {
    const { provider } = req.params;
    const { code, redirect_uri } = req.body;
    const result = await oauthAuthenticate(provider, code, redirect_uri);
    res.json(result);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Get current user
router.get('/me', async (req, res) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (!token) {
      return res.status(401).json({ error: 'No token provided' });
    }
    
    const payload = verifyToken(token);
    const pg = getPostgreSQL();

    if (!pg) {
      const user = getFallbackUserByEmail(payload.email || '');
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      return res.json({
        user: {
          ...user,
          permissions: getUserPermissions(user.role)
        }
      });
    }
    
    const userQuery = `
      SELECT u.id, u.email, u.phone, u.role, u.status, u.email_verified, u.phone_verified,
             up.first_name, up.last_name, up.profile_image_url, up.kyc_status
      FROM users u
      LEFT JOIN user_profiles up ON u.id = up.user_id
      WHERE u.id = $1
    `;
    
    const userResult = await pg.query(userQuery, [payload.userId]);
    
    if (userResult.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    const user = userResult.rows[0];
    
    res.json({
      user: {
        ...user,
        permissions: getUserPermissions(user.role)
      }
    });
  } catch (error) {
    res.status(401).json({ error: error.message });
  }
});

module.exports = {
  router,
  registerUser,
  loginUser,
  refreshAccessToken,
  logoutUser,
  setupTwoFactor,
  verifyTwoFactor,
  disableTwoFactor,
  oauthAuthenticate,
  getOAuthAuthUrl,
  verifyToken,
  hasPermission,
  generateAccessToken,
  generateRefreshToken
};
