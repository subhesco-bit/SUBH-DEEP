/**
 * Blockchain Traceability Service
 * Manages blockchain-based product traceability and immutable records
 */

const express = require('express');
const { Pool } = require('pg');
const { logger } = require('../utils/logger');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();
const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

// ============================================================================
// BLOCKCHAIN TRANSACTIONS
// ============================================================================

/**
 * Record blockchain transaction
 */
async function recordBlockchainTransaction(data) {
  const {
    transaction_hash,
    block_number,
    block_hash,
    transaction_index,
    from_address,
    to_address,
    gas_used,
    gas_price,
    status,
    metadata
  } = data;

  try {
    const result = await pool.query(
      `INSERT INTO blockchain_transactions 
       (transaction_hash, block_number, block_hash, transaction_index, from_address, to_address, 
        gas_used, gas_price, status, metadata)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
       RETURNING *`,
      [
        transaction_hash,
        block_number,
        block_hash,
        transaction_index,
        from_address,
        to_address,
        gas_used,
        gas_price,
        status,
        JSON.stringify(metadata)
      ]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Record blockchain transaction error:', error);
    throw error;
  }
}

/**
 * API endpoint to record blockchain transaction
 */
router.post('/blockchain-transactions', authMiddleware, async (req, res) => {
  try {
    const result = await recordBlockchainTransaction(req.body);
    res.status(201).json(result);
  } catch (error) {
    logger.error('Record blockchain transaction API error:', error);
    res.status(500).json({ error: 'Failed to record blockchain transaction' });
  }
});

/**
 * Get blockchain transaction
 */
async function getBlockchainTransaction(transactionHash) {
  try {
    const result = await pool.query(
      'SELECT * FROM blockchain_transactions WHERE transaction_hash = $1',
      [transactionHash]
    );

    if (result.rows.length === 0) {
      throw new Error('Transaction not found');
    }

    return result.rows[0];
  } catch (error) {
    logger.error('Get blockchain transaction error:', error);
    throw error;
  }
}

/**
 * API endpoint to get blockchain transaction
 */
router.get('/blockchain-transactions/:hash', async (req, res) => {
  try {
    const result = await getBlockchainTransaction(req.params.hash);
    res.json(result);
  } catch (error) {
    logger.error('Get blockchain transaction API error:', error);
    res.status(404).json({ error: 'Transaction not found' });
  }
});

// ============================================================================
// TRACEABILITY EVENTS
// ============================================================================

/**
 * Record traceability event
 */
async function recordTraceabilityEvent(data) {
  const {
    product_id,
    batch_number,
    event_type,
    location_id,
    actor_id,
    actor_type,
    transaction_hash,
    event_data,
    ipfs_hash
  } = data;

  try {
    const result = await pool.query(
      `INSERT INTO traceability_events 
       (product_id, batch_number, event_type, location_id, actor_id, actor_type, 
        transaction_hash, event_data, ipfs_hash, is_verified)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, true)
       RETURNING *`,
      [
        product_id,
        batch_number,
        event_type,
        location_id,
        actor_id,
        actor_type,
        transaction_hash,
        JSON.stringify(event_data),
        ipfs_hash
      ]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Record traceability event error:', error);
    throw error;
  }
}

/**
 * API endpoint to record traceability event
 */
router.post('/traceability-events', authMiddleware, async (req, res) => {
  try {
    const result = await recordTraceabilityEvent({
      ...req.body,
      actor_id: req.user.id
    });
    res.status(201).json(result);
  } catch (error) {
    logger.error('Record traceability event API error:', error);
    res.status(500).json({ error: 'Failed to record traceability event' });
  }
});

/**
 * Get traceability events for product
 */
async function getTraceabilityEvents(productId, batchNumber = null) {
  try {
    let query = `
      SELECT te.*, u.first_name, u.last_name, a.city, a.state
      FROM traceability_events te
      LEFT JOIN users u ON te.actor_id = u.id
      LEFT JOIN addresses a ON te.location_id = a.id
      WHERE te.product_id = $1
    `;
    const params = [productId];

    if (batchNumber) {
      query += ' AND te.batch_number = $2';
      params.push(batchNumber);
    }

    query += ' ORDER BY te.event_timestamp ASC';

    const result = await pool.query(query, params);
    return result.rows;
  } catch (error) {
    logger.error('Get traceability events error:', error);
    throw error;
  }
}

/**
 * API endpoint to get traceability events
 */
router.get('/traceability-events/:productId', async (req, res) => {
  try {
    const { batch_number } = req.query;
    const result = await getTraceabilityEvents(req.params.productId, batch_number);
    res.json(result);
  } catch (error) {
    logger.error('Get traceability events API error:', error);
    res.status(500).json({ error: 'Failed to get traceability events' });
  }
});

// ============================================================================
// CHAIN OF CUSTODY
// ============================================================================

/**
 * Record chain of custody transfer
 */
async function recordChainOfCustody(data) {
  const {
    product_id,
    batch_number,
    current_holder_id,
    holder_type,
    from_holder_id,
    transaction_hash,
    transfer_document_url
  } = data;

  try {
    const result = await pool.query(
      `INSERT INTO chain_of_custody 
       (product_id, batch_number, current_holder_id, holder_type, from_holder_id, 
        transaction_hash, transfer_document_url, is_verified)
       VALUES ($1, $2, $3, $4, $5, $6, $7, true)
       RETURNING *`,
      [
        product_id,
        batch_number,
        current_holder_id,
        holder_type,
        from_holder_id,
        transaction_hash,
        transfer_document_url
      ]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Record chain of custody error:', error);
    throw error;
  }
}

/**
 * API endpoint to record chain of custody
 */
router.post('/chain-of-custody', authMiddleware, async (req, res) => {
  try {
    const result = await recordChainOfCustody(req.body);
    res.status(201).json(result);
  } catch (error) {
    logger.error('Record chain of custody API error:', error);
    res.status(500).json({ error: 'Failed to record chain of custody' });
  }
});

/**
 * Verify chain of custody
 */
async function verifyChainOfCustody(productId, batchNumber) {
  try {
    const result = await pool.query(
      'SELECT verify_chain_of_custody($1, $2) as verification',
      [productId, batchNumber]
    );

    return result.rows[0].verification;
  } catch (error) {
    logger.error('Verify chain of custody error:', error);
    throw error;
  }
}

/**
 * API endpoint to verify chain of custody
 */
router.get('/chain-of-custody/verify/:productId', async (req, res) => {
  try {
    const { batch_number } = req.query;
    const result = await verifyChainOfCustody(req.params.productId, batch_number);
    res.json(result);
  } catch (error) {
    logger.error('Verify chain of custody API error:', error);
    res.status(500).json({ error: 'Failed to verify chain of custody' });
  }
});

// ============================================================================
// BLOCKCHAIN CERTIFICATES
// ============================================================================

/**
 * Issue blockchain certificate
 */
async function issueBlockchainCertificate(data) {
  const {
    certificate_type,
    certificate_number,
    product_id,
    batch_number,
    issuer_id,
    issuer_name,
    issue_date,
    expiry_date,
    certificate_data,
    transaction_hash,
    ipfs_hash
  } = data;

  try {
    const result = await pool.query(
      `INSERT INTO blockchain_certificates 
       (certificate_type, certificate_number, product_id, batch_number, issuer_id, issuer_name, 
        issue_date, expiry_date, certificate_data, transaction_hash, ipfs_hash)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
       RETURNING *`,
      [
        certificate_type,
        certificate_number,
        product_id,
        batch_number,
        issuer_id,
        issuer_name,
        issue_date,
        expiry_date,
        JSON.stringify(certificate_data),
        transaction_hash,
        ipfs_hash
      ]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Issue blockchain certificate error:', error);
    throw error;
  }
}

/**
 * API endpoint to issue blockchain certificate
 */
router.post('/blockchain-certificates', authMiddleware, async (req, res) => {
  try {
    const result = await issueBlockchainCertificate({
      ...req.body,
      issuer_id: req.user.id
    });
    res.status(201).json(result);
  } catch (error) {
    logger.error('Issue blockchain certificate API error:', error);
    res.status(500).json({ error: 'Failed to issue blockchain certificate' });
  }
});

/**
 * Verify blockchain certificate
 */
async function verifyBlockchainCertificate(certificateNumber) {
  try {
    const result = await pool.query(
      'SELECT * FROM blockchain_certificates WHERE certificate_number = $1 AND is_revoked = false',
      [certificateNumber]
    );

    if (result.rows.length === 0) {
      throw new Error('Certificate not found or revoked');
    }

    return result.rows[0];
  } catch (error) {
    logger.error('Verify blockchain certificate error:', error);
    throw error;
  }
}

/**
 * API endpoint to verify blockchain certificate
 */
router.get('/blockchain-certificates/verify/:certificateNumber', async (req, res) => {
  try {
    const result = await verifyBlockchainCertificate(req.params.certificateNumber);
    res.json(result);
  } catch (error) {
    logger.error('Verify blockchain certificate API error:', error);
    res.status(404).json({ error: 'Certificate not found or revoked' });
  }
});

// ============================================================================
// VERIFICATION REQUESTS
// ============================================================================

/**
 * Create verification request
 */
async function createVerificationRequest(data) {
  const {
    product_id,
    batch_number,
    certificate_id,
    request_type
  } = data;

  try {
    const result = await pool.query(
      `INSERT INTO verification_requests 
       (product_id, batch_number, certificate_id, requested_by, request_type, verification_status)
       VALUES ($1, $2, $3, $4, $5, 'pending')
       RETURNING *`,
      [product_id, batch_number, certificate_id, data.requested_by, request_type]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Create verification request error:', error);
    throw error;
  }
}

/**
 * API endpoint to create verification request
 */
router.post('/verification-requests', authMiddleware, async (req, res) => {
  try {
    const result = await createVerificationRequest({
      ...req.body,
      requested_by: req.user.id
    });
    res.status(201).json(result);
  } catch (error) {
    logger.error('Create verification request API error:', error);
    res.status(500).json({ error: 'Failed to create verification request' });
  }
});

// ============================================================================
// BLOCKCHAIN ANALYTICS
// ============================================================================

/**
 * Record blockchain analytics
 */
async function recordBlockchainAnalytics(metrics) {
  try {
    const result = await pool.query(
      `INSERT INTO blockchain_analytics 
       (date, total_transactions, confirmed_transactions, failed_transactions, 
        total_gas_used, average_gas_price, total_traceability_events, 
        total_certificates_issued, unique_products_tracked)
       VALUES (CURRENT_DATE, $1, $2, $3, $4, $5, $6, $7, $8)
       ON CONFLICT (date)
       DO UPDATE SET
         total_transactions = blockchain_analytics.total_transactions + EXCLUDED.total_transactions,
         confirmed_transactions = blockchain_analytics.confirmed_transactions + EXCLUDED.confirmed_transactions,
         failed_transactions = blockchain_analytics.failed_transactions + EXCLUDED.failed_transactions,
         total_gas_used = blockchain_analytics.total_gas_used + EXCLUDED.total_gas_used,
         total_traceability_events = blockchain_analytics.total_traceability_events + EXCLUDED.total_traceability_events,
         total_certificates_issued = blockchain_analytics.total_certificates_issued + EXCLUDED.total_certificates_issued
       RETURNING *`,
      [
        metrics.total_transactions || 0,
        metrics.confirmed_transactions || 0,
        metrics.failed_transactions || 0,
        metrics.total_gas_used || 0,
        metrics.average_gas_price || 0,
        metrics.total_traceability_events || 0,
        metrics.total_certificates_issued || 0,
        metrics.unique_products_tracked || 0
      ]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Record blockchain analytics error:', error);
    throw error;
  }
}

/**
 * API endpoint to record blockchain analytics
 */
router.post('/blockchain-analytics',  async (req, res) => {
  try {
    const { metrics } = req.body;
    const result = await recordBlockchainAnalytics(metrics);
    res.json(result);
  } catch (error) {
    logger.error('Record blockchain analytics API error:', error);
    res.status(500).json({ error: 'Failed to record blockchain analytics' });
  }
});

// ============================================================================
// HEALTH CHECK
// ============================================================================

function isHealthy() {
  return pool.connect().then(() => true).catch(() => false);
}

module.exports = {
  router,
  recordBlockchainTransaction,
  getBlockchainTransaction,
  recordTraceabilityEvent,
  getTraceabilityEvents,
  recordChainOfCustody,
  verifyChainOfCustody,
  issueBlockchainCertificate,
  verifyBlockchainCertificate,
  createVerificationRequest,
  recordBlockchainAnalytics,
  isHealthy
};
