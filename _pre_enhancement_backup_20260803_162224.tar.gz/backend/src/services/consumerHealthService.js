/**
 * Consumer Health Service
 * Manages consumer health profiles, dietary recommendations, and health monitoring
 */

const express = require('express');
const { Pool } = require('pg');
const { logger } = require('../utils/logger');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();
const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

// ============================================================================
// HEALTH PROFILES
// ============================================================================

/**
 * Create health profile
 */
async function createHealthProfile(userId, data) {
  const {
    profile_name,
    date_of_birth,
    gender,
    height_cm,
    weight_kg,
    blood_type,
    activity_level,
    health_conditions,
    allergies,
    dietary_restrictions,
    medications,
    health_goals
  } = data;

  try {
    const result = await pool.query(
      `INSERT INTO health_profiles 
       (user_id, profile_name, date_of_birth, gender, height_cm, weight_kg, blood_type, 
        activity_level, health_conditions, allergies, dietary_restrictions, medications, health_goals)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
       RETURNING *`,
      [
        userId,
        profile_name,
        date_of_birth,
        gender,
        height_cm,
        weight_kg,
        blood_type,
        activity_level,
        JSON.stringify(health_conditions),
        JSON.stringify(allergies),
        JSON.stringify(dietary_restrictions),
        JSON.stringify(medications),
        JSON.stringify(health_goals)
      ]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Create health profile error:', error);
    throw error;
  }
}

/**
 * API endpoint to create health profile
 */
router.post('/health-profiles', authMiddleware, async (req, res) => {
  try {
    const result = await createHealthProfile(req.user.id, req.body);
    res.status(201).json(result);
  } catch (error) {
    logger.error('Create health profile API error:', error);
    res.status(500).json({ error: 'Failed to create health profile' });
  }
});

/**
 * Get health profile
 */
async function getHealthProfile(userId) {
  try {
    const result = await pool.query(
      'SELECT * FROM health_profiles WHERE user_id = $1',
      [userId]
    );

    if (result.rows.length === 0) {
      throw new Error('Health profile not found');
    }

    return result.rows[0];
  } catch (error) {
    logger.error('Get health profile error:', error);
    throw error;
  }
}

/**
 * API endpoint to get health profile
 */
router.get('/health-profiles', authMiddleware, async (req, res) => {
  try {
    const result = await getHealthProfile(req.user.id);
    res.json(result);
  } catch (error) {
    logger.error('Get health profile API error:', error);
    res.status(404).json({ error: 'Health profile not found' });
  }
});

// ============================================================================
// DIETARY PROFILES
// ============================================================================

/**
 * Create dietary profile
 */
async function createDietaryProfile(userId, data) {
  const {
    profile_type,
    daily_calorie_target,
    macronutrient_targets,
    micronutrient_targets,
    meal_frequency,
    meal_timing,
    hydration_target_ml
  } = data;

  try {
    const result = await pool.query(
      `INSERT INTO dietary_profiles 
       (user_id, profile_type, daily_calorie_target, macronutrient_targets, micronutrient_targets, 
        meal_frequency, meal_timing, hydration_target_ml, is_active)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, true)
       RETURNING *`,
      [
        userId,
        profile_type,
        daily_calorie_target,
        JSON.stringify(macronutrient_targets),
        JSON.stringify(micronutrient_targets),
        meal_frequency,
        JSON.stringify(meal_timing),
        hydration_target_ml
      ]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Create dietary profile error:', error);
    throw error;
  }
}

/**
 * API endpoint to create dietary profile
 */
router.post('/dietary-profiles', authMiddleware, async (req, res) => {
  try {
    const result = await createDietaryProfile(req.user.id, req.body);
    res.status(201).json(result);
  } catch (error) {
    logger.error('Create dietary profile API error:', error);
    res.status(500).json({ error: 'Failed to create dietary profile' });
  }
});

// ============================================================================
// HEALTH METRICS
// ============================================================================

/**
 * Log health metric
 */
async function logHealthMetric(userId, data) {
  const {
    metric_type,
    metric_value,
    unit,
    notes,
    source
  } = data;

  try {
    const result = await pool.query(
      `INSERT INTO health_metrics 
       (user_id, metric_type, metric_value, unit, notes, source)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [userId, metric_type, metric_value, unit, notes, source || 'manual']
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Log health metric error:', error);
    throw error;
  }
}

/**
 * API endpoint to log health metric
 */
router.post('/health-metrics', authMiddleware, async (req, res) => {
  try {
    const result = await logHealthMetric(req.user.id, req.body);
    res.status(201).json(result);
  } catch (error) {
    logger.error('Log health metric API error:', error);
    res.status(500).json({ error: 'Failed to log health metric' });
  }
});

/**
 * Get health metrics
 */
async function getHealthMetrics(userId, metricType = null, limit = 50) {
  try {
    let query = 'SELECT * FROM health_metrics WHERE user_id = $1';
    const params = [userId];

    if (metricType) {
      query += ' AND metric_type = $2';
      params.push(metricType);
    }

    query += ' ORDER BY recorded_at DESC LIMIT $' + (params.length + 1);
    params.push(limit);

    const result = await pool.query(query, params);
    return result.rows;
  } catch (error) {
    logger.error('Get health metrics error:', error);
    throw error;
  }
}

/**
 * API endpoint to get health metrics
 */
router.get('/health-metrics', authMiddleware, async (req, res) => {
  try {
    const { metric_type, limit } = req.query;
    const result = await getHealthMetrics(req.user.id, metric_type, parseInt(limit) || 50);
    res.json(result);
  } catch (error) {
    logger.error('Get health metrics API error:', error);
    res.status(500).json({ error: 'Failed to get health metrics' });
  }
});

// ============================================================================
// HEALTH GOALS
// ============================================================================

/**
 * Create health goal
 */
async function createHealthGoal(userId, data) {
  const {
    goal_type,
    target_value,
    current_value,
    unit,
    start_date,
    target_date
  } = data;

  try {
    const result = await pool.query(
      `INSERT INTO health_goals 
       (user_id, goal_type, target_value, current_value, unit, start_date, target_date, status)
       VALUES ($1, $2, $3, $4, $5, $6, $7, 'active')
       RETURNING *`,
      [userId, goal_type, target_value, current_value, unit, start_date, target_date]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Create health goal error:', error);
    throw error;
  }
}

/**
 * API endpoint to create health goal
 */
router.post('/health-goals', authMiddleware, async (req, res) => {
  try {
    const result = await createHealthGoal(req.user.id, req.body);
    res.status(201).json(result);
  } catch (error) {
    logger.error('Create health goal API error:', error);
    res.status(500).json({ error: 'Failed to create health goal' });
  }
});

/**
 * Get health goals
 */
async function getHealthGoals(userId) {
  try {
    const result = await pool.query(
      'SELECT * FROM health_goals WHERE user_id = $1 AND status = $2 ORDER BY created_at DESC',
      [userId, 'active']
    );

    return result.rows;
  } catch (error) {
    logger.error('Get health goals error:', error);
    throw error;
  }
}

/**
 * API endpoint to get health goals
 */
router.get('/health-goals', authMiddleware, async (req, res) => {
  try {
    const result = await getHealthGoals(req.user.id);
    res.json(result);
  } catch (error) {
    logger.error('Get health goals API error:', error);
    res.status(500).json({ error: 'Failed to get health goals' });
  }
});

// ============================================================================
// DIETARY RECOMMENDATIONS
// ============================================================================

/**
 * Generate dietary recommendation
 */
async function generateDietaryRecommendation(userId, data) {
  const {
    recommendation_type,
    recommendation_text,
    priority,
    category,
    reasoning
  } = data;

  try {
    const result = await pool.query(
      `INSERT INTO dietary_recommendations 
       (user_id, recommendation_type, recommendation_text, priority, category, reasoning, is_personalized)
       VALUES ($1, $2, $3, $4, $5, $6, true)
       RETURNING *`,
      [userId, recommendation_type, recommendation_text, priority, category, reasoning]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Generate dietary recommendation error:', error);
    throw error;
  }
}

/**
 * API endpoint to generate dietary recommendation
 */
router.post('/dietary-recommendations', authMiddleware, async (req, res) => {
  try {
    const result = await generateDietaryRecommendation(req.user.id, req.body);
    res.status(201).json(result);
  } catch (error) {
    logger.error('Generate dietary recommendation API error:', error);
    res.status(500).json({ error: 'Failed to generate dietary recommendation' });
  }
});

/**
 * Get dietary recommendations
 */
async function getDietaryRecommendations(userId) {
  try {
    const result = await pool.query(
      `SELECT * FROM dietary_recommendations 
       WHERE user_id = $1 AND is_dismissed = false 
       AND (expires_at IS NULL OR expires_at > CURRENT_TIMESTAMP)
       ORDER BY priority DESC, generated_at DESC`,
      [userId]
    );

    return result.rows;
  } catch (error) {
    logger.error('Get dietary recommendations error:', error);
    throw error;
  }
}

/**
 * API endpoint to get dietary recommendations
 */
router.get('/dietary-recommendations', authMiddleware, async (req, res) => {
  try {
    const result = await getDietaryRecommendations(req.user.id);
    res.json(result);
  } catch (error) {
    logger.error('Get dietary recommendations API error:', error);
    res.status(500).json({ error: 'Failed to get dietary recommendations' });
  }
});

// ============================================================================
// HEALTH ALERTS
// ============================================================================

/**
 * Create health alert
 */
async function createHealthAlert(userId, data) {
  const {
    alert_type,
    severity,
    alert_message,
    trigger_data
  } = data;

  try {
    const result = await pool.query(
      `INSERT INTO health_alerts 
       (user_id, alert_type, severity, alert_message, trigger_data)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [userId, alert_type, severity, alert_message, JSON.stringify(trigger_data)]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Create health alert error:', error);
    throw error;
  }
}

/**
 * API endpoint to create health alert
 */
router.post('/health-alerts', authMiddleware, async (req, res) => {
  try {
    const result = await createHealthAlert(req.user.id, req.body);
    res.status(201).json(result);
  } catch (error) {
    logger.error('Create health alert API error:', error);
    res.status(500).json({ error: 'Failed to create health alert' });
  }
});

/**
 * Get health alerts
 */
async function getHealthAlerts(userId) {
  try {
    const result = await pool.query(
      'SELECT * FROM health_alerts WHERE user_id = $1 ORDER BY created_at DESC',
      [userId]
    );

    return result.rows;
  } catch (error) {
    logger.error('Get health alerts error:', error);
    throw error;
  }
}

/**
 * API endpoint to get health alerts
 */
router.get('/health-alerts', authMiddleware, async (req, res) => {
  try {
    const result = await getHealthAlerts(req.user.id);
    res.json(result);
  } catch (error) {
    logger.error('Get health alerts API error:', error);
    res.status(500).json({ error: 'Failed to get health alerts' });
  }
});

// ============================================================================
// FOOD CONSUMPTION LOGS
// ============================================================================

/**
 * Log food consumption
 */
async function logFoodConsumption(userId, data) {
  const {
    food_item_id,
    product_id,
    meal_type,
    quantity_g,
    calories_consumed,
    nutritional_intake,
    notes
  } = data;

  try {
    const result = await pool.query(
      `INSERT INTO food_consumption_logs 
       (user_id, food_item_id, product_id, meal_type, quantity_g, calories_consumed, nutritional_intake, notes)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING *`,
      [
        userId,
        food_item_id,
        product_id,
        meal_type,
        quantity_g,
        calories_consumed,
        JSON.stringify(nutritional_intake),
        notes
      ]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Log food consumption error:', error);
    throw error;
  }
}

/**
 * API endpoint to log food consumption
 */
router.post('/food-consumption', authMiddleware, async (req, res) => {
  try {
    const result = await logFoodConsumption(req.user.id, req.body);
    res.status(201).json(result);
  } catch (error) {
    logger.error('Log food consumption API error:', error);
    res.status(500).json({ error: 'Failed to log food consumption' });
  }
});

// ============================================================================
// HEALTH ANALYTICS
// ============================================================================

/**
 * Get health analytics
 */
async function getHealthAnalytics(userId, startDate = null, endDate = null) {
  try {
    let query = 'SELECT * FROM health_analytics WHERE user_id = $1';
    const params = [userId];

    if (startDate) {
      query += ' AND date >= $2';
      params.push(startDate);
    }

    if (endDate) {
      query += ' AND date <= $' + (params.length + 1);
      params.push(endDate);
    }

    query += ' ORDER BY date DESC';

    const result = await pool.query(query, params);
    return result.rows;
  } catch (error) {
    logger.error('Get health analytics error:', error);
    throw error;
  }
}

/**
 * API endpoint to get health analytics
 */
router.get('/health-analytics', authMiddleware, async (req, res) => {
  try {
    const { start_date, end_date } = req.query;
    const result = await getHealthAnalytics(req.user.id, start_date, end_date);
    res.json(result);
  } catch (error) {
    logger.error('Get health analytics API error:', error);
    res.status(500).json({ error: 'Failed to get health analytics' });
  }
});

// ============================================================================
// BMI CALCULATION
// ============================================================================

/**
 * Calculate BMI
 */
async function calculateBMI(userId) {
  try {
    const profile = await getHealthProfile(userId);
    
    if (!profile.height_cm || !profile.weight_kg) {
      throw new Error('Height and weight required for BMI calculation');
    }

    const result = await pool.query(
      'SELECT calculate_bmi($1, $2) as bmi',
      [profile.weight_kg, profile.height_cm]
    );

    return {
      bmi: result.rows[0].bmi,
      height_cm: profile.height_cm,
      weight_kg: profile.weight_kg
    };
  } catch (error) {
    logger.error('Calculate BMI error:', error);
    throw error;
  }
}

/**
 * API endpoint to calculate BMI
 */
router.get('/bmi', authMiddleware, async (req, res) => {
  try {
    const result = await calculateBMI(req.user.id);
    res.json(result);
  } catch (error) {
    logger.error('Calculate BMI API error:', error);
    res.status(500).json({ error: 'Failed to calculate BMI' });
  }
});

// ============================================================================
// HEALTH CHECK
// ============================================================================

function isHealthy() {
  return pool.connect().then(() => true).catch(() => false);
}

module.exports = {
  router,
  createHealthProfile,
  getHealthProfile,
  createDietaryProfile,
  logHealthMetric,
  getHealthMetrics,
  createHealthGoal,
  getHealthGoals,
  generateDietaryRecommendation,
  getDietaryRecommendations,
  createHealthAlert,
  getHealthAlerts,
  logFoodConsumption,
  getHealthAnalytics,
  calculateBMI,
  isHealthy
};
