/**
 * GI Intelligence Service
 * Manages Geographical Indication products, verification, and premium pricing
 */

const express = require('express');
const { Pool } = require('pg');
const { logger } = require('../utils/logger');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();
const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

// ============================================================================
// GI PRODUCTS
// ============================================================================

/**
 * Register GI product
 */
async function registerGIProduct(data) {
  const {
    product_id,
    gi_name,
    gi_registration_number,
    registration_date,
    geographical_region,
    state,
    gi_authority,
    gi_category,
    description,
    historical_significance,
    unique_characteristics,
    production_methods,
    quality_standards
  } = data;

  try {
    const result = await pool.query(
      `INSERT INTO gi_products 
       (product_id, gi_name, gi_registration_number, registration_date, geographical_region, 
        state, country, gi_authority, gi_category, description, historical_significance, 
        unique_characteristics, production_methods, quality_standards)
       VALUES ($1, $2, $3, $4, $5, $6, 'India', $7, $8, $9, $10, $11, $12, $13)
       RETURNING *`,
      [
        product_id,
        gi_name,
        gi_registration_number,
        registration_date,
        geographical_region,
        state,
        gi_authority,
        gi_category,
        description,
        historical_significance,
        JSON.stringify(unique_characteristics),
        JSON.stringify(production_methods),
        JSON.stringify(quality_standards)
      ]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Register GI product error:', error);
    throw error;
  }
}

/**
 * API endpoint to register GI product
 */
router.post('/gi-products', authMiddleware, async (req, res) => {
  try {
    const result = await registerGIProduct(req.body);
    res.status(201).json(result);
  } catch (error) {
    logger.error('Register GI product API error:', error);
    res.status(500).json({ error: 'Failed to register GI product' });
  }
});

/**
 * Get all GI products
 */
async function getGIProducts(state = null) {
  try {
    let query = 'SELECT * FROM gi_products WHERE status = $1';
    const params = ['registered'];

    if (state) {
      query += ' AND state = $2';
      params.push(state);
    }

    query += ' ORDER BY gi_name';

    const result = await pool.query(query, params);
    return result.rows;
  } catch (error) {
    logger.error('Get GI products error:', error);
    throw error;
  }
}

/**
 * API endpoint to get GI products
 */
router.get('/gi-products', async (req, res) => {
  try {
    const { state } = req.query;
    const result = await getGIProducts(state);
    res.json(result);
  } catch (error) {
    logger.error('Get GI products API error:', error);
    res.status(500).json({ error: 'Failed to get GI products' });
  }
});

// ============================================================================
// GI PRODUCERS
// ============================================================================

/**
 * Register GI producer
 */
async function registerGIProducer(data) {
  const {
    gi_product_id,
    producer_id,
    farmer_id,
    fpo_id,
    production_location_id,
    certified_area_hectares,
    annual_production_tonnes
  } = data;

  try {
    const result = await pool.query(
      `INSERT INTO gi_producers 
       (gi_product_id, producer_id, farmer_id, fpo_id, registration_number, registration_date, 
        production_location_id, certified_area_hectares, annual_production_tonnes, certification_status)
       VALUES ($1, $2, $3, $4, $5, CURRENT_DATE, $6, $7, $8, 'active')
       RETURNING *`,
      [
        gi_product_id,
        producer_id,
        farmer_id,
        fpo_id,
        `GI-PROD-${Date.now()}`,
        production_location_id,
        certified_area_hectares,
        annual_production_tonnes
      ]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Register GI producer error:', error);
    throw error;
  }
}

/**
 * API endpoint to register GI producer
 */
router.post('/gi-producers', authMiddleware, async (req, res) => {
  try {
    const result = await registerGIProducer(req.body);
    res.status(201).json(result);
  } catch (error) {
    logger.error('Register GI producer API error:', error);
    res.status(500).json({ error: 'Failed to register GI producer' });
  }
});

/**
 * Get GI producers for a product
 */
async function getGIProducers(giProductId) {
  try {
    const result = await pool.query(
      `SELECT gp.*, u.first_name, u.last_name, a.city, a.state
       FROM gi_producers gp
       LEFT JOIN users u ON gp.producer_id = u.id
       LEFT JOIN addresses a ON gp.production_location_id = a.id
       WHERE gp.gi_product_id = $1 AND gp.certification_status = 'active'
       ORDER BY gp.registration_date DESC`,
      [giProductId]
    );

    return result.rows;
  } catch (error) {
    logger.error('Get GI producers error:', error);
    throw error;
  }
}

/**
 * API endpoint to get GI producers
 */
router.get('/gi-products/:giProductId/producers', async (req, res) => {
  try {
    const result = await getGIProducers(req.params.giProductId);
    res.json(result);
  } catch (error) {
    logger.error('Get GI producers API error:', error);
    res.status(500).json({ error: 'Failed to get GI producers' });
  }
});

// ============================================================================
// GI PREMIUM PRICING
// ============================================================================

/**
 * Calculate GI premium pricing
 */
async function calculateGIPricing(productId, basePrice, giProductId) {
  try {
    const result = await pool.query(
      'SELECT calculate_gi_pricing($1, $2, $3) as pricing',
      [productId, basePrice, giProductId]
    );

    const pricing = result.rows[0].pricing;

    // Save pricing record
    await pool.query(
      `INSERT INTO gi_product_pricing 
       (product_id, gi_product_id, base_price, gi_premium, final_price, premium_percentage, pricing_factors)
       VALUES ($1, $2, $3, $4, $5, $6, $7)`,
      [
        productId,
        giProductId,
        pricing.base_price,
        pricing.gi_premium,
        pricing.final_price,
        pricing.premium_percentage,
        JSON.stringify(pricing.pricing_factors)
      ]
    );

    return pricing;
  } catch (error) {
    logger.error('Calculate GI pricing error:', error);
    throw error;
  }
}

/**
 * API endpoint to calculate GI pricing
 */
router.post('/gi-pricing', authMiddleware, async (req, res) => {
  try {
    const { product_id, base_price, gi_product_id } = req.body;
    const result = await calculateGIPricing(product_id, basePrice, gi_product_id);
    res.json(result);
  } catch (error) {
    logger.error('Calculate GI pricing API error:', error);
    res.status(500).json({ error: 'Failed to calculate GI pricing' });
  }
});

// ============================================================================
// GI AUTHENTICATION
// ============================================================================

/**
 * Authenticate GI product
 */
async function authenticateGIProduct(productId, batchNumber, producerId) {
  try {
    const authCode = `GI-${Math.random().toString(36).substr(2, 9).toUpperCase()}-${Date.now()}`;

    const result = await pool.query(
      `INSERT INTO gi_authentication 
       (product_id, batch_number, authentication_code, producer_id, production_date, authentication_status)
       VALUES ($1, $2, $3, $4, CURRENT_DATE, 'verified')
       RETURNING *`,
      [productId, batchNumber, authCode, producerId]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Authenticate GI product error:', error);
    throw error;
  }
}

/**
 * API endpoint to authenticate GI product
 */
router.post('/gi-authentication', authMiddleware, async (req, res) => {
  try {
    const { product_id, batch_number, producer_id } = req.body;
    const result = await authenticateGIProduct(product_id, batch_number, producer_id);
    res.status(201).json(result);
  } catch (error) {
    logger.error('Authenticate GI product API error:', error);
    res.status(500).json({ error: 'Failed to authenticate GI product' });
  }
});

/**
 * Verify GI authentication code
 */
async function verifyGIAuthCode(authCode) {
  try {
    const result = await pool.query(
      `SELECT ga.*, gp.gi_name, gp.geographical_region, gp.state
       FROM gi_authentication ga
       LEFT JOIN gi_products gp ON ga.product_id = gp.id
       WHERE ga.authentication_code = $1`,
      [authCode]
    );

    if (result.rows.length === 0) {
      throw new Error('Invalid authentication code');
    }

    return result.rows[0];
  } catch (error) {
    logger.error('Verify GI auth code error:', error);
    throw error;
  }
}

/**
 * API endpoint to verify GI authentication code (public endpoint)
 */
router.get('/gi-authentication/verify/:authCode', async (req, res) => {
  try {
    const result = await verifyGIAuthCode(req.params.authCode);
    res.json(result);
  } catch (error) {
    logger.error('Verify GI auth code API error:', error);
    res.status(404).json({ error: 'Invalid authentication code' });
  }
});

// ============================================================================
// GI MARKETPLACE
// ============================================================================

/**
 * Create GI marketplace listing
 */
async function createGIListing(data) {
  const {
    gi_product_id,
    product_id,
    seller_id,
    listing_title,
    description,
    available_quantity,
    unit,
    price_per_unit,
    quality_tier,
    harvest_date,
    location_id
  } = data;

  try {
    // Calculate GI premium
    const pricing = await calculateGIPricing(product_id, price_per_unit, gi_product_id);

    const result = await pool.query(
      `INSERT INTO gi_marketplace_listings 
       (gi_product_id, product_id, seller_id, listing_title, description, available_quantity, 
        unit, price_per_unit, is_premium_priced, premium_percentage, quality_tier, 
        harvest_date, location_id, listing_status)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, true, $9, $10, $11, $12, 'active')
       RETURNING *`,
      [
        gi_product_id,
        product_id,
        seller_id,
        listing_title,
        description,
        available_quantity,
        unit,
        pricing.final_price,
        pricing.premium_percentage,
        quality_tier,
        harvest_date,
        location_id
      ]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Create GI listing error:', error);
    throw error;
  }
}

/**
 * API endpoint to create GI listing
 */
router.post('/gi-marketplace', authMiddleware, async (req, res) => {
  try {
    const result = await createGIListing({
      ...req.body,
      seller_id: req.user.id
    });
    res.status(201).json(result);
  } catch (error) {
    logger.error('Create GI listing API error:', error);
    res.status(500).json({ error: 'Failed to create GI listing' });
  }
});

/**
 * Get GI marketplace listings
 */
async function getGIListings(giProductId = null, state = null) {
  try {
    let query = `
      SELECT gml.*, gp.gi_name, gp.geographical_region, gp.state, a.city
      FROM gi_marketplace_listings gml
      LEFT JOIN gi_products gp ON gml.gi_product_id = gp.id
      LEFT JOIN addresses a ON gml.location_id = a.id
      WHERE gml.listing_status = 'active'
    `;
    const params = [];

    if (giProductId) {
      query += ' AND gml.gi_product_id = $' + (params.length + 1);
      params.push(giProductId);
    }

    if (state) {
      query += ' AND gp.state = $' + (params.length + 1);
      params.push(state);
    }

    query += ' ORDER BY gml.created_at DESC';

    const result = await pool.query(query, params);
    return result.rows;
  } catch (error) {
    logger.error('Get GI listings error:', error);
    throw error;
  }
}

/**
 * API endpoint to get GI listings
 */
router.get('/gi-marketplace', async (req, res) => {
  try {
    const { gi_product_id, state } = req.query;
    const result = await getGIListings(gi_product_id, state);
    res.json(result);
  } catch (error) {
    logger.error('Get GI listings API error:', error);
    res.status(500).json({ error: 'Failed to get GI listings' });
  }
});

// ============================================================================
// GI ANALYTICS
// ============================================================================

/**
 * Record GI analytics
 */
async function recordGIAnalytics(giProductId, metrics) {
  try {
    const result = await pool.query(
      `INSERT INTO gi_analytics 
       (gi_product_id, date, total_views, total_searches, total_authentications, 
        total_sales, total_quantity_sold, average_premium_percentage, unique_consumers)
       VALUES ($1, CURRENT_DATE, $2, $3, $4, $5, $6, $7, $8)
       ON CONFLICT (gi_product_id, date)
       DO UPDATE SET
         total_views = gi_analytics.total_views + EXCLUDED.total_views,
         total_searches = gi_analytics.total_searches + EXCLUDED.total_searches,
         total_authentications = gi_analytics.total_authentications + EXCLUDED.total_authentications,
         total_sales = gi_analytics.total_sales + EXCLUDED.total_sales,
         total_quantity_sold = gi_analytics.total_quantity_sold + EXCLUDED.total_quantity_sold,
         unique_consumers = gi_analytics.unique_consumers + EXCLUDED.unique_consumers
       RETURNING *`,
      [
        giProductId,
        metrics.views || 0,
        metrics.searches || 0,
        metrics.authentications || 0,
        metrics.sales || 0,
        metrics.quantity_sold || 0,
        metrics.avg_premium || 0,
        metrics.unique_consumers || 0
      ]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Record GI analytics error:', error);
    throw error;
  }
}

/**
 * API endpoint to record GI analytics
 */
router.post('/gi-analytics', authMiddleware, async (req, res) => {
  try {
    const { gi_product_id, metrics } = req.body;
    const result = await recordGIAnalytics(gi_product_id, metrics);
    res.json(result);
  } catch (error) {
    logger.error('Record GI analytics API error:', error);
    res.status(500).json({ error: 'Failed to record GI analytics' });
  }
});

/**
 * Get GI analytics
 */
async function getGIAnalytics(giProductId, startDate = null, endDate = null) {
  try {
    let query = 'SELECT * FROM gi_analytics WHERE gi_product_id = $1';
    const params = [giProductId];

    if (startDate) {
      query += ' AND date >= $' + (params.length + 1);
      params.push(startDate);
    }

    if (endDate) {
      query += ' AND date <= $' + (params.length + 1);
      params.push(endDate);
    }

    query += ' ORDER BY date DESC';

    const result = await pool.query(query, params);
    return result.rows;
  } catch (error) {
    logger.error('Get GI analytics error:', error);
    throw error;
  }
}

/**
 * API endpoint to get GI analytics
 */
router.get('/gi-analytics/:giProductId', authMiddleware, async (req, res) => {
  try {
    const { start_date, end_date } = req.query;
    const result = await getGIAnalytics(req.params.giProductId, start_date, end_date);
    res.json(result);
  } catch (error) {
    logger.error('Get GI analytics API error:', error);
    res.status(500).json({ error: 'Failed to get GI analytics' });
  }
});

// ============================================================================
// HEALTH CHECK
// ============================================================================

function isHealthy() {
  return pool.connect().then(() => true).catch(() => false);
}

module.exports = {
  router,
  registerGIProduct,
  getGIProducts,
  registerGIProducer,
  getGIProducers,
  calculateGIPricing,
  authenticateGIProduct,
  verifyGIAuthCode,
  createGIListing,
  getGIListings,
  recordGIAnalytics,
  getGIAnalytics,
  isHealthy
};
