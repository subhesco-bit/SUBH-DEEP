/**
 * Multilingual Intelligence Service
 * Handles language detection, translation, and multilingual content management
 */

const express = require('express');
const { Pool } = require('pg');
const { logger } = require('../utils/logger');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();
const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

// ============================================================================
// LANGUAGE DETECTION
// ============================================================================

/**
 * Detect language from input text
 * Uses heuristic-based detection (can be enhanced with ML model)
 */
async function detectLanguage(text, options = {}) {
  const startTime = Date.now();
  
  try {
    // Call PostgreSQL function for basic detection
    const result = await pool.query(
      'SELECT detect_language($1) as language_id',
      [text]
    );
    
    const languageId = result.rows[0].language_id;
    
    // Get language details
    const langResult = await pool.query(
      'SELECT * FROM languages WHERE id = $1',
      [languageId]
    );
    
    const language = langResult.rows[0];
    const processingTime = Date.now() - startTime;
    
    // Log detection
    if (options.userId || options.sessionId) {
      await pool.query(
        `INSERT INTO language_detection_logs 
         (user_id, session_id, input_text, detected_language_id, confidence_score, detection_method, processing_time_ms)
         VALUES ($1, $2, $3, $4, $5, $6, $7)`,
        [
          options.userId || null,
          options.sessionId || null,
          text.substring(0, 500),
          languageId,
          0.85, // Default confidence for heuristic
          'heuristic',
          processingTime
        ]
      );
    }
    
    return {
      language_id: language.id,
      iso_code: language.iso_code,
      name: language.name,
      native_name: language.native_name,
      direction: language.direction,
      confidence: 0.85,
      processing_time_ms: processingTime
    };
  } catch (error) {
    logger.error('Language detection error:', error);
    throw error;
  }
}

/**
 * API endpoint for language detection
 */
router.post('/detect', authMiddleware, async (req, res) => {
  try {
    const { text } = req.body;
    
    if (!text || text.trim().length === 0) {
      return res.status(400).json({ error: 'Text is required' });
    }
    
    const result = await detectLanguage(text, {
      userId: req.user.id,
      sessionId: req.sessionID
    });
    
    res.json(result);
  } catch (error) {
    logger.error('Detect language API error:', error);
    res.status(500).json({ error: 'Language detection failed' });
  }
});

// ============================================================================
// TRANSLATION
// ============================================================================

/**
 * Translate text from source to target language
 * Uses translation memory first, then external API
 */
async function translateText(sourceText, sourceLang, targetLang, options = {}) {
  const startTime = Date.now();
  
  try {
    // Get language IDs
    const sourceLangResult = await pool.query(
      'SELECT id FROM languages WHERE iso_code = $1',
      [sourceLang]
    );
    const targetLangResult = await pool.query(
      'SELECT id FROM languages WHERE iso_code = $1',
      [targetLang]
    );
    
    if (sourceLangResult.rows.length === 0 || targetLangResult.rows.length === 0) {
      throw new Error('Invalid language code');
    }
    
    const sourceLangId = sourceLangResult.rows[0].id;
    const targetLangId = targetLangResult.rows[0].id;
    
    // Check translation memory first
    const memoryResult = await pool.query(
      'SELECT get_translation_from_memory($1, $2, $3, $4) as memory_id',
      [sourceText, sourceLangId, targetLangId, options.domain || null]
    );
    
    const memoryId = memoryResult.rows[0].memory_id;
    
    let translatedText;
    let usedMemory = false;
    let autoTranslated = false;
    let confidence = 1.0;
    
    if (memoryId) {
      // Get translation from memory
      const memResult = await pool.query(
        'SELECT target_text, confidence_score FROM translation_memory WHERE id = $1',
        [memoryId]
      );
      translatedText = memResult.rows[0].target_text;
      confidence = memResult.rows[0].confidence_score;
      usedMemory = true;
    } else {
      // Use external translation service (Google Cloud Translation)
      translatedText = await translateWithExternalAPI(sourceText, sourceLang, targetLang);
      autoTranslated = true;
      confidence = 0.90; // Default confidence for API translation
      
      // Store in translation memory
      await pool.query(
        `INSERT INTO translation_memory 
         (source_text, source_language_id, target_language_id, target_text, context, domain, confidence_score, is_auto_translated)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
        [sourceText, sourceLangId, targetLangId, translatedText, options.context || null, options.domain || null, confidence, true]
      );
    }
    
    const processingTime = Date.now() - startTime;
    
    // Log translation request
    if (options.userId) {
      await pool.query(
        `INSERT INTO translation_requests 
         (user_id, source_language_id, target_language_id, source_text, translated_text, status, used_memory, memory_match_id, processing_time_ms, completed_at)
         VALUES ($1, $2, $3, $4, $5, 'completed', $6, $7, $8, NOW())`,
        [options.userId, sourceLangId, targetLangId, sourceText, translatedText, usedMemory, memoryId, processingTime]
      );
    }
    
    return {
      source_text: sourceText,
      source_language: sourceLang,
      target_language: targetLang,
      translated_text: translatedText,
      confidence: confidence,
      used_memory: usedMemory,
      auto_translated: autoTranslated,
      processing_time_ms: processingTime
    };
  } catch (error) {
    logger.error('Translation error:', error);
    throw error;
  }
}

/**
 * Translate using external API (Google Cloud Translation)
 * In production, this would use actual Google Cloud Translation API
 */
async function translateWithExternalAPI(text, sourceLang, targetLang) {
  // Mock implementation - in production, integrate with Google Cloud Translation
  // const { TranslationServiceClient } = require('@google-cloud/translate').v3;
  // const client = new TranslationServiceClient();
  
  // For now, return a placeholder
  logger.info(`Translation request: ${sourceLang} -> ${targetLang}: "${text.substring(0, 50)}..."`);
  
  // In production, this would be:
  // const [response] = await client.translateText({
  //   parent: `projects/${process.env.GOOGLE_PROJECT_ID}/locations/global`,
  //   contents: [text],
  //   sourceLanguageCode: sourceLang,
  //   targetLanguageCode: targetLang
  // });
  // return response.translations[0].translatedText;
  
  // Mock response for development
  return `[Translated from ${sourceLang} to ${targetLang}]: ${text}`;
}

/**
 * API endpoint for translation
 */
router.post('/translate', authMiddleware, async (req, res) => {
  try {
    const { text, source_language, target_language, domain, context } = req.body;
    
    if (!text || !source_language || !target_language) {
      return res.status(400).json({ 
        error: 'text, source_language, and target_language are required' 
      });
    }
    
    const result = await translateText(text, source_language, target_language, {
      userId: req.user.id,
      domain,
      context
    });
    
    res.json(result);
  } catch (error) {
    logger.error('Translate API error:', error);
    res.status(500).json({ error: 'Translation failed' });
  }
});

// ============================================================================
// CONTENT TRANSLATIONS
// ============================================================================

/**
 * Get translated content for a key
 */
async function getContentTranslation(contentKey, languageCode, entityType = null, entityId = null) {
  try {
    const langResult = await pool.query(
      'SELECT id FROM languages WHERE iso_code = $1',
      [languageCode]
    );
    
    if (langResult.rows.length === 0) {
      throw new Error('Invalid language code');
    }
    
    const languageId = langResult.rows[0].id;
    
    const result = await pool.query(
      `SELECT * FROM content_translations 
       WHERE content_key = $1 AND language_id = $2 
       AND ($3::text IS NULL OR entity_type = $3)
       AND ($4::uuid IS NULL OR entity_id = $4)
       LIMIT 1`,
      [contentKey, languageId, entityType, entityId]
    );
    
    if (result.rows.length === 0) {
      return null;
    }
    
    return result.rows[0];
  } catch (error) {
    logger.error('Get content translation error:', error);
    throw error;
  }
}

/**
 * Save content translation
 */
async function saveContentTranslation(data) {
  try {
    const { content_key, entity_type, entity_id, language_code, translated_text, context } = data;
    
    const langResult = await pool.query(
      'SELECT id FROM languages WHERE iso_code = $1',
      [language_code]
    );
    
    if (langResult.rows.length === 0) {
      throw new Error('Invalid language code');
    }
    
    const languageId = langResult.rows[0].id;
    
    const result = await pool.query(
      `INSERT INTO content_translations 
       (content_key, entity_type, entity_id, language_id, translated_text, context, is_auto_translated, auto_translation_confidence)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       ON CONFLICT (content_key, language_id)
       DO UPDATE SET 
         translated_text = EXCLUDED.translated_text,
         context = EXCLUDED.context,
         updated_at = CURRENT_TIMESTAMP
       RETURNING *`,
      [content_key, entity_type, entity_id, languageId, translated_text, context, false, 1.0]
    );
    
    return result.rows[0];
  } catch (error) {
    logger.error('Save content translation error:', error);
    throw error;
  }
}

/**
 * API endpoint to get content translation
 */
router.get('/content/:key', authMiddleware, async (req, res) => {
  try {
    const { key } = req.params;
    const { language, entity_type, entity_id } = req.query;
    
    if (!language) {
      return res.status(400).json({ error: 'language parameter is required' });
    }
    
    const result = await getContentTranslation(key, language, entity_type, entity_id);
    
    if (!result) {
      return res.status(404).json({ error: 'Translation not found' });
    }
    
    res.json(result);
  } catch (error) {
    logger.error('Get content translation API error:', error);
    res.status(500).json({ error: 'Failed to get content translation' });
  }
});

/**
 * API endpoint to save content translation
 */
router.post('/content', authMiddleware, async (req, res) => {
  try {
    const result = await saveContentTranslation(req.body);
    res.json(result);
  } catch (error) {
    logger.error('Save content translation API error:', error);
    res.status(500).json({ error: 'Failed to save content translation' });
  }
});

// ============================================================================
// USER LANGUAGE PREFERENCES
// ============================================================================

/**
 * Get user language preferences
 */
async function getUserLanguagePreferences(userId) {
  try {
    const result = await pool.query(
      `SELECT ulp.*, 
       l1.iso_code as primary_language_code, l1.name as primary_language_name,
       l2.iso_code as secondary_language_code, l2.name as secondary_language_name
       FROM user_language_preferences ulp
       LEFT JOIN languages l1 ON ulp.primary_language_id = l1.id
       LEFT JOIN languages l2 ON ulp.secondary_language_id = l2.id
       WHERE ulp.user_id = $1`,
      [userId]
    );
    
    if (result.rows.length === 0) {
      // Create default preferences
      await pool.query(
        `INSERT INTO user_language_preferences (user_id, primary_language_id, auto_detect_language)
         VALUES ($1, (SELECT id FROM languages WHERE iso_code = 'en' LIMIT 1), true)`,
        [userId]
      );
      
      return await getUserLanguagePreferences(userId);
    }
    
    return result.rows[0];
  } catch (error) {
    logger.error('Get user language preferences error:', error);
    throw error;
  }
}

/**
 * Update user language preferences
 */
async function updateUserLanguagePreferences(userId, preferences) {
  try {
    const { primary_language, secondary_language, auto_detect_language, auto_translate_content, preferred_translation_service } = preferences;
    
    let primaryLangId = null;
    let secondaryLangId = null;
    
    if (primary_language) {
      const langResult = await pool.query(
        'SELECT id FROM languages WHERE iso_code = $1',
        [primary_language]
      );
      if (langResult.rows.length > 0) {
        primaryLangId = langResult.rows[0].id;
      }
    }
    
    if (secondary_language) {
      const langResult = await pool.query(
        'SELECT id FROM languages WHERE iso_code = $1',
        [secondary_language]
      );
      if (langResult.rows.length > 0) {
        secondaryLangId = langResult.rows[0].id;
      }
    }
    
    const result = await pool.query(
      `UPDATE user_language_preferences
       SET primary_language_id = COALESCE($1, primary_language_id),
           secondary_language_id = COALESCE($2, secondary_language_id),
           auto_detect_language = COALESCE($3, auto_detect_language),
           auto_translate_content = COALESCE($4, auto_translate_content),
           preferred_translation_service = COALESCE($5, preferred_translation_service),
           updated_at = CURRENT_TIMESTAMP
       WHERE user_id = $6
       RETURNING *`,
      [primaryLangId, secondaryLangId, auto_detect_language, auto_translate_content, preferred_translation_service, userId]
    );
    
    return result.rows[0];
  } catch (error) {
    logger.error('Update user language preferences error:', error);
    throw error;
  }
}

/**
 * API endpoint to get user language preferences
 */
router.get('/preferences', authMiddleware, async (req, res) => {
  try {
    const result = await getUserLanguagePreferences(req.user.id);
    res.json(result);
  } catch (error) {
    logger.error('Get preferences API error:', error);
    res.status(500).json({ error: 'Failed to get language preferences' });
  }
});

/**
 * API endpoint to update user language preferences
 */
router.put('/preferences', authMiddleware, async (req, res) => {
  try {
    const result = await updateUserLanguagePreferences(req.user.id, req.body);
    res.json(result);
  } catch (error) {
    logger.error('Update preferences API error:', error);
    res.status(500).json({ error: 'Failed to update language preferences' });
  }
});

// ============================================================================
// AVAILABLE LANGUAGES
// ============================================================================

/**
 * Get all available languages
 */
async function getAvailableLanguages() {
  try {
    const result = await pool.query(
      'SELECT * FROM languages WHERE is_active = true ORDER BY priority DESC, name'
    );
    return result.rows;
  } catch (error) {
    logger.error('Get available languages error:', error);
    throw error;
  }
}

/**
 * API endpoint to get available languages
 */
router.get('/languages', async (req, res) => {
  try {
    const result = await getAvailableLanguages();
    res.json(result);
  } catch (error) {
    logger.error('Get languages API error:', error);
    res.status(500).json({ error: 'Failed to get available languages' });
  }
});

// ============================================================================
// TRANSLATION MEMORY MANAGEMENT
// ============================================================================

/**
 * Get translation memory statistics
 */
async function getTranslationMemoryStats() {
  try {
    const result = await pool.query(`
      SELECT 
        COUNT(*) as total_entries,
        COUNT(CASE WHEN is_verified = true THEN 1 END) as verified_entries,
        COUNT(CASE WHEN is_auto_translated = true THEN 1 END) as auto_translated_entries,
        AVG(confidence_score) as avg_confidence,
        SUM(usage_count) as total_usage
      FROM translation_memory
    `);
    
    return result.rows[0];
  } catch (error) {
    logger.error('Get translation memory stats error:', error);
    throw error;
  }
}

/**
 * API endpoint to get translation memory statistics
 */
router.get('/memory/stats', async (req, res) => {
  try {
    const result = await getTranslationMemoryStats();
    res.json(result);
  } catch (error) {
    logger.error('Get memory stats API error:', error);
    res.status(500).json({ error: 'Failed to get translation memory statistics' });
  }
});

// ============================================================================
// HEALTH CHECK
// ============================================================================

function isHealthy() {
  return pool.connect().then(() => true).catch(() => false);
}

module.exports = {
  router,
  detectLanguage,
  translateText,
  getContentTranslation,
  saveContentTranslation,
  getUserLanguagePreferences,
  updateUserLanguagePreferences,
  getAvailableLanguages,
  getTranslationMemoryStats,
  isHealthy
};
