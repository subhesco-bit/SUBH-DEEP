/**
 * Nutrition Intelligence Service
 * Manages nutrition data, scoring, and value-based pricing
 */

const express = require('express');
const { Pool } = require('pg');
const { logger } = require('../utils/logger');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();
const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

// ============================================================================
// NUTRIENT DATABASE
// ============================================================================

/**
 * Get all nutrients
 */
async function getNutrients() {
  try {
    const result = await pool.query(
      `SELECT n.*, nc.name as category_name 
       FROM nutrients n 
       LEFT JOIN nutrient_categories nc ON n.category_id = nc.id 
       ORDER BY nc.display_order, n.name`
    );
    return result.rows;
  } catch (error) {
    logger.error('Get nutrients error:', error);
    throw error;
  }
}

/**
 * API endpoint to get nutrients
 */
router.get('/nutrients', async (req, res) => {
  try {
    const result = await getNutrients();
    res.json(result);
  } catch (error) {
    logger.error('Get nutrients API error:', error);
    res.status(500).json({ error: 'Failed to get nutrients' });
  }
});

// ============================================================================
// FOOD NUTRITION PROFILES
// ============================================================================

/**
 * Create food nutrition profile
 */
async function createFoodNutritionProfile(data) {
  const {
    food_name,
    scientific_name,
    food_group,
    botanical_family,
    variety,
    origin_region,
    is_organic,
    nutrition_data,
    serving_size_g,
    calories_per_100g,
    glycemic_index,
    glycemic_load,
    anti_inflammatory_score,
    antioxidant_capacity
  } = data;

  try {
    const result = await pool.query(
      `INSERT INTO food_nutrition_profiles 
       (food_name, scientific_name, food_group, botanical_family, variety, origin_region, 
        is_organic, nutrition_data, serving_size_g, calories_per_100g, glycemic_index, 
        glycemic_load, anti_inflammatory_score, antioxidant_capacity)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
       RETURNING *`,
      [
        food_name,
        scientific_name,
        food_group,
        botanical_family,
        variety,
        origin_region,
        is_organic,
        JSON.stringify(nutrition_data),
        serving_size_g,
        calories_per_100g,
        glycemic_index,
        glycemic_load,
        anti_inflammatory_score,
        antioxidant_capacity
      ]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Create food nutrition profile error:', error);
    throw error;
  }
}

/**
 * API endpoint to create food nutrition profile
 */
router.post('/food-profiles', authMiddleware, async (req, res) => {
  try {
    const result = await createFoodNutritionProfile(req.body);
    res.status(201).json(result);
  } catch (error) {
    logger.error('Create food profile API error:', error);
    res.status(500).json({ error: 'Failed to create food nutrition profile' });
  }
});

/**
 * Search food nutrition profiles
 */
async function searchFoodProfiles(query, foodGroup = null) {
  try {
    let queryText = `
      SELECT * FROM food_nutrition_profiles 
      WHERE to_tsvector('english', food_name || ' ' || COALESCE(scientific_name, '')) @@ to_tsquery('english', $1)
    `;
    const queryParams = [query];

    if (foodGroup) {
      queryText += ' AND food_group = $2';
      queryParams.push(foodGroup);
    }

    queryText += ' ORDER BY food_name LIMIT 50';

    const result = await pool.query(queryText, queryParams);
    return result.rows;
  } catch (error) {
    logger.error('Search food profiles error:', error);
    throw error;
  }
}

/**
 * API endpoint to search food profiles
 */
router.get('/food-profiles/search', async (req, res) => {
  try {
    const { q, food_group } = req.query;
    if (!q) {
      return res.status(400).json({ error: 'Query parameter q is required' });
    }
    const result = await searchFoodProfiles(q, food_group);
    res.json(result);
  } catch (error) {
    logger.error('Search food profiles API error:', error);
    res.status(500).json({ error: 'Failed to search food profiles' });
  }
});

// ============================================================================
// PRODUCT NUTRITION
// ============================================================================

/**
 * Add nutrition data to product
 */
async function addProductNutrition(data) {
  const {
    product_id,
    nutrition_profile_id,
    lab_test_id,
    test_date,
    testing_laboratory,
    sample_batch_number,
    nutrition_data,
    calories_per_serving,
    serving_size_g,
    servings_per_container,
    verification_method,
    confidence_score
  } = data;

  try {
    const result = await pool.query(
      `INSERT INTO product_nutrition 
       (product_id, nutrition_profile_id, lab_test_id, test_date, testing_laboratory, 
        sample_batch_number, nutrition_data, calories_per_serving, serving_size_g, 
        servings_per_container, verification_method, confidence_score)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
       RETURNING *`,
      [
        product_id,
        nutrition_profile_id,
        lab_test_id,
        test_date,
        testing_laboratory,
        sample_batch_number,
        JSON.stringify(nutrition_data),
        calories_per_serving,
        serving_size_g,
        servings_per_container,
        verification_method,
        confidence_score
      ]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Add product nutrition error:', error);
    throw error;
  }
}

/**
 * API endpoint to add product nutrition
 */
router.post('/product-nutrition', authMiddleware, async (req, res) => {
  try {
    const result = await addProductNutrition(req.body);
    res.status(201).json(result);
  } catch (error) {
    logger.error('Add product nutrition API error:', error);
    res.status(500).json({ error: 'Failed to add product nutrition' });
  }
});

/**
 * Get product nutrition
 */
async function getProductNutrition(productId) {
  try {
    const result = await pool.query(
      `SELECT pn.*, fnp.food_name 
       FROM product_nutrition pn
       LEFT JOIN food_nutrition_profiles fnp ON pn.nutrition_profile_id = fnp.id
       WHERE pn.product_id = $1
       ORDER BY pn.created_at DESC
       LIMIT 1`,
      [productId]
    );

    if (result.rows.length === 0) {
      throw new Error('Product nutrition not found');
    }

    return result.rows[0];
  } catch (error) {
    logger.error('Get product nutrition error:', error);
    throw error;
  }
}

/**
 * API endpoint to get product nutrition
 */
router.get('/product-nutrition/:productId', async (req, res) => {
  try {
    const result = await getProductNutrition(req.params.productId);
    res.json(result);
  } catch (error) {
    logger.error('Get product nutrition API error:', error);
    res.status(404).json({ error: 'Product nutrition not found' });
  }
});

// ============================================================================
// NUTRITION SCORING
// ============================================================================

/**
 * Calculate nutrition score for product
 */
async function calculateProductNutritionScore(productId, scoringModelId = 1) {
  try {
    // Get product nutrition
    const nutritionResult = await pool.query(
      'SELECT nutrition_data FROM product_nutrition WHERE product_id = $1 ORDER BY created_at DESC LIMIT 1',
      [productId]
    );

    if (nutritionResult.rows.length === 0) {
      throw new Error('Product nutrition data not found');
    }

    const nutritionData = nutritionResult.rows[0].nutrition_data;

    // Calculate score using database function
    const scoreResult = await pool.query(
      'SELECT calculate_nutrition_score($1, $2) as score',
      [JSON.stringify(nutritionData), scoringModelId]
    );

    const overallScore = scoreResult.rows[0].score;

    // Assign grade
    const gradeResult = await pool.query(
      'SELECT assign_nutrition_grade($1) as grade',
      [overallScore]
    );

    const grade = gradeResult.rows[0].grade;

    // Save score
    const saveResult = await pool.query(
      `INSERT INTO product_nutrition_scores 
       (product_id, scoring_model_id, overall_score, grade)
       VALUES ($1, $2, $3, $4)
       RETURNING *`,
      [productId, scoringModelId, overallScore, grade]
    );

    return saveResult.rows[0];
  } catch (error) {
    logger.error('Calculate nutrition score error:', error);
    throw error;
  }
}

/**
 * API endpoint to calculate nutrition score
 */
router.post('/product-nutrition/:productId/score', authMiddleware, async (req, res) => {
  try {
    const { scoring_model_id } = req.body;
    const result = await calculateProductNutritionScore(req.params.productId, scoring_model_id);
    res.json(result);
  } catch (error) {
    logger.error('Calculate score API error:', error);
    res.status(500).json({ error: 'Failed to calculate nutrition score' });
  }
});

/**
 * Get product nutrition score
 */
async function getProductNutritionScore(productId) {
  try {
    const result = await pool.query(
      `SELECT * FROM product_nutrition_scores 
       WHERE product_id = $1 
       ORDER BY calculated_at DESC 
       LIMIT 1`,
      [productId]
    );

    if (result.rows.length === 0) {
      throw new Error('Product nutrition score not found');
    }

    return result.rows[0];
  } catch (error) {
    logger.error('Get product nutrition score error:', error);
    throw error;
  }
}

/**
 * API endpoint to get product nutrition score
 */
router.get('/product-nutrition/:productId/score', async (req, res) => {
  try {
    const result = await getProductNutritionScore(req.params.productId);
    res.json(result);
  } catch (error) {
    logger.error('Get score API error:', error);
    res.status(404).json({ error: 'Product nutrition score not found' });
  }
});

// ============================================================================
// VALUE-BASED PRICING
// ============================================================================

/**
 * Calculate nutrition-based pricing
 */
async function calculateNutritionPricing(productId, basePrice, pricingRuleId = 1) {
  try {
    // Get nutrition score
    const scoreData = await getProductNutritionScore(productId);
    
    // Get pricing rule
    const ruleResult = await pool.query(
      'SELECT * FROM nutrition_pricing_rules WHERE id = $1 AND is_active = true',
      [pricingRuleId]
    );

    if (ruleResult.rows.length === 0) {
      throw new Error('Pricing rule not found');
    }

    const pricingRule = ruleResult.rows[0];
    const algorithm = pricingRule.pricing_algorithm;

    // Calculate adjustment based on score
    let adjustment = 0;
    const score = scoreData.overall_score;

    // Simple algorithm: higher score = higher price premium
    if (score >= 90) {
      adjustment = basePrice * 0.20; // 20% premium for A+ grade
    } else if (score >= 80) {
      adjustment = basePrice * 0.15; // 15% premium for A/B+ grade
    } else if (score >= 70) {
      adjustment = basePrice * 0.10; // 10% premium for B/C+ grade
    } else if (score >= 60) {
      adjustment = basePrice * 0.05; // 5% premium for C grade
    }

    const finalPrice = basePrice + adjustment;
    const premiumPercentage = (adjustment / basePrice) * 100;

    // Save pricing
    const saveResult = await pool.query(
      `INSERT INTO product_nutrition_pricing 
       (product_id, nutrition_score_id, pricing_rule_id, base_price, nutrition_adjustment, 
        final_price, price_premium_percentage, value_factors)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING *`,
      [
        productId,
        scoreData.id,
        pricingRuleId,
        basePrice,
        adjustment,
        finalPrice,
        premiumPercentage,
        JSON.stringify({
          nutrition_grade: scoreData.grade,
          nutrition_score: score,
          base_price: basePrice
        })
      ]
    );

    return saveResult.rows[0];
  } catch (error) {
    logger.error('Calculate nutrition pricing error:', error);
    throw error;
  }
}

/**
 * API endpoint to calculate nutrition pricing
 */
router.post('/product-nutrition/:productId/pricing', authMiddleware, async (req, res) => {
  try {
    const { base_price, pricing_rule_id } = req.body;
    const result = await calculateNutritionPricing(req.params.productId, base_price, pricing_rule_id);
    res.json(result);
  } catch (error) {
    logger.error('Calculate pricing API error:', error);
    res.status(500).json({ error: 'Failed to calculate nutrition pricing' });
  }
});

// ============================================================================
// NUTRITION COMPARISON
// ============================================================================

/**
 * Compare nutrition between two products
 */
async function compareProductsNutrition(productAId, productBId) {
  try {
    const nutritionA = await getProductNutrition(productAId);
    const nutritionB = await getProductNutrition(productBId);
    const scoreA = await getProductNutritionScore(productAId);
    const scoreB = await getProductNutritionScore(productBId);

    const comparison = {
      product_a: {
        id: productAId,
        nutrition_data: nutritionA.nutrition_data,
        score: scoreA.overall_score,
        grade: scoreA.grade
      },
      product_b: {
        id: productBId,
        nutrition_data: nutritionB.nutrition_data,
        score: scoreB.overall_score,
        grade: scoreB.grade
      },
      winner: scoreA.overall_score >= scoreB.overall_score ? productAId : productBId,
      comparison_reason: scoreA.overall_score >= scoreB.overall_score 
        ? `Product A has higher nutrition score (${scoreA.overall_score} vs ${scoreB.overall_score})`
        : `Product B has higher nutrition score (${scoreB.overall_score} vs ${scoreA.overall_score})`
    };

    // Save comparison
    await pool.query(
      `INSERT INTO nutrition_comparisons 
       (product_a_id, product_b_id, comparison_metrics, winner_product_id, comparison_reason)
       VALUES ($1, $2, $3, $4, $5)`,
      [productAId, productBId, JSON.stringify(comparison), comparison.winner, comparison.comparison_reason]
    );

    return comparison;
  } catch (error) {
    logger.error('Compare products nutrition error:', error);
    throw error;
  }
}

/**
 * API endpoint to compare products
 */
router.post('/compare', async (req, res) => {
  try {
    const { product_a_id, product_b_id } = req.body;
    const result = await compareProductsNutrition(product_a_id, product_b_id);
    res.json(result);
  } catch (error) {
    logger.error('Compare products API error:', error);
    res.status(500).json({ error: 'Failed to compare products' });
  }
});

// ============================================================================
// DIETARY PROFILES
// ============================================================================

/**
 * Get dietary profiles
 */
async function getDietaryProfiles() {
  try {
    const result = await pool.query(
      'SELECT * FROM dietary_profiles ORDER BY name'
    );
    return result.rows;
  } catch (error) {
    logger.error('Get dietary profiles error:', error);
    throw error;
  }
}

/**
 * API endpoint to get dietary profiles
 */
router.get('/dietary-profiles', async (req, res) => {
  try {
    const result = await getDietaryProfiles();
    res.json(result);
  } catch (error) {
    logger.error('Get dietary profiles API error:', error);
    res.status(500).json({ error: 'Failed to get dietary profiles' });
  }
});

// ============================================================================
// HEALTH CHECK
// ============================================================================

function isHealthy() {
  return pool.connect().then(() => true).catch(() => false);
}

module.exports = {
  router,
  getNutrients,
  createFoodNutritionProfile,
  searchFoodProfiles,
  addProductNutrition,
  getProductNutrition,
  calculateProductNutritionScore,
  getProductNutritionScore,
  calculateNutritionPricing,
  compareProductsNutrition,
  getDietaryProfiles,
  isHealthy
};
