/**
 * Order & Cart Service
 * Manages shopping cart, order processing, and payment integration
 */

const crypto = require('crypto');
const { logger } = require('../utils/logger');
const { getPostgreSQL } = require('../database/connection');

/**
 * Get user's cart
 */
async function getCart(userId) {
  try {
    const pg = getPostgreSQL();
    
    const query = `
      SELECT c.*, p.name as product_name, p.base_price, p.images, p.slug,
             u.symbol as unit_symbol
      FROM cart c
      JOIN products p ON c.product_id = p.id
      LEFT JOIN units u ON p.unit_id = u.id
      WHERE c.user_id = $1
      ORDER BY c.created_at DESC
    `;
    
    const result = await pg.query(query, [userId]);
    
    const cartItems = result.rows.map(item => ({
      ...item,
      total_price: item.base_price * item.quantity
    }));
    
    const total = cartItems.reduce((sum, item) => sum + item.total_price, 0);
    
    return {
      items: cartItems,
      total_items: cartItems.reduce((sum, item) => sum + item.quantity, 0),
      total_amount: total
    };
  } catch (error) {
    logger.error('Error fetching cart:', error);
    throw error;
  }
}

/**
 * Add item to cart
 */
async function addToCart(userId, productId, quantity = 1, attributes = {}) {
  try {
    const pg = getPostgreSQL();
    
    // Check if product exists
    const productQuery = 'SELECT id, base_price, is_active FROM products WHERE id = $1';
    const productResult = await pg.query(productQuery, [productId]);
    
    if (productResult.rows.length === 0) {
      throw new Error('Product not found');
    }
    
    const product = productResult.rows[0];
    
    if (!product.is_active) {
      throw new Error('Product is not available');
    }
    
    // Check if item already exists in cart
    const existingQuery = 'SELECT id, quantity FROM cart WHERE user_id = $1 AND product_id = $2';
    const existingResult = await pg.query(existingQuery, [userId, productId]);
    
    if (existingResult.rows.length > 0) {
      // Update quantity
      const updateQuery = `
        UPDATE cart
        SET quantity = quantity + $1, attributes = $2, updated_at = NOW()
        WHERE id = $3
        RETURNING *
      `;
      
      const updateResult = await pg.query(updateQuery, [
        quantity,
        JSON.stringify(attributes),
        existingResult.rows[0].id
      ]);
      
      logger.info(`Cart item updated: user ${userId}, product ${productId}`);
      return updateResult.rows[0];
    } else {
      // Add new item
      const insertQuery = `
        INSERT INTO cart (user_id, product_id, quantity, attributes)
        VALUES ($1, $2, $3, $4)
        RETURNING *
      `;
      
      const insertResult = await pg.query(insertQuery, [userId, productId, quantity, JSON.stringify(attributes)]);
      
      logger.info(`Item added to cart: user ${userId}, product ${productId}`);
      return insertResult.rows[0];
    }
  } catch (error) {
    logger.error('Error adding to cart:', error);
    throw error;
  }
}

/**
 * Update cart item quantity
 */
async function updateCartItem(userId, cartItemId, quantity) {
  try {
    const pg = getPostgreSQL();
    
    if (quantity <= 0) {
      // Remove item
      const deleteQuery = 'DELETE FROM cart WHERE id = $1 AND user_id = $2 RETURNING *';
      const deleteResult = await pg.query(deleteQuery, [cartItemId, userId]);
      
      if (deleteResult.rows.length === 0) {
        throw new Error('Cart item not found');
      }
      
      logger.info(`Cart item removed: ${cartItemId}`);
      return deleteResult.rows[0];
    } else {
      // Update quantity
      const updateQuery = `
        UPDATE cart
        SET quantity = $1, updated_at = NOW()
        WHERE id = $2 AND user_id = $3
        RETURNING *
      `;
      
      const updateResult = await pg.query(updateQuery, [quantity, cartItemId, userId]);
      
      if (updateResult.rows.length === 0) {
        throw new Error('Cart item not found');
      }
      
      logger.info(`Cart item updated: ${cartItemId}`);
      return updateResult.rows[0];
    }
  } catch (error) {
    logger.error('Error updating cart item:', error);
    throw error;
  }
}

/**
 * Remove item from cart
 */
async function removeFromCart(userId, cartItemId) {
  try {
    const pg = getPostgreSQL();
    
    const query = 'DELETE FROM cart WHERE id = $1 AND user_id = $2 RETURNING *';
    const result = await pg.query(query, [cartItemId, userId]);
    
    if (result.rows.length === 0) {
      throw new Error('Cart item not found');
    }
    
    logger.info(`Cart item removed: ${cartItemId}`);
    return result.rows[0];
  } catch (error) {
    logger.error('Error removing from cart:', error);
    throw error;
  }
}

/**
 * Clear cart
 */
async function clearCart(userId) {
  try {
    const pg = getPostgreSQL();
    
    const query = 'DELETE FROM cart WHERE user_id = $1';
    await pg.query(query, [userId]);
    
    logger.info(`Cart cleared for user: ${userId}`);
    return { success: true };
  } catch (error) {
    logger.error('Error clearing cart:', error);
    throw error;
  }
}

/**
 * Create order from cart
 */
async function createOrder(userId, orderData) {
  try {
    const pg = getPostgreSQL();
    
    // Get cart items
    const cartQuery = `
      SELECT c.*, p.base_price, p.name as product_name, p.slug
      FROM cart c
      JOIN products p ON c.product_id = p.id
      WHERE c.user_id = $1
    `;
    
    const cartResult = await pg.query(cartQuery, [userId]);
    
    if (cartResult.rows.length === 0) {
      throw new Error('Cart is empty');
    }
    
    const cartItems = cartResult.rows;
    
    // Calculate totals
    const subtotal = cartItems.reduce((sum, item) => sum + (item.base_price * item.quantity), 0);
    const taxAmount = Math.round(subtotal * 0.05); // 5% GST
    const shippingAmount = subtotal > 1500 ? 0 : 60;
    const discountAmount = orderData.coupon_code ? await calculateDiscount(orderData.coupon_code, subtotal) : 0;
    const totalAmount = subtotal + taxAmount + shippingAmount - discountAmount;
    
    // Generate order number
    const orderNumber = generateOrderNumber();
    
    // Create order
    const orderQuery = `
      INSERT INTO orders (order_number, user_id, status, total_amount, subtotal,
                         tax_amount, shipping_amount, discount_amount, currency,
                         payment_status, shipping_address_id, billing_address_id,
                         expected_delivery_date, notes, coupon_code)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
      RETURNING *
    `;
    
    const orderResult = await pg.query(orderQuery, [
      orderNumber,
      userId,
      'pending',
      totalAmount,
      subtotal,
      taxAmount,
      shippingAmount,
      discountAmount,
      'INR',
      'pending',
      orderData.shipping_address_id || null,
      orderData.billing_address_id || null,
      orderData.expected_delivery_date || null,
      orderData.notes || null,
      orderData.coupon_code || null
    ]);
    
    const order = orderResult.rows[0];
    
    // Create order items
    for (const cartItem of cartItems) {
      const itemQuery = `
        INSERT INTO order_items (order_id, product_id, product_name, product_sku,
                                quantity, unit_price, total_price, attributes)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      `;
      
      await pg.query(itemQuery, [
        order.id,
        cartItem.product_id,
        cartItem.product_name,
        null, // SKU from product
        cartItem.quantity,
        cartItem.base_price,
        cartItem.base_price * cartItem.quantity,
        JSON.stringify(cartItem.attributes || {})
      ]);
    }
    
    // Clear cart
    await clearCart(userId);
    
    // Emit WebSocket event
    const io = require('../index').app.get('io');
    if (io) {
      io.to(`user:${userId}`).emit('order_created', {
        order_id: order.id,
        order_number: order.order_number,
        total_amount: order.total_amount
      });
    }
    
    logger.info(`Order created: ${orderNumber} for user ${userId}`);
    
    return order;
  } catch (error) {
    logger.error('Error creating order:', error);
    throw error;
  }
}

/**
 * Get order by ID
 */
async function getOrderById(orderId, userId = null) {
  try {
    const pg = getPostgreSQL();
    
    let query = `
      SELECT o.*, u.name as customer_name, u.email as customer_email,
             sa.address_line1 as shipping_line1, sa.city as shipping_city,
             sa.state as shipping_state, sa.pincode as shipping_pincode,
             ba.address_line1 as billing_line1, ba.city as billing_city,
             ba.state as billing_state, ba.pincode as billing_pincode
      FROM orders o
      JOIN users u ON o.user_id = u.id
      LEFT JOIN addresses sa ON o.shipping_address_id = sa.id
      LEFT JOIN addresses ba ON o.billing_address_id = ba.id
      WHERE o.id = $1
    `;
    
    const params = [orderId];
    
    // If userId provided, add user filter
    if (userId) {
      query += ' AND o.user_id = $2';
      params.push(userId);
    }
    
    const result = await pg.query(query, params);
    
    if (result.rows.length === 0) {
      throw new Error('Order not found');
    }
    
    const order = result.rows[0];
    
    // Get order items
    const itemsQuery = `
      SELECT oi.*, p.slug, p.images
      FROM order_items oi
      LEFT JOIN products p ON oi.product_id = p.id
      WHERE oi.order_id = $1
    `;
    
    const itemsResult = await pg.query(itemsQuery, [orderId]);
    
    order.items = itemsResult.rows;
    
    return order;
  } catch (error) {
    logger.error('Error fetching order:', error);
    throw error;
  }
}

/**
 * Get user's orders
 */
async function getUserOrders(userId, filters = {}, pagination = {}) {
  try {
    const pg = getPostgreSQL();
    
    const { status, search } = filters;
    const { page = 1, limit = 20, sort_by = 'created_at', sort_order = 'DESC' } = pagination;
    
    const offset = (page - 1) * limit;
    
    let query = `
      SELECT o.*, COUNT(oi.id) as item_count
      FROM orders o
      LEFT JOIN order_items oi ON o.id = oi.order_id
      WHERE o.user_id = $1
    `;
    
    const params = [userId];
    let paramCount = 1;
    
    if (status) {
      paramCount++;
      query += ` AND o.status = $${paramCount}`;
      params.push(status);
    }
    
    if (search) {
      paramCount++;
      query += ` AND (o.order_number ILIKE $${paramCount})`;
      params.push(`%${search}%`);
    }
    
    query += ` GROUP BY o.id ORDER BY o.${sort_by} ${sort_order} LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}`;
    params.push(limit, offset);
    
    const result = await pg.query(query, params);
    
    // Get total count
    const countQuery = `
      SELECT COUNT(*) FROM orders WHERE user_id = $1
      ${status ? `AND status = $2` : ''}
      ${search ? `AND order_number ILIKE $${status ? 3 : 2}` : ''}
    `;
    
    const countParams = [userId];
    if (status) countParams.push(status);
    if (search) countParams.push(`%${search}%`);
    
    const countResult = await pg.query(countQuery, countParams);
    const total = parseInt(countResult.rows[0].count);
    
    return {
      orders: result.rows,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    };
  } catch (error) {
    logger.error('Error fetching user orders:', error);
    throw error;
  }
}

/**
 * Update order status
 */
async function updateOrderStatus(orderId, status, notes = null) {
  try {
    const pg = getPostgreSQL();
    
    const query = `
      UPDATE orders
      SET status = $1, notes = COALESCE($2, notes), updated_at = NOW()
      WHERE id = $3
      RETURNING *
    `;
    
    const result = await pg.query(query, [status, notes, orderId]);
    
    if (result.rows.length === 0) {
      throw new Error('Order not found');
    }
    
    const order = result.rows[0];
    
    // Emit WebSocket event
    const io = require('../index').app.get('io');
    if (io) {
      io.to(`order:${orderId}`).emit('order_status_updated', {
        order_id: orderId,
        status: status,
        notes: notes
      });
      
      io.to(`user:${order.user_id}`).emit('order_updated', {
        order_id: orderId,
        status: status
      });
    }
    
    logger.info(`Order status updated: ${orderId} to ${status}`);
    
    return order;
  } catch (error) {
    logger.error('Error updating order status:', error);
    throw error;
  }
}

/**
 * Process payment
 */
async function processPayment(orderId, paymentData) {
  try {
    const pg = getPostgreSQL();
    
    // Get order
    const orderQuery = 'SELECT * FROM orders WHERE id = $1';
    const orderResult = await pg.query(orderQuery, [orderId]);
    
    if (orderResult.rows.length === 0) {
      throw new Error('Order not found');
    }
    
    const order = orderResult.rows[0];
    
    if (order.payment_status === 'completed') {
      throw new Error('Payment already completed');
    }
    
    // Process payment (in production, integrate with payment gateway)
    const paymentResult = await processPaymentGateway(paymentData, order.total_amount);
    
    // Create payment record
    const paymentQuery = `
      INSERT INTO payments (order_id, user_id, amount, currency, payment_method,
                          payment_status, transaction_id, gateway_response, paid_at)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW())
      RETURNING *
    `;
    
    const paymentRecord = await pg.query(paymentQuery, [
      orderId,
      order.user_id,
      order.total_amount,
      'INR',
      paymentData.payment_method,
      'completed',
      paymentResult.transaction_id,
      JSON.stringify(paymentResult)
    ]);
    
    // Update order payment status
    await pg.query(
      'UPDATE orders SET payment_status = $1, status = $2 WHERE id = $3',
      ['completed', 'confirmed', orderId]
    );
    
    logger.info(`Payment processed: order ${orderId}, amount ${order.total_amount}`);
    
    return paymentRecord.rows[0];
  } catch (error) {
    logger.error('Error processing payment:', error);
    throw error;
  }
}

/**
 * Calculate discount from coupon
 */
async function calculateDiscount(couponCode, orderAmount) {
  try {
    const pg = getPostgreSQL();
    
    const query = `
      SELECT * FROM coupons
      WHERE code = $1
        AND is_active = TRUE
        AND (valid_from IS NULL OR valid_from <= NOW())
        AND (valid_until IS NULL OR valid_until >= NOW())
    `;
    
    const result = await pg.query(query, [couponCode.toUpperCase()]);
    
    if (result.rows.length === 0) {
      return 0;
    }
    
    const coupon = result.rows[0];
    
    // Check minimum order value
    if (coupon.minimum_order_value && orderAmount < coupon.minimum_order_value) {
      return 0;
    }
    
    // Check usage limit
    if (coupon.usage_limit && coupon.used_count >= coupon.usage_limit) {
      return 0;
    }
    
    // Calculate discount
    let discount = 0;
    if (coupon.discount_type === 'percentage') {
      discount = orderAmount * (coupon.discount_value / 100);
    } else {
      discount = coupon.discount_value;
    }
    
    // Apply maximum discount limit
    if (coupon.maximum_discount_amount && discount > coupon.maximum_discount_amount) {
      discount = coupon.maximum_discount_amount;
    }
    
    // Update used count
    await pg.query(
      'UPDATE coupons SET used_count = used_count + 1 WHERE id = $1',
      [coupon.id]
    );
    
    return Math.round(discount);
  } catch (error) {
    logger.error('Error calculating discount:', error);
    return 0;
  }
}

/**
 * Helper function to generate order number
 */
function generateOrderNumber() {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = crypto.randomBytes(3).toString('hex').substring(0, 6).toUpperCase();
  return `AFR-${timestamp}-${random}`;
}

/**
 * Mock payment gateway processing
 */
async function processPaymentGateway(paymentData, amount) {
  // In production, integrate with actual payment gateway (Razorpay, Stripe, etc.)
  return {
    success: true,
    transaction_id: `TXN-${Date.now()}`,
    amount: amount,
    currency: 'INR',
    payment_method: paymentData.payment_method
  };
}

/**
 * Express router for order service
 */
const express = require('express');
const router = express.Router();

// Get cart
router.get('/cart', async (req, res) => {
  try {
    const userId = req.user.id; // From auth middleware
    const cart = await getCart(userId);
    res.json(cart);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Add to cart
router.post('/cart', async (req, res) => {
  try {
    const userId = req.user.id;
    const { product_id, quantity, attributes } = req.body;
    const cartItem = await addToCart(userId, product_id, quantity, attributes);
    res.json(cartItem);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Update cart item
router.put('/cart/:id', async (req, res) => {
  try {
    const userId = req.user.id;
    const { quantity } = req.body;
    const cartItem = await updateCartItem(userId, req.params.id, quantity);
    res.json(cartItem);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Remove from cart
router.delete('/cart/:id', async (req, res) => {
  try {
    const userId = req.user.id;
    const cartItem = await removeFromCart(userId, req.params.id);
    res.json(cartItem);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Clear cart
router.delete('/cart', async (req, res) => {
  try {
    const userId = req.user.id;
    const result = await clearCart(userId);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create order
router.post('/', async (req, res) => {
  try {
    const userId = req.user.id;
    const order = await createOrder(userId, req.body);
    res.status(201).json(order);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Get order by ID
router.get('/:id', async (req, res) => {
  try {
    const userId = req.user.id;
    const order = await getOrderById(req.params.id, userId);
    res.json(order);
  } catch (error) {
    if (error.message === 'Order not found') {
      res.status(404).json({ error: error.message });
    } else {
      res.status(500).json({ error: error.message });
    }
  }
});

// Get user orders
router.get('/', async (req, res) => {
  try {
    const userId = req.user.id;
    const filters = {
      status: req.query.status,
      search: req.query.search
    };
    const pagination = {
      page: parseInt(req.query.page) || 1,
      limit: parseInt(req.query.limit) || 20,
      sort_by: req.query.sort_by,
      sort_order: req.query.sort_order
    };
    const result = await getUserOrders(userId, filters, pagination);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update order status
router.put('/:id/status', async (req, res) => {
  try {
    const { status, notes } = req.body;
    const order = await updateOrderStatus(req.params.id, status, notes);
    res.json(order);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Process payment
router.post('/:id/payment', async (req, res) => {
  try {
    const payment = await processPayment(req.params.id, req.body);
    res.json(payment);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

module.exports = {
  router,
  getCart,
  addToCart,
  updateCartItem,
  removeFromCart,
  clearCart,
  createOrder,
  getOrderById,
  getUserOrders,
  updateOrderStatus,
  processPayment
};
