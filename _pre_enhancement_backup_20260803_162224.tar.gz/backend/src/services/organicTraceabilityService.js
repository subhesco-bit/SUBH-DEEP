/**
 * Organic Traceability Service
 * Manages end-to-end organic traceability from seed to consumer
 */

const express = require('express');
const { Pool } = require('pg');
const { logger } = require('../utils/logger');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();
const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

// ============================================================================
// ORGANIC FARM REGISTRY
// ============================================================================

/**
 * Register organic farm
 */
async function registerOrganicFarm(data) {
  const {
    farmer_id,
    farm_name,
    certification_standard_id,
    total_area_hectares,
    organic_area_hectares,
    location_id,
    gps_coordinates
  } = data;

  try {
    const result = await pool.query(
      `INSERT INTO organic_farms 
       (farm_id, farmer_id, farm_name, certification_standard_id, total_area_hectares, 
        organic_area_hectares, location_id, gps_coordinates, certification_status)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'pending')
       RETURNING *`,
      [
        `ORG-${Date.now()}`,
        farmer_id,
        farm_name,
        certification_standard_id,
        total_area_hectares,
        organic_area_hectares,
        location_id,
        JSON.stringify(gps_coordinates)
      ]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Register organic farm error:', error);
    throw error;
  }
}

/**
 * API endpoint to register organic farm
 */
router.post('/farms', authMiddleware, async (req, res) => {
  try {
    const result = await registerOrganicFarm(req.body);
    res.status(201).json(result);
  } catch (error) {
    logger.error('Register farm API error:', error);
    res.status(500).json({ error: 'Failed to register organic farm' });
  }
});

/**
 * Get organic farms for a farmer
 */
async function getOrganicFarms(farmerId) {
  try {
    const result = await pool.query(
      `SELECT of.*, os.name as standard_name, os.code as standard_code,
       a.city, a.state, a.pincode
       FROM organic_farms of
       LEFT JOIN organic_standards os ON of.certification_standard_id = os.id
       LEFT JOIN addresses a ON of.location_id = a.id
       WHERE of.farmer_id = $1
       ORDER BY of.created_at DESC`,
      [farmerId]
    );
    return result.rows;
  } catch (error) {
    logger.error('Get organic farms error:', error);
    throw error;
  }
}

/**
 * API endpoint to get organic farms
 */
router.get('/farms', authMiddleware, async (req, res) => {
  try {
    const result = await getOrganicFarms(req.user.id);
    res.json(result);
  } catch (error) {
    logger.error('Get farms API error:', error);
    res.status(500).json({ error: 'Failed to get organic farms' });
  }
});

// ============================================================================
// ORGANIC PLOTS
// ============================================================================

/**
 * Add organic plot
 */
async function addOrganicPlot(data) {
  const {
    organic_farm_id,
    plot_number,
    plot_name,
    area_hectares,
    certification_status,
    gps_boundary,
    soil_type,
    irrigation_type
  } = data;

  try {
    const result = await pool.query(
      `INSERT INTO organic_plots 
       (organic_farm_id, plot_number, plot_name, area_hectares, certification_status, 
        gps_boundary, soil_type, irrigation_type)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING *`,
      [
        organic_farm_id,
        plot_number,
        plot_name,
        area_hectares,
        certification_status,
        JSON.stringify(gps_boundary),
        soil_type,
        irrigation_type
      ]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Add organic plot error:', error);
    throw error;
  }
}

/**
 * API endpoint to add organic plot
 */
router.post('/plots', authMiddleware, async (req, res) => {
  try {
    const result = await addOrganicPlot(req.body);
    res.status(201).json(result);
  } catch (error) {
    logger.error('Add plot API error:', error);
    res.status(500).json({ error: 'Failed to add organic plot' });
  }
});

/**
 * Get plots for a farm
 */
async function getOrganicPlots(farmId) {
  try {
    const result = await pool.query(
      'SELECT * FROM organic_plots WHERE organic_farm_id = $1 ORDER BY plot_number',
      [farmId]
    );
    return result.rows;
  } catch (error) {
    logger.error('Get organic plots error:', error);
    throw error;
  }
}

/**
 * API endpoint to get plots
 */
router.get('/farms/:farmId/plots', authMiddleware, async (req, res) => {
  try {
    const result = await getOrganicPlots(req.params.farmId);
    res.json(result);
  } catch (error) {
    logger.error('Get plots API error:', error);
    res.status(500).json({ error: 'Failed to get organic plots' });
  }
});

// ============================================================================
// ORGANIC CROP PRODUCTION
// ============================================================================

/**
 * Record organic crop
 */
async function recordOrganicCrop(data) {
  const {
    organic_plot_id,
    crop_name,
    variety,
    planting_date,
    expected_harvest_date,
    area_hectares,
    expected_yield_kg_per_hectare,
    seed_source,
    seed_lot_number,
    cultivation_practices,
    pest_management_practices,
    soil_management_practices,
    water_management_practices
  } = data;

  try {
    const result = await pool.query(
      `INSERT INTO organic_crops 
       (organic_plot_id, crop_name, variety, planting_date, expected_harvest_date, 
        area_hectares, expected_yield_kg_per_hectare, seed_source, seed_lot_number,
        cultivation_practices, pest_management_practices, soil_management_practices, 
        water_management_practices, status)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, 'growing')
       RETURNING *`,
      [
        organic_plot_id,
        crop_name,
        variety,
        planting_date,
        expected_harvest_date,
        area_hectares,
        expected_yield_kg_per_hectare,
        seed_source,
        seed_lot_number,
        JSON.stringify(cultivation_practices),
        JSON.stringify(pest_management_practices),
        JSON.stringify(soil_management_practices),
        JSON.stringify(water_management_practices)
      ]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Record organic crop error:', error);
    throw error;
  }
}

/**
 * API endpoint to record organic crop
 */
router.post('/crops', authMiddleware, async (req, res) => {
  try {
    const result = await recordOrganicCrop(req.body);
    res.status(201).json(result);
  } catch (error) {
    logger.error('Record crop API error:', error);
    res.status(500).json({ error: 'Failed to record organic crop' });
  }
});

/**
 * Record harvest
 */
async function recordHarvest(data) {
  const {
    organic_crop_id,
    harvest_date,
    total_quantity_kg,
    grade,
    moisture_content,
    quality_parameters,
    harvested_by,
    storage_location
  } = data;

  try {
    const result = await pool.query(
      `INSERT INTO organic_harvests 
       (organic_crop_id, harvest_number, harvest_date, total_quantity_kg, grade,
        moisture_content, quality_parameters, harvested_by, storage_location, batch_number)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
       RETURNING *`,
      [
        organic_crop_id,
        `HVST-${Date.now()}`,
        harvest_date,
        total_quantity_kg,
        grade,
        moisture_content,
        JSON.stringify(quality_parameters),
        harvested_by,
        storage_location,
        `BATCH-${Date.now()}`
      ]
    );

    // Update crop status
    await pool.query(
      'UPDATE organic_crops SET actual_harvest_date = $1, actual_yield_kg = $2, status = $3 WHERE id = $4',
      [harvest_date, total_quantity_kg, 'harvested', organic_crop_id]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Record harvest error:', error);
    throw error;
  }
}

/**
 * API endpoint to record harvest
 */
router.post('/harvests', authMiddleware, async (req, res) => {
  try {
    const result = await recordHarvest(req.body);
    res.status(201).json(result);
  } catch (error) {
    logger.error('Record harvest API error:', error);
    res.status(500).json({ error: 'Failed to record harvest' });
  }
});

// ============================================================================
// CHAIN OF CUSTODY
// ============================================================================

/**
 * Record chain of custody transfer
 */
async function recordChainOfCustody(data) {
  const {
    product_id,
    lot_number,
    current_holder_type,
    current_holder_id,
    custody_transfer_date,
    transfer_from_type,
    transfer_from_id,
    quantity_kg,
    document_reference
  } = data;

  try {
    const result = await pool.query(
      `INSERT INTO organic_chain_of_custody 
       (product_id, lot_number, current_holder_type, current_holder_id, 
        custody_transfer_date, transfer_from_type, transfer_from_id, quantity_kg, document_reference)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING *`,
      [
        product_id,
        lot_number,
        current_holder_type,
        current_holder_id,
        custody_transfer_date,
        transfer_from_type,
        transfer_from_id,
        quantity_kg,
        document_reference
      ]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Record chain of custody error:', error);
    throw error;
  }
}

/**
 * API endpoint to record chain of custody
 */
router.post('/chain-of-custody', authMiddleware, async (req, res) => {
  try {
    const result = await recordChainOfCustody(req.body);
    res.status(201).json(result);
  } catch (error) {
    logger.error('Record chain of custody API error:', error);
    res.status(500).json({ error: 'Failed to record chain of custody' });
  }
});

/**
 * Get chain of custody for a product
 */
async function getChainOfCustody(productId, lotNumber) {
  try {
    const result = await pool.query(
      `SELECT * FROM organic_chain_of_custody 
       WHERE product_id = $1 OR lot_number = $2
       ORDER BY custody_transfer_date ASC`,
      [productId, lotNumber]
    );
    return result.rows;
  } catch (error) {
    logger.error('Get chain of custody error:', error);
    throw error;
  }
}

/**
 * API endpoint to get chain of custody
 */
router.get('/chain-of-custody/:productId', authMiddleware, async (req, res) => {
  try {
    const { productId } = req.params;
    const { lot_number } = req.query;
    const result = await getChainOfCustody(productId, lot_number);
    res.json(result);
  } catch (error) {
    logger.error('Get chain of custody API error:', error);
    res.status(500).json({ error: 'Failed to get chain of custody' });
  }
});

// ============================================================================
// CONSUMER TRANSPARENCY (QR CODE)
// ============================================================================

/**
 * Generate QR code data for consumer transparency
 */
async function generateQRCodeData(productId, lotNumber) {
  try {
    const result = await pool.query(
      'SELECT generate_organic_qr_data($1, $2) as qr_data',
      [productId, lotNumber]
    );

    if (result.rows.length === 0 || !result.rows[0].qr_data) {
      throw new Error('No organic traceability data found');
    }

    return result.rows[0].qr_data;
  } catch (error) {
    logger.error('Generate QR code data error:', error);
    throw error;
  }
}

/**
 * API endpoint to generate QR code data
 */
router.get('/qr-data/:productId', authMiddleware, async (req, res) => {
  try {
    const { productId } = req.params;
    const { lot_number } = req.query;
    const result = await generateQRCodeData(productId, lot_number);
    res.json(result);
  } catch (error) {
    logger.error('Generate QR data API error:', error);
    res.status(500).json({ error: 'Failed to generate QR code data' });
  }
});

/**
 * Save consumer transparency record
 */
async function saveConsumerTransparency(data) {
  const {
    product_id,
    lot_number,
    qr_code,
    farmer_name,
    farm_location,
    farm_certification_number,
    harvest_date,
    processing_facility,
    processing_date,
    packaging_date,
    ingredients,
    nutritional_info,
    organic_certification_details,
    chain_of_custody_summary,
    quality_test_results
  } = data;

  try {
    const result = await pool.query(
      `INSERT INTO organic_consumer_transparency 
       (product_id, lot_number, qr_code, farmer_name, farm_location, 
        farm_certification_number, harvest_date, processing_facility, processing_date,
        packaging_date, ingredients, nutritional_info, organic_certification_details,
        chain_of_custody_summary, quality_test_results)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
       RETURNING *`,
      [
        product_id,
        lot_number,
        qr_code,
        farmer_name,
        farm_location,
        farm_certification_number,
        harvest_date,
        processing_facility,
        processing_date,
        packaging_date,
        JSON.stringify(ingredients),
        JSON.stringify(nutritional_info),
        JSON.stringify(organic_certification_details),
        JSON.stringify(chain_of_custody_summary),
        JSON.stringify(quality_test_results)
      ]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Save consumer transparency error:', error);
    throw error;
  }
}

/**
 * API endpoint to save consumer transparency
 */
router.post('/consumer-transparency', authMiddleware, async (req, res) => {
  try {
    const result = await saveConsumerTransparency(req.body);
    res.status(201).json(result);
  } catch (error) {
    logger.error('Save consumer transparency API error:', error);
    res.status(500).json({ error: 'Failed to save consumer transparency data' });
  }
});

/**
 * Get consumer transparency by QR code
 */
async function getConsumerTransparencyByQR(qrCode) {
  try {
    const result = await pool.query(
      'SELECT * FROM organic_consumer_transparency WHERE qr_code = $1',
      [qrCode]
    );

    if (result.rows.length === 0) {
      throw new Error('QR code not found');
    }

    return result.rows[0];
  } catch (error) {
    logger.error('Get consumer transparency error:', error);
    throw error;
  }
}

/**
 * API endpoint to get consumer transparency by QR code (public endpoint)
 */
router.get('/consumer-transparency/qr/:qrCode', async (req, res) => {
  try {
    const result = await getConsumerTransparencyByQR(req.params.qrCode);
    res.json(result);
  } catch (error) {
    logger.error('Get consumer transparency API error:', error);
    res.status(404).json({ error: 'QR code not found' });
  }
});

// ============================================================================
// ORGANIC STANDARDS
// ============================================================================

/**
 * Get all organic standards
 */
async function getOrganicStandards() {
  try {
    const result = await pool.query(
      'SELECT * FROM organic_standards WHERE is_active = true ORDER BY name'
    );
    return result.rows;
  } catch (error) {
    logger.error('Get organic standards error:', error);
    throw error;
  }
}

/**
 * API endpoint to get organic standards
 */
router.get('/standards', async (req, res) => {
  try {
    const result = await getOrganicStandards();
    res.json(result);
  } catch (error) {
    logger.error('Get standards API error:', error);
    res.status(500).json({ error: 'Failed to get organic standards' });
  }
});

// ============================================================================
// ORGANIC FRAUD ALERTS
// ============================================================================

/**
 * Report organic fraud
 */
async function reportFraud(data) {
  const {
    alert_type,
    severity,
    entity_type,
    entity_id,
    description,
    evidence
  } = data;

  try {
    const result = await pool.query(
      `INSERT INTO organic_fraud_alerts 
       (alert_type, severity, entity_type, entity_id, description, evidence)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING *`,
      [
        alert_type,
        severity,
        entity_type,
        entity_id,
        description,
        JSON.stringify(evidence)
      ]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Report fraud error:', error);
    throw error;
  }
}

/**
 * API endpoint to report fraud
 */
router.post('/fraud-alerts', authMiddleware, async (req, res) => {
  try {
    const result = await reportFraud(req.body);
    res.status(201).json(result);
  } catch (error) {
    logger.error('Report fraud API error:', error);
    res.status(500).json({ error: 'Failed to report fraud' });
  }
});

// ============================================================================
// HEALTH CHECK
// ============================================================================

function isHealthy() {
  return pool.connect().then(() => true).catch(() => false);
}

module.exports = {
  router,
  registerOrganicFarm,
  getOrganicFarms,
  addOrganicPlot,
  getOrganicPlots,
  recordOrganicCrop,
  recordHarvest,
  recordChainOfCustody,
  getChainOfCustody,
  generateQRCodeData,
  saveConsumerTransparency,
  getConsumerTransparencyByQR,
  getOrganicStandards,
  reportFraud,
  isHealthy
};
