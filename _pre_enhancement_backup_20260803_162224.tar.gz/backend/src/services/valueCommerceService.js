/**
 * Value-Based Commerce Service
 * Commerce platform based on value (nutrition, quality, sustainability) rather than weight
 */

const express = require('express');
const { Pool } = require('pg');
const { logger } = require('../utils/logger');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();
const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

// ============================================================================
// VALUE FACTORS
// ============================================================================

/**
 * Get all value factors
 */
async function getValueFactors() {
  try {
    const result = await pool.query(
      'SELECT * FROM value_factors WHERE is_active = true ORDER BY weight DESC'
    );
    return result.rows;
  } catch (error) {
    logger.error('Get value factors error:', error);
    throw error;
  }
}

/**
 * API endpoint to get value factors
 */
router.get('/value-factors', async (req, res) => {
  try {
    const result = await getValueFactors();
    res.json(result);
  } catch (error) {
    logger.error('Get value factors API error:', error);
    res.status(500).json({ error: 'Failed to get value factors' });
  }
});

// ============================================================================
// PRODUCT VALUE SCORES
// ============================================================================

/**
 * Calculate product value score
 */
async function calculateProductValueScore(data) {
  const {
    product_id,
    nutrition_score,
    organic_score,
    gi_score,
    freshness_score,
    sustainability_score,
    quality_score
  } = data;

  try {
    const overallScore = await pool.query(
      `SELECT calculate_value_score($1, $2, $3, $4, $5, $6) as score`,
      [nutrition_score, organic_score, gi_score, freshness_score, sustainability_score, quality_score]
    );

    const gradeResult = await pool.query(
      'SELECT assign_value_grade($1) as grade',
      [overallScore.rows[0].score]
    );

    const validUntil = new Date();
    validUntil.setDate(validUntil.getDate() + 30); // Valid for 30 days

    const result = await pool.query(
      `INSERT INTO product_value_scores 
       (product_id, nutrition_score, organic_score, gi_score, freshness_score, 
        sustainability_score, quality_score, overall_value_score, value_grade, valid_until)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
       RETURNING *`,
      [
        product_id,
        nutrition_score,
        organic_score,
        gi_score,
        freshness_score,
        sustainability_score,
        quality_score,
        overallScore.rows[0].score,
        gradeResult.rows[0].grade,
        validUntil
      ]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Calculate product value score error:', error);
    throw error;
  }
}

/**
 * API endpoint to calculate product value score
 */
router.post('/product-value-scores', authMiddleware, async (req, res) => {
  try {
    const result = await calculateProductValueScore(req.body);
    res.status(201).json(result);
  } catch (error) {
    logger.error('Calculate product value score API error:', error);
    res.status(500).json({ error: 'Failed to calculate product value score' });
  }
});

/**
 * Get product value score
 */
async function getProductValueScore(productId) {
  try {
    const result = await pool.query(
      `SELECT * FROM product_value_scores 
       WHERE product_id = $1 
       AND (valid_until IS NULL OR valid_until > CURRENT_TIMESTAMP)
       ORDER BY calculated_at DESC 
       LIMIT 1`,
      [productId]
    );

    if (result.rows.length === 0) {
      throw new Error('No valid value score found');
    }

    return result.rows[0];
  } catch (error) {
    logger.error('Get product value score error:', error);
    throw error;
  }
}

/**
 * API endpoint to get product value score
 */
router.get('/product-value-scores/:productId', async (req, res) => {
  try {
    const result = await getProductValueScore(req.params.productId);
    res.json(result);
  } catch (error) {
    logger.error('Get product value score API error:', error);
    res.status(404).json({ error: 'Product value score not found' });
  }
});

// ============================================================================
// VALUE-BASED PRICING
// ============================================================================

/**
 * Calculate value-based price
 */
async function calculateValueBasedPrice(productId, basePrice) {
  try {
    const valueScore = await getProductValueScore(productId);

    const pricing = await pool.query(
      'SELECT calculate_value_price($1, $2, $3) as pricing',
      [basePrice, valueScore.overall_value_score, valueScore.value_grade]
    );

    const pricingData = pricing.rows[0].pricing;

    // Save pricing record
    await pool.query(
      `INSERT INTO product_value_pricing 
       (product_id, value_score_id, base_price, value_premium, final_price, premium_percentage, value_factors_breakdown)
       VALUES ($1, $2, $3, $4, $5, $6, $7)`,
      [
        productId,
        valueScore.id,
        pricingData.base_price,
        pricingData.value_premium,
        pricingData.final_price,
        pricingData.premium_percentage,
        JSON.stringify(pricingData)
      ]
    );

    return pricingData;
  } catch (error) {
    logger.error('Calculate value-based price error:', error);
    throw error;
  }
}

/**
 * API endpoint to calculate value-based price
 */
router.post('/value-pricing', authMiddleware, async (req, res) => {
  try {
    const { product_id, base_price } = req.body;
    const result = await calculateValueBasedPrice(product_id, base_price);
    res.json(result);
  } catch (error) {
    logger.error('Calculate value-based price API error:', error);
    res.status(500).json({ error: 'Failed to calculate value-based price' });
  }
});

// ============================================================================
// CONSUMER VALUE PREFERENCES
// ============================================================================

/**
 * Set consumer value preferences
 */
async function setConsumerValuePreferences(userId, preferences) {
  try {
    const result = await pool.query(
      `INSERT INTO consumer_value_preferences 
       (user_id, nutrition_importance, organic_importance, gi_importance, 
        freshness_importance, sustainability_importance, quality_importance, 
        min_value_score, preferred_tiers)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       ON CONFLICT (user_id)
       DO UPDATE SET
         nutrition_importance = EXCLUDED.nutrition_importance,
         organic_importance = EXCLUDED.organic_importance,
         gi_importance = EXCLUDED.gi_importance,
         freshness_importance = EXCLUDED.freshness_importance,
         sustainability_importance = EXCLUDED.sustainability_importance,
         quality_importance = EXCLUDED.quality_importance,
         min_value_score = EXCLUDED.min_value_score,
         preferred_tiers = EXCLUDED.preferred_tiers,
         updated_at = CURRENT_TIMESTAMP
       RETURNING *`,
      [
        userId,
        preferences.nutrition_importance || 1.0,
        preferences.organic_importance || 1.0,
        preferences.gi_importance || 1.0,
        preferences.freshness_importance || 1.0,
        preferences.sustainability_importance || 1.0,
        preferences.quality_importance || 1.0,
        preferences.min_value_score,
        JSON.stringify(preferences.preferred_tiers || [])
      ]
    );

    return result.rows[0];
  } catch (error) {
    logger.error('Set consumer value preferences error:', error);
    throw error;
  }
}

/**
 * API endpoint to set consumer value preferences
 */
router.post('/consumer-preferences', authMiddleware, async (req, res) => {
  try {
    const result = await setConsumerValuePreferences(req.user.id, req.body);
    res.json(result);
  } catch (error) {
    logger.error('Set consumer preferences API error:', error);
    res.status(500).json({ error: 'Failed to set consumer preferences' });
  }
});

/**
 * Get consumer value preferences
 */
async function getConsumerValuePreferences(userId) {
  try {
    const result = await pool.query(
      'SELECT * FROM consumer_value_preferences WHERE user_id = $1',
      [userId]
    );

    if (result.rows.length === 0) {
      // Return default preferences
      return {
        nutrition_importance: 1.0,
        organic_importance: 1.0,
        gi_importance: 1.0,
        freshness_importance: 1.0,
        sustainability_importance: 1.0,
        quality_importance: 1.0
      };
    }

    return result.rows[0];
  } catch (error) {
    logger.error('Get consumer value preferences error:', error);
    throw error;
  }
}

/**
 * API endpoint to get consumer value preferences
 */
router.get('/consumer-preferences', authMiddleware, async (req, res) => {
  try {
    const result = await getConsumerValuePreferences(req.user.id);
    res.json(result);
  } catch (error) {
    logger.error('Get consumer preferences API error:', error);
    res.status(500).json({ error: 'Failed to get consumer preferences' });
  }
});

// ============================================================================
// VALUE-BASED RECOMMENDATIONS
// ============================================================================

/**
 * Generate value-based recommendations
 */
async function generateValueRecommendations(userId, limit = 10) {
  try {
    const preferences = await getConsumerValuePreferences(userId);

    // Get products with value scores that match preferences
    const result = await pool.query(
      `SELECT pvs.*, p.name, p.base_price, pvp.final_price, pvp.premium_percentage
       FROM product_value_scores pvs
       LEFT JOIN products p ON pvs.product_id = p.id
       LEFT JOIN product_value_pricing pvp ON pvs.id = pvp.value_score_id
       WHERE pvs.overall_value_score >= COALESCE($1, 0)
       AND (pvs.valid_until IS NULL OR pvs.valid_until > CURRENT_TIMESTAMP)
       ORDER BY pvs.overall_value_score DESC
       LIMIT $2`,
      [preferences.min_value_score, limit]
    );

    const recommendations = result.rows.map(row => {
      const matchScore = row.overall_value_score;
      const priceValueRatio = row.final_price > 0 ? matchScore / row.final_price * 100 : 0;

      return {
        product_id: row.product_id,
        product_name: row.name,
        value_score: row.overall_value_score,
        value_grade: row.value_grade,
        base_price: row.base_price,
        final_price: row.final_price,
        premium_percentage: row.premium_percentage,
        recommendation_score: matchScore,
        value_match_score: matchScore,
        price_value_ratio: priceValueRatio,
        recommendation_reasons: [
          `High value grade: ${row.value_grade}`,
          `Overall score: ${row.overall_value_score}`
        ]
      };
    });

    // Save recommendations
    for (const rec of recommendations) {
      await pool.query(
        `INSERT INTO value_recommendations 
         (user_id, product_id, recommendation_score, recommendation_reasons, 
          value_match_score, price_value_ratio)
         VALUES ($1, $2, $3, $4, $5, $6)
         ON CONFLICT (user_id, product_id)
         DO UPDATE SET
           recommendation_score = EXCLUDED.recommendation_score,
           generated_at = CURRENT_TIMESTAMP`,
        [
          userId,
          rec.product_id,
          rec.recommendation_score,
          JSON.stringify(rec.recommendation_reasons),
          rec.value_match_score,
          rec.price_value_ratio
        ]
      );
    }

    return recommendations;
  } catch (error) {
    logger.error('Generate value recommendations error:', error);
    throw error;
  }
}

/**
 * API endpoint to generate value-based recommendations
 */
router.get('/recommendations', authMiddleware, async (req, res) => {
  try {
    const { limit } = req.query;
    const result = await generateValueRecommendations(req.user.id, parseInt(limit) || 10);
    res.json(result);
  } catch (error) {
    logger.error('Generate recommendations API error:', error);
    res.status(500).json({ error: 'Failed to generate recommendations' });
  }
});

// ============================================================================
// VALUE TIERS
// ============================================================================

/**
 * Get value tiers
 */
async function getValueTiers() {
  try {
    const result = await pool.query(
      'SELECT * FROM value_tiers WHERE is_active = true ORDER BY min_score DESC'
    );
    return result.rows;
  } catch (error) {
    logger.error('Get value tiers error:', error);
    throw error;
  }
}

/**
 * API endpoint to get value tiers
 */
router.get('/value-tiers', async (req, res) => {
  try {
    const result = await getValueTiers();
    res.json(result);
  } catch (error) {
    logger.error('Get value tiers API error:', error);
    res.status(500).json({ error: 'Failed to get value tiers' });
  }
});

// ============================================================================
// HEALTH CHECK
// ============================================================================

function isHealthy() {
  return pool.connect().then(() => true).catch(() => false);
}

module.exports = {
  router,
  getValueFactors,
  calculateProductValueScore,
  getProductValueScore,
  calculateValueBasedPrice,
  setConsumerValuePreferences,
  getConsumerValuePreferences,
  generateValueRecommendations,
  getValueTiers,
  isHealthy
};
