import { Link, useNavigate } from 'react-router-dom'
import { ShoppingCart, User, Menu, Search, LogOut } from 'lucide-react'
import { useAuthStore } from '../store/authStore'
import { useState } from 'react'

function Header() {
  const { user, isAuthenticated, logout } = useAuthStore()
  const navigate = useNavigate()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const handleLogout = () => {
    logout()
    navigate('/')
  }

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-xl">A</span>
            </div>
            <span className="text-xl font-bold text-gray-800">AFRERA</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/marketplace" className="text-gray-700 hover:text-green-600 transition">
              Marketplace
            </Link>
            <Link to="/farmer-portal" className="text-gray-700 hover:text-green-600 transition">
              Farmer Portal
            </Link>
            <Link to="/logistics" className="text-gray-700 hover:text-green-600 transition">
              Logistics
            </Link>
            <Link to="/insurance" className="text-gray-700 hover:text-green-600 transition">
              Insurance
            </Link>
            <Link to="/forms" className="text-gray-700 hover:text-green-600 transition">
              Forms
            </Link>
            <Link to="/analytics" className="text-gray-700 hover:text-green-600 transition">
              Analytics
            </Link>
            <Link to="/modules" className="text-gray-700 hover:text-green-600 transition">
              Modules
            </Link>
          </nav>

          {/* Search Bar */}
          <div className="hidden md:flex items-center flex-1 max-w-md mx-8">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search products..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>
          </div>

          {/* Right Actions */}
          <div className="flex items-center space-x-4">
            {/* Cart */}
            <Link to="/cart" className="relative p-2 text-gray-700 hover:text-green-600 transition">
              <ShoppingCart className="w-6 h-6" />
              <span className="absolute -top-1 -right-1 bg-orange-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                0
              </span>
            </Link>

            {/* User Menu */}
            {isAuthenticated ? (
              <div className="relative group">
                <button className="flex items-center space-x-2 p-2 text-gray-700 hover:text-green-600 transition">
                  <User className="w-6 h-6" />
                  <span className="hidden md:inline">{user?.firstName || user?.email}</span>
                </button>
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-2 hidden group-hover:block">
                  <Link
                    to="/dashboard"
                    className="block px-4 py-2 text-gray-700 hover:bg-gray-100"
                  >
                    Dashboard
                  </Link>
                  <button
                    onClick={handleLogout}
                    className="w-full text-left px-4 py-2 text-gray-700 hover:bg-gray-100 flex items-center space-x-2"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Logout</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <Link
                  to="/login"
                  className="px-4 py-2 text-gray-700 hover:text-green-600 transition"
                >
                  Login
                </Link>
                <Link
                  to="/register"
                  className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition"
                >
                  Register
                </Link>
              </div>
            )}

            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2 text-gray-700"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              <Menu className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t">
            <nav className="flex flex-col space-y-4">
              <Link
                to="/marketplace"
                className="text-gray-700 hover:text-green-600 transition"
                onClick={() => setMobileMenuOpen(false)}
              >
                Marketplace
              </Link>
              <Link
                to="/farmer-portal"
                className="text-gray-700 hover:text-green-600 transition"
                onClick={() => setMobileMenuOpen(false)}
              >
                Farmer Portal
              </Link>
              <Link
                to="/logistics"
                className="text-gray-700 hover:text-green-600 transition"
                onClick={() => setMobileMenuOpen(false)}
              >
                Logistics
              </Link>
              <Link
                to="/insurance"
                className="text-gray-700 hover:text-green-600 transition"
                onClick={() => setMobileMenuOpen(false)}
              >
                Insurance
              </Link>
              <Link
                to="/forms"
                className="text-gray-700 hover:text-green-600 transition"
                onClick={() => setMobileMenuOpen(false)}
              >
                Forms
              </Link>
              <Link
                to="/analytics"
                className="text-gray-700 hover:text-green-600 transition"
                onClick={() => setMobileMenuOpen(false)}
              >
                Analytics
              </Link>
              <Link
                to="/modules"
                className="text-gray-700 hover:text-green-600 transition"
                onClick={() => setMobileMenuOpen(false)}
              >
                Modules
              </Link>
              <input
                type="text"
                placeholder="Search products..."
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </nav>
          </div>
        )}
      </div>
    </header>
  )
}

export default Header
