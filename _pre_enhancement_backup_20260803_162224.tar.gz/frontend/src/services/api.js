import axios from 'axios'

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001/api/v1'

// Create axios instance
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
})

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('access_token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => Promise.reject(error)
)

// Response interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config

    // Handle 401 Unauthorized - try to refresh token
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true

      try {
        const refreshToken = localStorage.getItem('refresh_token')
        const response = await axios.post(`${API_BASE_URL}/auth/refresh`, {
          refresh_token: refreshToken,
        })

        const { access_token, refresh_token: newRefreshToken } = response.data

        localStorage.setItem('access_token', access_token)
        localStorage.setItem('refresh_token', newRefreshToken)

        originalRequest.headers.Authorization = `Bearer ${access_token}`
        return api(originalRequest)
      } catch (refreshError) {
        // Refresh failed, logout user
        localStorage.removeItem('access_token')
        localStorage.removeItem('refresh_token')
        window.location.href = '/login'
        return Promise.reject(refreshError)
      }
    }

    return Promise.reject(error)
  }
)

// Auth API
export const authAPI = {
  register: (data) => api.post('/auth/register', data),
  login: (data) => api.post('/auth/login', data),
  logout: (data) => api.post('/auth/logout', data),
  refresh: (data) => api.post('/auth/refresh', data),
  getMe: () => api.get('/auth/me'),
  setup2FA: (userId) => api.post(`/auth/2fa/setup`, { user_id: userId }),
  verify2FA: (userId, code) => api.post(`/auth/2fa/verify`, { user_id: userId, code }),
  disable2FA: (userId, password) => api.post(`/auth/2fa/disable`, { user_id: userId, password }),
}

// Products API
export const productsAPI = {
  getProducts: (filters, pagination) => api.get('/products', { params: { ...filters, ...pagination } }),
  getProduct: (id) => api.get(`/products/${id}`),
  createProduct: (data) => api.post('/products', data),
  updateProduct: (id, data) => api.put(`/products/${id}`, data),
  deleteProduct: (id) => api.delete(`/products/${id}`),
  getCategories: () => api.get('/products/categories/list'),
  getStates: () => api.get('/products/states/list'),
  searchProducts: (query) => api.get('/products/search', { params: { q: query } }),
}

// Orders API
export const ordersAPI = {
  getCart: () => api.get('/orders/cart'),
  addToCart: (data) => api.post('/orders/cart', data),
  updateCartItem: (id, data) => api.put(`/orders/cart/${id}`, data),
  removeFromCart: (id) => api.delete(`/orders/cart/${id}`),
  clearCart: () => api.delete('/orders/cart'),
  createOrder: (data) => api.post('/orders', data),
  getOrder: (id) => api.get(`/orders/${id}`),
  getOrders: (filters, pagination) => api.get('/orders', { params: { ...filters, ...pagination } }),
  updateOrderStatus: (id, data) => api.put(`/orders/${id}/status`, data),
  processPayment: (id, data) => api.post(`/orders/${id}/payment`, data),
}

// Farmers API
export const farmersAPI = {
  getFarmer: (id) => api.get(`/farmers/${id}`),
  getFarmers: (filters, pagination) => api.get('/farmers', { params: { ...filters, ...pagination } }),
  calculateFDI: (id) => api.post(`/farmers/${id}/fdi`),
  addCertification: (id, data) => api.post(`/farmers/${id}/certifications`, data),
  getCertifications: (id) => api.get(`/farmers/${id}/certifications`),
  getFPOs: (filters) => api.get('/farmers/fpos/list', { params: filters }),
}

// Financial API
export const financialAPI = {
  applyForLoan: (data) => api.post('/financial/loans', data),
  getFarmerLoans: (farmerId, filters) => api.get(`/financial/loans/farmer/${farmerId}`, { params: filters }),
  approveLoan: (id, data) => api.post(`/financial/loans/${id}/approve`, data),
  getEMISchedule: (id) => api.get(`/financial/loans/${id}/emi`),
  payEMI: (id, data) => api.post(`/financial/emi/${id}/pay`, data),
  requestAdvance: (data) => api.post('/financial/advances', data),
  getFarmerAdvances: (farmerId) => api.get(`/financial/advances/farmer/${farmerId}`),
  getCreditScore: (farmerId) => api.get(`/financial/credit-score/${farmerId}`),
}

// Logistics API
export const logisticsAPI = {
  createShipment: (data) => api.post('/logistics/shipments', data),
  getShipment: (id) => api.get(`/logistics/shipments/${id}`),
  getShipments: (filters, pagination) => api.get('/logistics/shipments', { params: { ...filters, ...pagination } }),
  updateShipmentStatus: (id, data) => api.put(`/logistics/shipments/${id}/status`, data),
  addTrackingUpdate: (id, data) => api.post(`/logistics/shipments/${id}/tracking`, data),
  getShipmentTracking: (id) => api.get(`/logistics/shipments/${id}/tracking`),
  registerVehicle: (data) => api.post('/logistics/vehicles', data),
  getVehicles: (filters) => api.get('/logistics/vehicles', { params: filters }),
  registerDriver: (data) => api.post('/logistics/drivers', data),
  getDrivers: (filters) => api.get('/logistics/drivers', { params: filters }),
  getShipmentModes: () => api.get('/logistics/modes'),
}

// Insurance API
export const insuranceAPI = {
  createPolicy: (data) => api.post('/insurance/policies', data),
  getPolicy: (id) => api.get(`/insurance/policies/${id}`),
  getPolicies: (filters, pagination) => api.get('/insurance/policies', { params: { ...filters, ...pagination } }),
  submitClaim: (data) => api.post('/insurance/claims', data),
  getClaim: (id) => api.get(`/insurance/claims/${id}`),
  getClaims: (filters, pagination) => api.get('/insurance/claims', { params: { ...filters, ...pagination } }),
  processClaim: (id, data) => api.put(`/insurance/claims/${id}/process`, data),
  createMasterPolicy: (data) => api.post('/insurance/master-policies', data),
  getMasterPolicies: (filters) => api.get('/insurance/master-policies', { params: filters }),
  getInsuranceProducts: (filters) => api.get('/insurance/products', { params: filters }),
  calculatePremium: (data) => api.post('/insurance/calculate-premium', data),
}

// AI API
export const aiAPI = {
  predictDemand: (data) => api.post('/ai/predict/demand', data),
  optimizePrice: (data) => api.post('/ai/optimize/price', data),
  assessCreditRisk: (data) => api.post('/ai/assess/credit-risk', data),
  detectFraud: (data) => api.post('/ai/detect/fraud', data),
  generateRecommendations: (data) => api.post('/ai/recommend', data),
}

// Forms API
export const formsAPI = {
  getForms: (params = {}) => api.get('/forms', { params }),
  getForm: (id) => api.get(`/forms/${id}`),
  createForm: (data) => api.post('/forms', data),
  updateForm: (id, data) => api.put(`/forms/${id}`, data),
  deleteForm: (id) => api.delete(`/forms/${id}`),
  submitForm: (id, payload) => api.post(`/forms/${id}/submit`, payload),
  getSubmissions: (id) => api.get(`/forms/${id}/submissions`),
  getTemplates: () => api.get('/forms/templates'),
}

// Analytics API
export const analyticsAPI = {
  getOverview: () => api.get('/analytics/overview'),
  getInsights: () => api.get('/analytics/insights'),
}

// ERP API
export const erpAPI = {
  getSyncStatus: () => api.get('/erp/status'),
  syncProduct: (data) => api.post('/erp/sync/product', data),
  syncOrder: (data) => api.post('/erp/sync/order', data),
  syncFarmer: (data) => api.post('/erp/sync/farmer', data),
  syncTransaction: (data) => api.post('/erp/sync/transaction', data),
  syncAsset: (data) => api.post('/erp/sync/asset', data),
  triggerBulkSync: (data) => api.post('/erp/sync/bulk', data),
}

export default api
